import streamlit as st
import swisseph as swe
from datetime import datetime, timedelta, date, time, timezone
import base64
from html import escape as _esc
from geopy.geocoders import Nominatim
from timezonefinder import TimezoneFinder
import zoneinfo
import os
import json
import sqlite3
import urllib.request
import urllib.error

# ---------------------------------------------------------------
# Swiss Ephemeris (Lahiri Ayanamsha)
# ---------------------------------------------------------------
swe.set_sid_mode(swe.SIDM_LAHIRI)

SIGNS = ["Mesh", "Vrishabh", "Mithun", "Kark", "Singh", "Kanya",
         "Tula", "Vrishchik", "Dhanu", "Makar", "Kumbh", "Meen"]
SIGNS_HI = ["मेष", "वृषभ", "मिथुन", "कर्क", "सिंह", "कन्या",
            "तुला", "वृश्चिक", "धनु", "मकर", "कुंभ", "मीन"]

NAKSHATRAS = [
    "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira", "Ardra",
    "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni",
    "Uttara Phalguni", "Hasta", "Chitra", "Swati", "Vishakha", "Anuradha",
    "Jyeshtha", "Mula", "Purva Ashadha", "Uttara Ashadha", "Shravana",
    "Dhanishta", "Shatabhisha", "Purva Bhadrapada", "Uttara Bhadrapada", "Revati"
]

PLANETS = {
    "Surya": swe.SUN, "Chandra": swe.MOON, "Mangal": swe.MARS,
    "Budh": swe.MERCURY, "Guru": swe.JUPITER, "Shukra": swe.VENUS,
    "Shani": swe.SATURN, "Rahu": swe.MEAN_NODE,
}

DASHA_LORDS = ["Ketu", "Shukra", "Surya", "Chandra", "Mangal",
               "Rahu", "Guru", "Shani", "Budh"]
DASHA_YEARS = {"Ketu": 7, "Shukra": 20, "Surya": 6, "Chandra": 10, "Mangal": 7,
               "Rahu": 18, "Guru": 16, "Shani": 19, "Budh": 17}
YEAR_DAYS = 365.25

RASHI_LORDS = {0: "Mangal", 1: "Shukra", 2: "Budh", 3: "Chandra", 4: "Surya",
               5: "Budh", 6: "Shukra", 7: "Mangal", 8: "Guru", 9: "Shani",
               10: "Shani", 11: "Guru"}

OWN_SIGNS = {"Mangal": [0, 7], "Shukra": [1, 6], "Budh": [2, 5],
             "Guru": [8, 11], "Shani": [9, 10]}
EXALT_SIGN = {"Mangal": 9, "Shukra": 11, "Budh": 5, "Guru": 3, "Shani": 6}
MAHAPURUSHA = {"Mangal": "रुचक योग", "Budh": "भद्र योग", "Guru": "हंस योग",
               "Shukra": "मालव्य योग", "Shani": "शश योग"}

GEMSTONES = {
    "Surya": "माणिक्य (Ruby)", "Chandra": "मोती (Pearl)",
    "Mangal": "मूँगा (Red Coral)", "Budh": "पन्ना (Emerald)",
    "Guru": "पुखराज (Yellow Sapphire)", "Shukra": "हीरा / ओपल (Diamond / Opal)",
    "Shani": "नीलम (Blue Sapphire)",
    "Rahu": "गोमेद (Hessonite) - केवल विद्वान की सलाह से",
    "Ketu": "लहसुनिया (Cat's Eye) - केवल विद्वान की सलाह से",
}

RUDRAKSHA = {
    "Surya": "1 मुखी या 12 मुखी रुद्राक्ष", "Chandra": "2 मुखी रुद्राक्ष",
    "Mangal": "3 मुखी रुद्राक्ष", "Budh": "4 मुखी रुद्राक्ष",
    "Guru": "5 मुखी रुद्राक्ष", "Shukra": "6 मुखी रुद्राक्ष",
    "Shani": "7 मुखी रुद्राक्ष", "Rahu": "8 मुखी रुद्राक्ष",
    "Ketu": "9 मुखी रुद्राक्ष",
}

HEALTH_MAP = {
    "Surya": "अस्थि स्वास्थ्य, नेत्र दृष्टि, हृदय प्रणाली, एवं पित्त संबंधी संतुलन पर विशेष ध्यान दें।",
    "Chandra": "मानसिक शांति, अनिद्रा, कफ/जल जनित समस्याएं, एवं श्वसन तंत्र की देखभाल आवश्यक है।",
    "Mangal": "रक्तचाप, एसिडिटी, चोट-चपेट से सावधानी, एवं पाचन अग्नि को संतुलित रखना हितकर है।",
    "Budh": "त्वचा स्वास्थ्य, स्नायु तंत्र (Nervous System), वाणी एवं गले की देखभाल पर ध्यान दें।",
    "Guru": "यकृत (Liver) स्वास्थ्य, कोलेस्ट्रॉल, शुगर/डायबिटीज प्रबंधन, एवं पाचन तंत्र पर ध्यान दें।",
    "Shukra": "वृक्क (Kidney) स्वास्थ्य, हार्मोनल संतुलन, एवं शरीर में शर्करा स्तर की नियमित जांच रखें।",
    "Shani": "अस्थि संधि (Joints), वात संतुलन, दांतों की देखभाल, एवं शारीरिक दिनचर्या में अनुशासन रखें।",
    "Rahu": "अचानक स्वास्थ्य उतार-चढ़ाव, मानसिक तनाव, एलर्जी, एवं एंग्जाइटी से बचाव के लिए योग करें।",
    "Ketu": "त्वचा संबंधी संवेदनशीलता, उदर स्वास्थ्य, एवं शारीरिक ऊर्जा स्तर को बनाए रखने के उपाय करें।",
}

MAHADASHA_PREDICTIONS = {
    "Surya": "सूर्य की महादशा आत्मबल, अधिकार, सामाजिक प्रतिष्ठा और प्रशासनिक कार्यों में सफलता प्रदान करती है। अहंकार से बचें।",
    "Chandra": "चंद्रमा की महादशा मन की संवेदनशीलता, रचनात्मकता और मानसिक सुख लाती है। माता का सहयोग मिलता है।",
    "Mangal": "मंगल की महादशा असीम ऊर्जा, साहस, पराक्रम, भूमि और तकनीकी कार्यों में बड़ी सफलता का काल है।",
    "Budh": "बुध की महादशा बुद्धि, ज्ञान, संचार, बैंकिंग, लेखन और व्यापारिक कुशाग्रता का काल मानी जाती है।",
    "Guru": "बृहस्पति की महादशा सुख, समृद्धि, उच्च शिक्षा, आध्यात्मिक ज्ञान और दांपत्य जीवन में वृद्धि लाती है।",
    "Shukra": "शुक्र की महादशा भौतिक सुख-सुविधाओं, वाहन, आभूषण, कला और विलासिता का स्वर्णिम काल होती है।",
    "Shani": "शनि की महादशा कड़े परिश्रम, अनुशासन और परिपक्वता का काल है। यह स्थायी और दीर्घकालिक फल देती है।",
    "Rahu": "राहु की महादशा अचानक बदलाव, आधुनिक तकनीक, विदेशी व्यापार और लीक से हटकर सोचने का अवसर देती है।",
    "Ketu": "केतु की महादशा आध्यात्म, गुप्त विद्याओं, शोध और आत्म-साक्षात्कार का काल है। अंतर्दृष्टि मजबूत होती है।",
}


# ---------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------
def get_navamsha_sign(abs_degree):
    abs_degree = abs_degree % 360
    d1_sign = int(abs_degree // 30)
    navamsha_num = int((abs_degree % 30) // (30 / 9))
    if d1_sign in (0, 4, 8):      # fire
        start = 0
    elif d1_sign in (1, 5, 9):    # earth
        start = 9
    elif d1_sign in (2, 6, 10):   # air
        start = 6
    else:                         # water
        start = 3
    return (start + navamsha_num) % 12


def get_dashamsha_sign(abs_degree):
    """Return the D10 (Dashamsha) sign using the classical odd/even sign rule."""
    abs_degree = abs_degree % 360
    rashi = int(abs_degree // 30)
    part = min(9, int((abs_degree % 30) // 3.0))
    # Odd-numbered signs (Aries, Gemini, etc.) start from the same sign;
    # even-numbered signs start from the 9th sign from the natal sign.
    start = rashi if rashi % 2 == 0 else (rashi + 8) % 12
    return (start + part) % 12


def get_profile_db():
    """Local SQLite store. On hosted deployments, filesystem persistence depends on the host."""
    db_path = os.environ.get("JYOTISH_DB_PATH", "jyotish_profiles.db")
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            dob TEXT NOT NULL,
            birth_time TEXT NOT NULL,
            place TEXT NOT NULL,
            gender TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    return conn


def save_profile(name, dob_value, birth_time, place, gender):
    with get_profile_db() as conn:
        conn.execute(
            "INSERT INTO profiles(name, dob, birth_time, place, gender) VALUES (?, ?, ?, ?, ?)",
            (name, dob_value.isoformat(), birth_time.strftime("%H:%M"), place, gender),
        )


def list_profiles():
    with get_profile_db() as conn:
        return conn.execute(
            "SELECT id, name, dob, birth_time, place, gender, created_at FROM profiles ORDER BY id DESC"
        ).fetchall()


def delete_profile(profile_id):
    with get_profile_db() as conn:
        conn.execute("DELETE FROM profiles WHERE id = ?", (int(profile_id),))


def guna_milan(report_a, report_b):
    """Indicative Ashtakoota-style score out of 36; traditions may differ."""
    nak_a = int(report_a["lons"]["Chandra"] / (360.0 / 27.0))
    nak_b = int(report_b["lons"]["Chandra"] / (360.0 / 27.0))
    sign_a, sign_b = report_a["moon_sign"], report_b["moon_sign"]

    # Traditional Nakshatra classifications in Ashwini-to-Revati order.
    deva = {0, 4, 6, 7, 12, 14, 17, 21, 26}
    manushya = {1, 3, 5, 10, 11, 19, 20, 24, 25}
    rakshasa = {2, 8, 9, 13, 15, 18, 22, 23}
    gana = ["Deva" if i in deva else "Manushya" if i in manushya else "Rakshasa" for i in range(27)]

    yoni = [
        "Horse", "Elephant", "Sheep", "Serpent", "Serpent", "Dog", "Cat", "Sheep", "Cat",
        "Rat", "Rat", "Cow", "Buffalo", "Tiger", "Buffalo", "Tiger", "Deer", "Deer",
        "Dog", "Monkey", "Mongoose", "Monkey", "Lion", "Horse", "Lion", "Cow", "Elephant"
    ]
    nadi = []
    adi = {0, 5, 6, 11, 12, 17, 18, 23, 24}
    madhya = {1, 4, 7, 10, 13, 16, 19, 22, 25}
    for i in range(27):
        nadi.append("Adi" if i in adi else "Madhya" if i in madhya else "Antya")

    # Moon-sign lords.
    sign_lords = ["Mars", "Venus", "Mercury", "Moon", "Sun", "Mercury",
                  "Venus", "Mars", "Jupiter", "Saturn", "Saturn", "Jupiter"]
    friends = {
        "Sun": {"Moon", "Mars", "Jupiter"}, "Moon": {"Sun", "Mercury"},
        "Mars": {"Sun", "Moon", "Jupiter"}, "Mercury": {"Sun", "Venus"},
        "Jupiter": {"Sun", "Moon", "Mars"}, "Venus": {"Mercury", "Saturn"},
        "Saturn": {"Mercury", "Venus"},
    }
    enemies = {
        "Sun": {"Venus", "Saturn"}, "Moon": set(), "Mars": {"Mercury"},
        "Mercury": {"Moon"}, "Jupiter": {"Mercury", "Venus"},
        "Venus": {"Sun", "Moon"}, "Saturn": {"Sun", "Moon", "Mars"},
    }
    lord_a, lord_b = sign_lords[sign_a], sign_lords[sign_b]

    # Varna: 1 point maximum. Traditional sign classes, arranged as a simple compatibility check.
    varna = [1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]
    varna_score = 1 if varna[sign_a] == varna[sign_b] else 0

    # Vashya is a simplified sign-class comparison (full school-specific tables differ).
    element = [0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3]
    vashya_score = 2 if element[sign_a] == element[sign_b] else 1 if (element[sign_a] + element[sign_b]) % 2 == 0 else 0

    tara_a = (nak_b - nak_a) % 9
    tara_b = (nak_a - nak_b) % 9
    good_tara = {0, 1, 3, 5, 7}
    tara_score = 3 if tara_a in good_tara and tara_b in good_tara else 1.5 if tara_a in good_tara or tara_b in good_tara else 0

    # Yoni enemy pairs are a simplified traditional conflict list.
    yoni_enemies = {
        frozenset(("Horse", "Buffalo")), frozenset(("Elephant", "Lion")),
        frozenset(("Sheep", "Monkey")), frozenset(("Serpent", "Mongoose")),
        frozenset(("Dog", "Deer")), frozenset(("Cat", "Rat")),
        frozenset(("Cow", "Tiger")), frozenset(("Rat", "Monkey")),
    }
    if yoni[nak_a] == yoni[nak_b]:
        yoni_score = 4
    elif frozenset((yoni[nak_a], yoni[nak_b])) in yoni_enemies:
        yoni_score = 0
    else:
        yoni_score = 2

    if lord_a == lord_b:
        maitri_score = 5
    elif lord_b in friends.get(lord_a, set()) and lord_a in friends.get(lord_b, set()):
        maitri_score = 5
    elif lord_b in enemies.get(lord_a, set()) or lord_a in enemies.get(lord_b, set()):
        maitri_score = 0
    else:
        maitri_score = 3

    gana_pair = {gana[nak_a], gana[nak_b]}
    if gana[nak_a] == gana[nak_b]:
        gana_score = 6
    elif gana_pair == {"Deva", "Manushya"}:
        gana_score = 5
    elif "Rakshasa" in gana_pair and "Deva" in gana_pair:
        gana_score = 0
    else:
        gana_score = 1

    sign_distance = (sign_b - sign_a) % 12
    bhakoot_bad = sign_distance in {1, 4, 5, 7, 8, 11}
    bhakoot_score = 0 if bhakoot_bad and sign_a != sign_b else 7

    nadi_score = 0 if nadi[nak_a] == nadi[nak_b] else 8

    details = [
        ("Varna", varna_score, 1, f"Moon-sign classes: {varna[sign_a]} / {varna[sign_b]}"),
        ("Vashya", vashya_score, 2, "Simplified sign-class compatibility"),
        ("Tara", tara_score, 3, f"Nakshatra distance remainders: {tara_a}, {tara_b}"),
        ("Yoni", yoni_score, 4, f"{yoni[nak_a]} / {yoni[nak_b]}"),
        ("Graha Maitri", maitri_score, 5, f"Moon-sign lords: {lord_a} / {lord_b}"),
        ("Gana", gana_score, 6, f"{gana[nak_a]} / {gana[nak_b]}"),
        ("Bhakoot", bhakoot_score, 7, f"Moon-sign distance: {sign_distance}"),
        ("Nadi", nadi_score, 8, f"{nadi[nak_a]} / {nadi[nak_b]}"),
    ]
    total = round(sum(x[1] for x in details), 1)
    return total, details, nak_a, nak_b


def get_current_transits():
    """Return current sidereal sign positions using Swiss Ephemeris."""
    now = datetime.now(timezone.utc)
    jd = swe.julday(now.year, now.month, now.day,
                    now.hour + now.minute / 60.0 + now.second / 3600.0)
    flags = swe.FLG_SWIEPH | swe.FLG_SIDEREAL | swe.FLG_SPEED
    out = {}
    for pname, code in PLANETS.items():
        result = swe.calc_ut(jd, code, flags)[0]
        out[pname] = {"longitude": result[0] % 360, "sign": int((result[0] % 360) // 30)}
    if "Rahu" in out:
        ketu_lon = (out["Rahu"]["longitude"] + 180) % 360
        out["Ketu"] = {"longitude": ketu_lon, "sign": int(ketu_lon // 30)}
    return out


def build_pdf_bytes(report):
    """Create a portable PDF summary; use English/Roman labels for font portability."""
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.enums import TA_CENTER
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from io import BytesIO
    except ImportError as exc:
        raise RuntimeError("PDF ke liye reportlab install karein: pip install reportlab") from exc

    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    styles = getSampleStyleSheet()
    font_name = "Helvetica"
    font_path = "/usr/share/fonts/truetype/noto/NotoSansDevanagari-Regular.ttf"
    if os.path.exists(font_path):
        try:
            pdfmetrics.registerFont(TTFont("JyotishNoto", font_path))
            font_name = "JyotishNoto"
        except Exception:
            font_name = "Helvetica"
    for style_name in ("Normal", "Title", "Heading2", "Italic"):
        styles[style_name].fontName = font_name
    styles.add(ParagraphStyle(name="TitleCenter", parent=styles["Title"], alignment=TA_CENTER, fontName=font_name))
    story = [
        Paragraph("JYOTISH AI - Birth Chart Report", styles["TitleCenter"]),
        Spacer(1, 10),
        Paragraph(f"Name: {_esc(str(report.get('name', '')))}", styles["Normal"]),
        Paragraph(f"Birth details: {_esc(str(report.get('dob_str', '')))}", styles["Normal"]),
        Paragraph(f"Birth place: {_esc(str(report.get('place', '')))}", styles["Normal"]),
        Paragraph(f"Timezone: {_esc(str(report.get('tz_str', '')))} (UTC {report.get('utc_off', 0):+.2f})", styles["Normal"]),
        Paragraph(f"Ascendant: {SIGNS[report['asc_sign']]} | Moon sign: {SIGNS[report['moon_sign']]}", styles["Normal"]),
        Spacer(1, 12),
        Paragraph("Planetary Positions", styles["Heading2"]),
    ]
    planet_data = [["Planet", "D1 sign", "House", "Degree", "D9 sign", "D10 sign", "Status"]]
    for row in report.get("rows", []):
        planet_data.append([
            str(row.get("Planet", "")).replace(" (R)", " R"),
            str(row.get("D1 Rashi", "")), str(row.get("House", "")),
            str(row.get("Degree", "")), str(row.get("D9 Navamsha Rashi", "")),
            str(row.get("D10 Dashamsha Rashi", "")), str(row.get("Status", "")),
        ])
    table = Table(planet_data, repeatRows=1, colWidths=[65, 58, 48, 38, 68, 68, 55])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#3A0007")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
        ("FONTNAME", (0, 0), (-1, -1), font_name),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.extend([table, Spacer(1, 12), Paragraph("Vimshottari Mahadasha", styles["Heading2"])])
    md_data = [["Lord", "Start", "End", "Years", "Active"]]
    for m in report.get("md_rows", []):
        md_data.append([m["lord"], m["start"], m["end"], str(m["years"]), "Yes" if m["active"] else ""])
    md_table = Table(md_data, repeatRows=1, colWidths=[70, 90, 90, 50, 55])
    md_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#8A1C1C")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("FONTNAME", (0, 0), (-1, -1), font_name),
    ]))
    story.extend([md_table, Spacer(1, 12), Paragraph("Panchang", styles["Heading2"])])
    pc = report.get("panchang", {})
    story.append(Paragraph(
        f"Vara: {pc.get('vara', '')} | Tithi: {pc.get('tithi', '')} | "
        f"Nakshatra: {pc.get('nakshatra', '')} | Yoga: {pc.get('yoga', '')} | Karana: {pc.get('karana', '')}",
        styles["Normal"]
    ))
    story.append(Spacer(1, 8))
    story.append(Paragraph("For educational/astrological interpretation only; not a scientific or guaranteed prediction.", styles["Italic"]))
    doc.build(story)
    return buffer.getvalue()


def ask_ai_jyotish(question, report, language, api_key, model="gpt-4o-mini"):
    """Call OpenAI-compatible Chat Completions endpoint only when user configures a key."""
    chart_context = "No birth chart has been generated in this session."
    if report:
        planets = "; ".join(
            f"{row['Planet']}: {row['D1 Rashi']} house {row['House']}, D9 {row['D9 Navamsha Rashi']}"
            for row in report.get("rows", [])
        )
        chart_context = (
            f"Ascendant: {SIGNS[report['asc_sign']]}; Moon sign: {SIGNS[report['moon_sign']]}; "
            f"active Mahadasha: {report.get('active_md')}; active Antardasha: {report.get('active_ad')}. "
            f"Planet data: {planets}"
        )
    lang_names = {"Hindi": "Hindi", "Nepali": "Nepali", "English": "English"}
    system_prompt = (
        "You are a careful Vedic astrology explainer. Use only supplied chart facts; never invent planetary positions "
        "or dates. Explain traditional interpretations as beliefs, not guaranteed facts. Avoid fear-based certainty, "
        "medical diagnosis, financial guarantees, or telling users to make major decisions solely from astrology. "
        f"Answer in {lang_names.get(language, 'Hindi')}. If birth-chart data is absent, clearly say so. "
        f"Chart context: {chart_context}"
    )
    payload = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": question},
        ],
        "temperature": 0.4,
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=payload,
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=45) as response:
            data = json.loads(response.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:500]
        raise RuntimeError(f"AI API error ({exc.code}): {detail}") from exc
    except (urllib.error.URLError, KeyError, ValueError, TimeoutError) as exc:
        raise RuntimeError(f"AI service unavailable or returned an unexpected response: {exc}") from exc


def antardashas(md_lord, md_start):
    """Full 9 antardashas of a mahadasha. md_start must be the *true* start
    of the mahadasha (for the first MD this is before birth)."""
    md_idx = DASHA_LORDS.index(md_lord)
    md_years = DASHA_YEARS[md_lord]
    out, start = [], md_start
    for i in range(9):
        lord = DASHA_LORDS[(md_idx + i) % 9]
        yrs = md_years * DASHA_YEARS[lord] / 120.0
        end = start + timedelta(days=yrs * YEAR_DAYS)
        out.append((lord, start, end))
        start = end
    return out


def check_kaal_sarp(lons, rahu_deg):
    """All 7 planets on one side of the Rahu-Ketu axis."""
    others = ["Surya", "Chandra", "Mangal", "Budh", "Guru", "Shukra", "Shani"]
    diffs = [(lons[p] - rahu_deg) % 360 for p in others]
    return all(d < 180 for d in diffs) or all(d > 180 for d in diffs)


def find_yogas(sign_of, houses):
    yogas = []
    # Gajakesari: Guru in kendra from Chandra
    if (sign_of["Guru"] - sign_of["Chandra"]) % 12 in (0, 3, 6, 9):
        yogas.append(("गजकेसरी योग", "गुरु चंद्र से केंद्र में है: यश, बुद्धि और सम्मान देने वाला योग।"))
    # Budhaditya
    if sign_of["Surya"] == sign_of["Budh"]:
        yogas.append(("बुधादित्य योग", "सूर्य-बुध एक राशि में: तीक्ष्ण बुद्धि और वाक्पटुता।"))
    # Chandra-Mangal
    if sign_of["Chandra"] == sign_of["Mangal"]:
        yogas.append(("चंद्र-मंगल योग", "धन-अर्जन की क्षमता, पर भावनात्मक उग्रता से सावधान रहें।"))
    # Panch Mahapurusha
    for p, name in MAHAPURUSHA.items():
        in_kendra = houses[p] in (1, 4, 7, 10)
        strong = sign_of[p] in OWN_SIGNS[p] or sign_of[p] == EXALT_SIGN[p]
        if in_kendra and strong:
            yogas.append((name, f"{p} स्वराशि/उच्च का होकर केंद्र में है: पंच-महापुरुष योग।"))
    return yogas


def analyze_love(asc_sign, sign_of, houses, gender):
    """Love / marriage / affair tendencies from 5th, 7th, 12th houses,
    their lords, Venus (or Jupiter for women), Mars, Rahu, Ketu, Shani."""
    lord5 = RASHI_LORDS[(asc_sign + 4) % 12]
    lord7 = RASHI_LORDS[(asc_sign + 6) % 12]
    karaka = "Guru" if gender.startswith("Female") else "Shukra"

    def in_house(h):
        return [p for p in houses if houses[p] == h]

    def together(a, b):
        return sign_of[a] == sign_of[b]

    love, marriage, affair = [], [], []
    score = 0

    # --- Prem (5th house)
    p5 = in_house(5)
    love.append(("info", f"पंचम भाव (प्रेम): लग्न से {SIGNS[(asc_sign + 4) % 12]} राशि, स्वामी {lord5} "
                         f"{houses[lord5]}वें भाव में। पंचम में ग्रह: {', '.join(p5) if p5 else 'कोई नहीं'}।"))
    if houses["Shukra"] in (1, 5, 7, 11):
        love.append(("good", f"शुक्र {houses['Shukra']}वें भाव में है: प्रेम, आकर्षण और रोमांस की अच्छी क्षमता।"))
    elif houses["Shukra"] in (6, 8, 12):
        love.append(("warn", f"शुक्र {houses['Shukra']}वें भाव में है: प्रेम में बाधा, देरी या गुप्तता के संकेत।"))
    if "Chandra" in p5 or together("Chandra", "Shukra"):
        love.append(("good", "चंद्र/शुक्र का संबंध भावनात्मक और संवेदनशील प्रेम स्वभाव दर्शाता है।"))
    if together("Shani", "Shukra"):
        love.append(("warn", "शनि-शुक्र एक राशि में: प्रेम देर से मिलता है, रिश्ते में गंभीरता और दूरी दोनों रह सकती हैं।"))
    if together("Mangal", "Shukra"):
        love.append(("warn", "मंगल-शुक्र एक राशि में: तीव्र आकर्षण और जुनून, पर संयम की आवश्यकता।"))
        score += 1
    if together("Rahu", "Shukra") or together("Ketu", "Shukra"):
        love.append(("warn", "राहु/केतु-शुक्र संबंध: असामान्य या अचानक आकर्षण, भ्रम की संभावना।"))
        score += 1

    # --- Prem vivah (love marriage)
    if together(lord5, lord7) and lord5 != lord7:
        marriage.append(("good", "पंचमेश और सप्तमेश एक राशि में: प्रेम-विवाह का मजबूत योग।"))
    if houses[lord5] == 7 or houses[lord7] == 5:
        marriage.append(("good", "पंचमेश-सप्तमेश का भाव-परिवर्तन/संबंध: प्रेम से विवाह की संभावना।"))
    if lord5 == lord7:
        marriage.append(("good", f"{lord5} पंचम और सप्तम दोनों का स्वामी है: प्रेम और विवाह एक-दूसरे से जुड़े रहते हैं।"))
    if houses[karaka] in (5, 7):
        marriage.append(("good", f"विवाह कारक {karaka} {houses[karaka]}वें भाव में है: साथी से अच्छा जुड़ाव।"))
    if not marriage:
        marriage.append(("info", "प्रेम-विवाह के स्पष्ट शास्त्रीय योग नहीं मिले; विवाह पारंपरिक या मिश्रित रूप से संभव।"))

    # --- Saptam (7th house)
    p7 = in_house(7)
    marriage.append(("info", f"सप्तम भाव: {SIGNS[(asc_sign + 6) % 12]} राशि, स्वामी {lord7} {houses[lord7]}वें भाव में। "
                             f"सप्तम में ग्रह: {', '.join(p7) if p7 else 'कोई नहीं'}।"))
    if houses[lord7] in (6, 8, 12):
        marriage.append(("warn", f"सप्तमेश {houses[lord7]}वें (दुःस्थान) भाव में: वैवाहिक जीवन में उतार-चढ़ाव, दूरी या विलंब।"))
        score += 1
    if houses[lord7] in (1, 4, 5, 7, 9, 10, 11):
        marriage.append(("good", f"सप्तमेश {houses[lord7]}वें भाव में: वैवाहिक सुख के लिए अनुकूल स्थिति।"))
    if "Shani" in p7 or "Mangal" in p7:
        marriage.append(("warn", "सप्तम में शनि/मंगल: विवाह में देरी या स्वभाव-भेद; धैर्य ज़रूरी।"))
    if "Guru" in p7 or "Shukra" in p7:
        marriage.append(("good", "सप्तम में गुरु/शुक्र: सुखद और सहयोगी जीवनसाथी का संकेत।"))

    # --- Affair / secret relationship tendencies
    if "Rahu" in in_house(5) or "Rahu" in p7 or "Ketu" in p7:
        affair.append(("warn", "राहु/केतु पंचम या सप्तम में: गुप्त, असामान्य या अचानक बनने-टूटने वाले संबंधों की प्रवृत्ति।"))
        score += 1
    if "Rahu" in in_house(12) or "Mangal" in in_house(12):
        affair.append(("warn", "द्वादश भाव (शय्या सुख/गुप्त बातें) में राहु/मंगल: छिपे हुए संबंधों की प्रवृत्ति।"))
        score += 1
    if houses[lord5] in (6, 8, 12) or houses[lord7] == 12:
        affair.append(("warn", "पंचमेश/सप्तमेश का दुःस्थान या द्वादश से संबंध: संबंधों में गोपनीयता या बाधा।"))
        score += 1
    if together("Mangal", "Shukra") or together("Rahu", "Shukra"):
        affair.append(("warn", "शुक्र पर मंगल/राहु का प्रभाव: आकर्षण में अधिक तीव्रता, इच्छाओं पर संयम की आवश्यकता।"))
        score += 1
    if houses["Shukra"] == 12:
        affair.append(("info", "शुक्र द्वादश में: भोग-विलास और निजी जीवन में गोपनीयता की प्रवृत्ति।"))
    if "Shani" in in_house(7) or "Guru" in in_house(7):
        affair.append(("good", "सप्तम में शनि/गुरु: मर्यादा और निष्ठा की प्रवृत्ति को बल।"))
        score -= 1
    if not affair:
        affair.append(("good", "गुप्त संबंध या अनैतिक आकर्षण के स्पष्ट योग नहीं मिले।"))

    level = "कम" if score <= 1 else ("मध्यम" if score <= 3 else "अधिक")
    return {"love": love, "marriage": marriage, "affair": affair,
            "affair_level": level, "score": score, "karaka": karaka,
            "lord5": lord5, "lord7": lord7}


WEEKDAYS = ["सोमवार", "मंगलवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार", "रविवार"]
TITHIS = ["प्रतिपदा", "द्वितीया", "तृतीया", "चतुर्थी", "पंचमी", "षष्ठी", "सप्तमी", "अष्टमी",
          "नवमी", "दशमी", "एकादशी", "द्वादशी", "त्रयोदशी", "चतुर्दशी"]
PANCHANG_YOGAS = ["विष्कुम्भ", "प्रीति", "आयुष्मान", "सौभाग्य", "शोभन", "अतिगण्ड", "सुकर्मा", "धृति",
                  "शूल", "गण्ड", "वृद्धि", "ध्रुव", "व्याघात", "हर्षण", "वज्र", "सिद्धि", "व्यतीपात",
                  "वरीयान", "परिघ", "शिव", "सिद्ध", "साध्य", "शुभ", "शुक्ल", "ब्रह्म", "इन्द्र", "वैधृति"]
KARANA_MOVABLE = ["बव", "बालव", "कौलव", "तैतिल", "गर", "वणिज", "विष्टि (भद्रा)"]
KARANA_FIXED = ["शकुनि", "चतुष्पद", "नाग"]

NAK_GANA = ["देव", "मनुष्य", "राक्षस", "मनुष्य", "देव", "मनुष्य", "देव", "देव", "राक्षस", "राक्षस",
            "मनुष्य", "मनुष्य", "देव", "राक्षस", "देव", "राक्षस", "देव", "राक्षस", "राक्षस", "मनुष्य",
            "मनुष्य", "देव", "राक्षस", "राक्षस", "मनुष्य", "मनुष्य", "देव"]
NAK_YONI = ["अश्व", "गज", "मेष", "सर्प", "सर्प", "श्वान", "मार्जार", "मेष", "मार्जार", "मूषक",
            "मूषक", "गौ", "महिष", "व्याघ्र", "महिष", "व्याघ्र", "मृग", "मृग", "श्वान", "वानर",
            "नकुल", "वानर", "सिंह", "अश्व", "सिंह", "गौ", "गज"]
NADI_NAMES = ["आदि", "मध्य", "अंत्य", "अंत्य", "मध्य", "आदि"]       # index % 6
VARNA_BY_SIGN = ["क्षत्रिय", "वैश्य", "शूद्र", "ब्राह्मण"] * 3          # index % 4
VASHYA_BY_SIGN = ["चतुष्पद", "चतुष्पद", "मानव", "जलचर", "वनचर", "मानव", "मानव", "कीट",
                  "मानव/चतुष्पद", "चतुष्पद/जलचर", "मानव", "जलचर"]
TATVA_BY_SIGN = ["अग्नि", "पृथ्वी", "वायु", "जल"]                      # index % 4
BHAVA_NAMES = ["तनु (लग्न)", "धन/कुटुंब", "सहज (पराक्रम)", "सुख/माता", "पुत्र/विद्या/प्रेम",
               "रिपु/रोग/ऋण", "जाया/विवाह", "आयु/गुप्त", "भाग्य/धर्म", "कर्म/व्यवसाय", "लाभ", "व्यय/विदेश"]

CAREER_HOUSE = {
    1: "स्वयं के बल पर, स्वतंत्र कार्य या नेतृत्व वाली भूमिका।",
    2: "वाणी, परिवार या धन-संबंधी कारोबार; बैंकिंग/खाद्य क्षेत्र में लाभ।",
    3: "मेहनत, संचार, मीडिया, सेल्स या छोटी यात्राओं वाले कार्य।",
    4: "घर के पास या घर से काम; भूमि-भवन, कृषि या वाहन संबंधी क्षेत्र।",
    5: "शिक्षा, रचनात्मक कार्य, सलाह या निवेश से जुड़े क्षेत्र।",
    6: "सेवा, स्वास्थ्य, कानून, प्रतियोगिता या नौकरी में सफलता।",
    7: "साझेदारी, व्यापार और जनसंपर्क वाले कार्य में सफलता।",
    8: "शोध, बीमा, गुप्त/तकनीकी कार्य; करियर में अचानक बदलाव संभव।",
    9: "भाग्य का साथ; उच्च शिक्षा, विदेश या धर्म/कानून से जुड़े क्षेत्र।",
    10: "करियर बहुत मज़बूत; पद, प्रतिष्ठा और स्थिरता।",
    11: "बड़ा नेटवर्क और कई स्रोतों से आय।",
    12: "विदेश, अस्पताल/आश्रम या पर्दे के पीछे वाले कार्य; खर्च अधिक।",
}
CAREER_KARAKA = {
    "Surya": "सरकारी/प्रशासनिक कार्य", "Chandra": "जनता, आतिथ्य, यात्रा, तरल पदार्थ",
    "Mangal": "इंजीनियरिंग, तकनीकी, सुरक्षा, भूमि", "Budh": "व्यापार, IT, लेखा, लेखन",
    "Guru": "शिक्षण, कानून, वित्त, सलाह", "Shukra": "कला, मीडिया, फैशन, सौंदर्य",
    "Shani": "उद्योग, निर्माण, खेती, सेवा", "Rahu": "विदेशी/आधुनिक तकनीक, राजनीति",
    "Ketu": "शोध, अध्यात्म, गुप्त विद्या",
}


def compute_panchang(lons, dob):
    sun, moon = lons["Surya"], lons["Chandra"]
    elong = (moon - sun) % 360
    tithi_no = int(elong // 12) + 1                       # 1..30
    paksha = "शुक्ल" if tithi_no <= 15 else "कृष्ण"
    if tithi_no == 15:
        tithi = "पूर्णिमा"
    elif tithi_no == 30:
        tithi = "अमावस्या"
    else:
        tithi = TITHIS[(tithi_no - 1) % 15]
    k = int(elong // 6)                                    # 0..59
    if k == 0:
        karana = "किंस्तुघ्न"
    elif k >= 57:
        karana = KARANA_FIXED[k - 57]
    else:
        karana = KARANA_MOVABLE[(k - 1) % 7]
    span = 360.0 / 27.0
    yoga = PANCHANG_YOGAS[int(((sun + moon) % 360) / span)]
    nak = int(moon / span)
    pada = int((moon % span) / (span / 4)) + 1
    return {"vara": WEEKDAYS[dob.weekday()], "tithi": f"{paksha} पक्ष {tithi}", "karana": karana,
            "yoga": yoga, "nakshatra": NAKSHATRAS[nak], "pada": pada}


def compute_avakahada(moon_lon):
    nak = int(moon_lon / (360.0 / 27.0))
    sign = int(moon_lon // 30)
    return {"वर्ण": VARNA_BY_SIGN[sign], "वश्य": VASHYA_BY_SIGN[sign], "योनि": NAK_YONI[nak],
            "गण": NAK_GANA[nak], "नाड़ी": NADI_NAMES[nak % 6], "तत्व": TATVA_BY_SIGN[sign % 4],
            "राशि स्वामी": RASHI_LORDS[sign]}


def compute_sade_sati(moon_sign):
    now = datetime.now(timezone.utc)
    jd = swe.julday(now.year, now.month, now.day, now.hour + now.minute / 60.0)
    sat = swe.calc_ut(jd, swe.SATURN, swe.FLG_SWIEPH | swe.FLG_SIDEREAL)[0][0] % 360
    s = int(sat // 30)
    d = (s - moon_sign) % 12
    status = {11: "साढ़ेसाती - प्रथम चरण (चंद्र से 12वें में शनि)",
              0: "साढ़ेसाती - द्वितीय चरण (चंद्र राशि में शनि, शिखर)",
              1: "साढ़ेसाती - तृतीय चरण (चंद्र से 2रे में शनि)",
              3: "शनि ढैया (चंद्र से 4थे में शनि)",
              7: "शनि ढैया (चंद्र से 8वें में शनि)"}.get(d)
    return {"saturn_sign": SIGNS[s], "status": status}


def bhava_table(asc_sign, sign_of, houses):
    rows = []
    for h in range(1, 13):
        sign = (asc_sign + h - 1) % 12
        lord = RASHI_LORDS[sign]
        rows.append({
            "भाव": f"{h} - {BHAVA_NAMES[h - 1]}", "राशि": f"{SIGNS[sign]} ({SIGNS_HI[sign]})",
            "भावेश": f"{lord} ({houses[lord]}वें भाव में)",
            "ग्रह": ", ".join(p for p in houses if houses[p] == h) or "-",
        })
    return rows


def analyze_career(asc_sign, sign_of, houses):
    out = []
    lord10 = RASHI_LORDS[(asc_sign + 9) % 12]
    out.append(("info", f"दशमेश {lord10} {houses[lord10]}वें भाव में: {CAREER_HOUSE[houses[lord10]]}"))
    p10 = [p for p in houses if houses[p] == 10]
    for p in p10:
        out.append(("info", f"दशम भाव में {p}: {CAREER_KARAKA[p]} से जुड़े क्षेत्र।"))
    # wealth
    lord2, lord11 = RASHI_LORDS[(asc_sign + 1) % 12], RASHI_LORDS[(asc_sign + 10) % 12]
    good = (1, 2, 5, 9, 10, 11)
    if houses[lord2] in good:
        out.append(("good", f"धनेश {lord2} {houses[lord2]}वें भाव में: धन संचय के लिए अनुकूल।"))
    else:
        out.append(("warn", f"धनेश {lord2} {houses[lord2]}वें भाव में: खर्च या धन में उतार-चढ़ाव; बचत पर ध्यान दें।"))
    if houses[lord11] in good:
        out.append(("good", f"लाभेश {lord11} {houses[lord11]}वें भाव में: आय के अच्छे स्रोत।"))
    else:
        out.append(("warn", f"लाभेश {lord11} {houses[lord11]}वें भाव में: आय में अस्थिरता संभव।"))
    if lord2 != lord11 and sign_of[lord2] == sign_of[lord11]:
        out.append(("good", "धनेश और लाभेश एक राशि में: धन योग।"))
    return out


# ===============================================================
# विस्तृत महादशा / अंतर्दशा फलादेश
# ===============================================================
GRAHA_HI = {"Surya": "सूर्य", "Chandra": "चंद्र", "Mangal": "मंगल", "Budh": "बुध", "Guru": "गुरु",
            "Shukra": "शुक्र", "Shani": "शनि", "Rahu": "राहु", "Ketu": "केतु"}

NAT_FRIENDS = {
    "Surya": ["Chandra", "Mangal", "Guru"], "Chandra": ["Surya", "Budh"],
    "Mangal": ["Surya", "Chandra", "Guru"], "Budh": ["Surya", "Shukra"],
    "Guru": ["Surya", "Chandra", "Mangal"], "Shukra": ["Budh", "Shani"],
    "Shani": ["Budh", "Shukra"], "Rahu": ["Budh", "Shukra", "Shani"],
    "Ketu": ["Mangal", "Shukra", "Shani"],
}
NAT_ENEMIES = {
    "Surya": ["Shukra", "Shani"], "Chandra": [], "Mangal": ["Budh"],
    "Budh": ["Chandra"], "Guru": ["Budh", "Shukra"], "Shukra": ["Surya", "Chandra"],
    "Shani": ["Surya", "Chandra", "Mangal"], "Rahu": ["Surya", "Chandra", "Mangal"],
    "Ketu": ["Surya", "Chandra"],
}
EXTRA_OWN = {"Surya": [4], "Chandra": [3]}
EXALT_ALL = {"Surya": 0, "Chandra": 1, "Mangal": 9, "Budh": 5, "Guru": 3, "Shukra": 11, "Shani": 6}

HOUSE_THEME = {
    1: "स्वास्थ्य, व्यक्तित्व और आत्म-विश्वास", 2: "धन, वाणी और परिवार",
    3: "पराक्रम, मेहनत, भाई-बहन और संचार", 4: "घर, माता, वाहन और मानसिक सुख",
    5: "संतान, शिक्षा, प्रेम और बुद्धि", 6: "रोग, ऋण और शत्रु (प्रतियोगिता)",
    7: "विवाह, जीवनसाथी और साझेदारी", 8: "आयु, गुप्त विषय और अचानक होने वाली घटनाएँ",
    9: "भाग्य, धर्म, पिता और दूर की यात्राएँ", 10: "कर्म, करियर और प्रतिष्ठा",
    11: "आय, लाभ और इच्छा-पूर्ति", 12: "खर्च, विदेश, नींद और एकांत",
}

# भाव में दशानाथ की स्थिति का फल
HOUSE_EFFECT = {
    1: "दशानाथ लग्न (प्रथम भाव) में है। इसलिए इस काल में आपका व्यक्तित्व, आपकी सोच और आपके निर्णय सीधे जीवन की दिशा तय करते हैं। आप स्वयं आगे बढ़कर काम लेते हैं, लोग आपको गंभीरता से लेते हैं और स्वास्थ्य तथा ऊर्जा पर ग्रह का प्रभाव साफ़ दिखता है। ग्रह शुभ हो तो आत्म-बल बढ़ता है; अशुभ हो तो ज़िद और जल्दबाज़ी नुकसान करा सकती है।",
    2: "दशानाथ द्वितीय भाव (धन-कुटुंब) में है। इस काल में कमाई, बचत, वाणी और पारिवारिक ज़िम्मेदारियाँ मुख्य विषय बनते हैं। धन-संचय का अवसर मिलता है, पर कठोर बोलने से संबंध बिगड़ सकते हैं। खान-पान और परिवार के सदस्यों से जुड़े निर्णय इसी समय महत्वपूर्ण रहते हैं।",
    3: "दशानाथ तृतीय भाव (पराक्रम) में है। यह साहस, मेहनत, छोटी यात्राओं, संचार और भाई-बहनों से जुड़े फल देता है। आप अपने बल पर काम करके आगे बढ़ते हैं। लेखन, मीडिया, सेल्स, कौशल-आधारित काम और नए प्रयासों के लिए यह समय अनुकूल माना जाता है।",
    4: "दशानाथ चतुर्थ भाव (सुख-स्थान) में है। इस काल में घर, ज़मीन-जायदाद, वाहन, माता और मानसिक शांति प्रमुख रहती है। घर बदलना, संपत्ति खरीदना या घर में बड़ा काम होना संभव है। ग्रह अशुभ हो तो मन अशांत रह सकता है और घरेलू तनाव बढ़ सकता है।",
    5: "दशानाथ पंचम भाव (विद्या-संतान) में है। यह शिक्षा, बुद्धि, प्रेम-संबंध, संतान और रचनात्मकता का काल है। पढ़ाई, प्रतियोगी परीक्षा, निवेश और मंत्र-साधना में सफलता की संभावना रहती है। प्रेम और संतान से जुड़े बड़े निर्णय भी इसी दशा में होते हैं।",
    6: "दशानाथ षष्ठ भाव (रोग-ऋण-शत्रु) में है। यह भाव संघर्ष का है, इसलिए इस काल में प्रतियोगिता, नौकरी, मुकदमे और शत्रु-विजय जैसे विषय सक्रिय रहते हैं। मेहनत करने पर विरोधी पराजित होते हैं, पर स्वास्थ्य, कर्ज़ और पाचन पर ध्यान रखना ज़रूरी है। सेवा और अनुशासन से यह दशा लाभ देती है।",
    7: "दशानाथ सप्तम भाव (विवाह-साझेदारी) में है। इस काल में जीवनसाथी, व्यापारिक साझेदारी और सार्वजनिक जीवन केंद्र में रहते हैं। विवाह, सगाई या नई साझेदारी के योग बनते हैं। ग्रह अशुभ हो तो साथी से मतभेद और साझेदारी में विवाद हो सकते हैं।",
    8: "दशानाथ अष्टम भाव (आयु-गुप्त विषय) में है। यह भाव अचानक बदलाव, रुकावट, शोध और गहरे अनुभवों का है। इस काल में अप्रत्याशित घटनाएँ, विरासत या बीमा से लाभ, तंत्र-मंत्र या गूढ़ विद्या में रुचि और स्वास्थ्य की चुनौतियाँ संभव हैं। धैर्य, सावधानी और स्वास्थ्य जाँच विशेष रूप से ज़रूरी हैं।",
    9: "दशानाथ नवम भाव (भाग्य) में है। यह अत्यंत शुभ स्थान माना जाता है। भाग्य का साथ, धार्मिक कार्य, तीर्थ-यात्रा, उच्च शिक्षा, गुरु और पिता का सहयोग मिलता है। रुके हुए काम बनते हैं और विदेश या दूर के स्थानों से जुड़े अवसर आ सकते हैं।",
    10: "दशानाथ दशम भाव (कर्म) में है। यह करियर का सबसे बड़ा भाव है, इसलिए इस काल में पद, प्रतिष्ठा, व्यवसाय और जिम्मेदारी बढ़ती है। प्रमोशन, नई नौकरी या व्यवसाय में बड़ी सफलता की संभावना रहती है। मेहनत का फल समाज के सामने दिखाई देता है।",
    11: "दशानाथ एकादश भाव (लाभ) में है। यह इच्छा-पूर्ति और आय का भाव है। इस काल में आय के कई स्रोत बनते हैं, मित्रों और बड़े नेटवर्क से लाभ मिलता है और पुरानी इच्छाएँ पूरी होती हैं। बड़े भाई-बहन और सामाजिक समूह का सहयोग भी मिलता है।",
    12: "दशानाथ द्वादश भाव (व्यय-विदेश) में है। इस काल में खर्च बढ़ने, विदेश-यात्रा या विदेश में बसने, अस्पताल, आश्रम या एकांत से जुड़े अनुभव होने की संभावना रहती है। नींद और मानसिक शांति पर ध्यान देना पड़ता है। आध्यात्मिक साधना और दान-पुण्य के लिए यह समय बहुत अच्छा है।",
}

# महादशा का विस्तृत फल (प्रत्येक ग्रह के लिए)
MD_DETAIL = {
    "Surya": [
        ("दशा का सामान्य स्वरूप", "सूर्य की महादशा 6 वर्ष की होती है। सूर्य आत्मा, मान-सम्मान, अधिकार, पिता और सरकार का कारक ग्रह है। इस काल में व्यक्ति के भीतर आत्म-विश्वास बढ़ता है और वह अपनी पहचान बनाने के लिए प्रेरित होता है। यदि सूर्य बलवान है तो यह दशा पद, प्रतिष्ठा और सम्मान दिलाती है। यदि कमज़ोर या पीड़ित है तो अहंकार, अधिकारियों से टकराव और मान-हानि की आशंका रहती है।"),
        ("करियर एवं व्यवसाय", "सरकारी नौकरी, प्रशासन, राजनीति, पुलिस-सेना, चिकित्सा, प्रबंधन और नेतृत्व वाले कामों में प्रगति के अवसर मिलते हैं। उच्च अधिकारियों का सहयोग मिलता है और आप अपनी ज़िम्मेदारियाँ आत्मविश्वास से निभाते हैं। निजी व्यवसाय में भी आपको अपनी बात मनवाने की शक्ति मिलती है। परंतु हर जगह स्वयं को सबसे ऊपर रखने की प्रवृत्ति नुकसान भी करा सकती है।"),
        ("धन एवं आर्थिक स्थिति", "आय स्थिर और सम्मानजनक स्रोतों से आती है। सरकारी या पैतृक संपत्ति से लाभ की संभावना रहती है। खर्च अक्सर प्रतिष्ठा बनाए रखने में होता है। बिना सोचे बड़े वादे या दिखावे में पैसा न लगाएँ।"),
        ("परिवार, विवाह एवं संबंध", "पिता या पिता-तुल्य व्यक्ति का प्रभाव जीवन में बढ़ता है। जीवनसाथी के साथ अहंकार के कारण मतभेद हो सकते हैं, इसलिए संवाद में नम्रता रखना ज़रूरी है। सामाजिक दायरे में आपका सम्मान बढ़ता है, पर करीबी रिश्तों में थोड़ी दूरी महसूस हो सकती है।"),
        ("स्वास्थ्य", "हृदय, रक्तचाप, आँखें, हड्डियाँ और पित्त से संबंधित समस्याओं पर ध्यान दें। सिरदर्द, बुखार और गर्मी से जुड़ी परेशानियाँ बार-बार हो सकती हैं। सुबह की धूप, नियमित व्यायाम और पर्याप्त पानी लाभकारी रहते हैं।"),
        ("मानसिक स्थिति एवं स्वभाव", "आप अधिक आत्म-केंद्रित, आदर्शवादी और सिद्धांतवादी हो जाते हैं। दूसरों की सलाह कम सुनने की प्रवृत्ति बढ़ती है। गुस्सा जल्दी आता है, परंतु मन में छल-कपट नहीं रहता।"),
        ("सावधानियाँ", "अहंकार, अधिकारियों से विवाद, पिता से मतभेद और अनावश्यक कानूनी झगड़ों से बचें। अपनी बात को ज़बरदस्ती मनवाने की कोशिश संबंध बिगाड़ सकती है। स्वास्थ्य की अनदेखी न करें।"),
        ("उपाय", "प्रतिदिन सूर्योदय के समय ताँबे के पात्र से सूर्य को जल अर्पित करें और 'ॐ घृणि सूर्याय नमः' का जाप करें। रविवार को गुड़, गेहूँ या ताँबे का दान करें। आदित्य हृदय स्तोत्र का पाठ लाभकारी है। पिता और गुरुजनों का सम्मान करें।"),
    ],
    "Chandra": [
        ("दशा का सामान्य स्वरूप", "चंद्र की महादशा 10 वर्ष की होती है। चंद्रमा मन, भावनाओं, माता और मानसिक शांति का कारक है। इस काल में जीवन का केंद्र भावनात्मक अनुभव और घर-परिवार बन जाता है। चंद्र बलवान हो तो मन प्रसन्न रहता है, कल्पना-शक्ति और लोकप्रियता बढ़ती है। कमज़ोर हो तो चिंता, अस्थिरता और मूड में उतार-चढ़ाव रहता है।"),
        ("करियर एवं व्यवसाय", "जनता से जुड़े काम, होटल-आतिथ्य, डेयरी-तरल पदार्थ, कृषि, कला, लेखन, यात्रा, नर्सिंग-देखभाल और मनोविज्ञान जैसे क्षेत्रों में सफलता मिलती है। महिलाओं या आम लोगों से जुड़े कारोबार में लाभ होता है। करियर में बार-बार बदलाव की इच्छा हो सकती है, इसलिए स्थिरता बनाए रखने का प्रयास करें।"),
        ("धन एवं आर्थिक स्थिति", "आय में उतार-चढ़ाव रह सकता है, क्योंकि चंद्र घटता-बढ़ता रहता है। पर समग्र रूप से धन का प्रवाह बना रहता है और सुख-सुविधाओं पर खर्च होता है। माता या ननिहाल पक्ष से सहयोग मिल सकता है। भावनाओं में आकर पैसा खर्च करने से बचें।"),
        ("परिवार, विवाह एवं संबंध", "माता के साथ संबंध गहरे होते हैं और उनका स्वास्थ्य या सहयोग जीवन में महत्वपूर्ण रहता है। प्रेम और विवाह के लिए यह समय भावनात्मक रूप से अनुकूल है, पर संवेदनशीलता के कारण छोटी बातों पर नाराज़गी भी हो सकती है। घर में शांति बनाए रखने का प्रयास करें।"),
        ("स्वास्थ्य", "मानसिक तनाव, नींद की कमी, सर्दी-जुकाम, कफ, जल-जनित रोग और हार्मोन संबंधी विषयों का ध्यान रखें। नियमित नींद, पर्याप्त पानी और ध्यान-प्राणायाम बहुत सहायक होते हैं।"),
        ("मानसिक स्थिति एवं स्वभाव", "आप भावुक, दयालु और संवेदनशील हो जाते हैं। मन बहुत जल्दी प्रभावित होता है। कभी अत्यधिक उत्साह और कभी उदासी रह सकती है। किसी भी बड़े फैसले को मन की स्थिर अवस्था में ही लें।"),
        ("सावधानियाँ", "अत्यधिक चिंता, अनावश्यक भय, भावनात्मक निर्भरता और जल्दबाज़ी में लिए निर्णयों से बचें। नशा या अनियमित दिनचर्या मानसिक स्थिति को और बिगाड़ सकती है।"),
        ("उपाय", "सोमवार को शिवजी का अभिषेक करें और 'ॐ सों सोमाय नमः' का जाप करें। चावल, दूध या सफेद वस्त्र का दान करें। माता की सेवा करें। रात को समय पर सोएँ और चाँदनी में कुछ देर टहलना शांति देता है।"),
    ],
    "Mangal": [
        ("दशा का सामान्य स्वरूप", "मंगल की महादशा 7 वर्ष की होती है। मंगल साहस, ऊर्जा, भूमि, भाई, रक्त और पराक्रम का ग्रह है। इस काल में कर्म-शक्ति बहुत बढ़ जाती है और व्यक्ति चुनौतियों का सामना करने को तैयार रहता है। बलवान मंगल भूमि, संपत्ति और बड़ी सफलता देता है, जबकि कमज़ोर या पीड़ित मंगल दुर्घटना, क्रोध और विवाद बढ़ाता है।"),
        ("करियर एवं व्यवसाय", "इंजीनियरिंग, तकनीकी कार्य, सेना-पुलिस-सुरक्षा, खेल, सर्जरी, रियल एस्टेट, निर्माण और मशीनरी से जुड़े क्षेत्रों में तेज़ तरक्की होती है। आप जोखिम लेकर आगे बढ़ते हैं। प्रतियोगिता में जीत मिलती है। नेतृत्व की क्षमता निखरती है, पर टीम के साथ तालमेल बनाए रखना ज़रूरी है।"),
        ("धन एवं आर्थिक स्थिति", "भूमि, मकान और वाहन खरीदने के योग बनते हैं। मेहनत से बड़ी आय संभव है। परंतु जल्दबाज़ी में निवेश या जोखिम भरे फैसले हानि भी दे सकते हैं। कर्ज़ लेने में सावधानी रखें।"),
        ("परिवार, विवाह एवं संबंध", "भाइयों से संबंध महत्वपूर्ण रहते हैं। स्वभाव में तेज़ी के कारण जीवनसाथी से तकरार हो सकती है। यदि कुंडली में मंगल दोष है तो वैवाहिक जीवन में अधिक सतर्कता चाहिए। संबंधों में धैर्य और संयम सबसे बड़ा उपाय है।"),
        ("स्वास्थ्य", "रक्तचाप, एसिडिटी, चोट-दुर्घटना, जलन, फोड़े-फुंसी और रक्त संबंधी विषयों पर ध्यान दें। वाहन सावधानी से चलाएँ। नियमित व्यायाम ऊर्जा को सही दिशा देता है।"),
        ("मानसिक स्थिति एवं स्वभाव", "आप साहसी, उत्साही और जुझारू हो जाते हैं, पर क्रोध और अधीरता भी बढ़ती है। हर बात में जीतने की प्रवृत्ति आती है। ऊर्जा को खेल, मेहनत या रचनात्मक काम में लगाना लाभकारी है।"),
        ("सावधानियाँ", "क्रोध, झगड़े, कानूनी विवाद, दुर्घटना और आग या बिजली से जुड़े जोखिमों से सावधान रहें। बड़े भाई-बहन या मित्रों से अहंकार वाला टकराव न करें।"),
        ("उपाय", "मंगलवार को हनुमानजी की पूजा करें, हनुमान चालीसा पढ़ें और 'ॐ अं अंगारकाय नमः' का जाप करें। लाल मसूर, गुड़ या लाल वस्त्र का दान करें। रक्तदान करना भी शुभ माना जाता है। क्रोध पर नियंत्रण का अभ्यास करें।"),
    ],
    "Budh": [
        ("दशा का सामान्य स्वरूप", "बुध की महादशा 17 वर्ष की लंबी अवधि की होती है। बुध बुद्धि, वाणी, व्यापार, गणित और संचार का कारक है। इस काल में सीखने, बोलने और व्यापार करने की क्षमता चरम पर होती है। बलवान बुध तेज़ दिमाग, सफलता और धन देता है; कमज़ोर बुध भ्रम, त्वचा या नसों की समस्या और निर्णय में गड़बड़ी लाता है।"),
        ("करियर एवं व्यवसाय", "व्यापार, बैंकिंग, लेखा, IT और सॉफ्टवेयर, लेखन, पत्रकारिता, शिक्षण, मार्केटिंग, ज्योतिष और सलाह-परामर्श के क्षेत्र बहुत अनुकूल हैं। एक साथ कई काम संभालने की शक्ति बढ़ती है। नए कौशल सीखने और डिग्री-प्रमाणपत्र प्राप्त करने के लिए यह श्रेष्ठ काल है।"),
        ("धन एवं आर्थिक स्थिति", "बुद्धि और संपर्कों के सहारे आय बढ़ती है। व्यापार में तेज़ी से लाभ मिल सकता है, परंतु अनुबंध और लेन-देन को पढ़कर ही हस्ताक्षर करें। शेयर, ट्रेडिंग या सट्टे में जल्दबाज़ी न करें, क्योंकि बुध चंचल ग्रह है।"),
        ("परिवार, विवाह एवं संबंध", "मित्र, भाई-बहन, मामा पक्ष और रिश्तेदारों से संपर्क बढ़ता है। बातचीत से रिश्ते सुधरते हैं, पर अधिक बोलने या चालाकी से रिश्तों में गलतफ़हमी भी हो सकती है। जीवनसाथी के साथ खुला संवाद रखना लाभकारी है।"),
        ("स्वास्थ्य", "त्वचा, नसें, गला, पेट की गैस, एलर्जी और घबराहट जैसी समस्याएँ हो सकती हैं। अधिक सोचने से मानसिक थकान आती है। साफ़-सुथरा खान-पान और नियमित दिनचर्या रखें।"),
        ("मानसिक स्थिति एवं स्वभाव", "आप चतुर, जिज्ञासु और व्यावहारिक बन जाते हैं। दिमाग हर समय सक्रिय रहता है। कभी-कभी निर्णय लेने में उलझन और अति-विश्लेषण की आदत परेशान कर सकती है।"),
        ("सावधानियाँ", "झूठ, चालाकी, गलत दस्तावेज़ और अधूरी जानकारी पर किए गए सौदे नुकसान कराते हैं। अफ़वाहों पर भरोसा न करें। एक साथ बहुत सारे काम शुरू करके अधूरे न छोड़ें।"),
        ("उपाय", "बुधवार को गणेशजी या विष्णुजी की पूजा करें और 'ॐ बुं बुधाय नमः' का जाप करें। हरे मूँग, हरी सब्ज़ी या हरे वस्त्र का दान करें। गाय को हरा चारा खिलाएँ। विद्यार्थियों और ज़रूरतमंदों को पुस्तकें दें।"),
    ],
    "Guru": [
        ("दशा का सामान्य स्वरूप", "गुरु की महादशा 16 वर्ष की होती है और इसे सबसे शुभ दशाओं में गिना जाता है। गुरु ज्ञान, धर्म, संतान, गुरु-शिक्षा और समृद्धि का कारक है। इस काल में जीवन में विस्तार होता है, यानी ज्ञान, धन, सम्मान और परिवार तीनों बढ़ते हैं। बलवान गुरु बड़ी सफलता देता है; कमज़ोर या पीड़ित गुरु अति-आत्मविश्वास, मोटापा और अवसरों की हानि कराता है।"),
        ("करियर एवं व्यवसाय", "शिक्षण, कानून, न्याय, वित्त-बैंकिंग, परामर्श, धर्म-अध्यात्म, प्रशासन और उच्च पदों पर सफलता मिलती है। गुरुजनों और वरिष्ठों का मार्गदर्शन मिलता है। उच्च शिक्षा, डिग्री और विदेश-संबंधी अवसर बनते हैं। आपकी सलाह का समाज में सम्मान होता है।"),
        ("धन एवं आर्थिक स्थिति", "धन के स्थायी स्रोत बनते हैं और संपत्ति बढ़ती है। निवेश, बचत और परिवार की आर्थिक स्थिति मज़बूत होती है। दान और शुभ कार्यों पर खर्च होता है। परंतु अति-उदारता या बिना जाँचे किसी पर भरोसा करना नुकसान दे सकता है।"),
        ("परिवार, विवाह एवं संबंध", "विवाह, संतान-प्राप्ति और परिवार में शुभ कार्य (मांगलिक आयोजन) होने की संभावना रहती है। जीवनसाथी से संबंध मधुर होते हैं। संतान की शिक्षा और प्रगति से सुख मिलता है। बुज़ुर्गों और गुरुओं का आशीर्वाद मिलता है।"),
        ("स्वास्थ्य", "यकृत (लिवर), चर्बी, कोलेस्ट्रॉल, मधुमेह (शुगर) और मोटापे पर ध्यान दें। सुखद जीवन-शैली में अधिक खान-पान से वज़न बढ़ सकता है। संतुलित आहार और सैर लाभकारी रहती है।"),
        ("मानसिक स्थिति एवं स्वभाव", "आप शांत, आशावादी, धार्मिक और उदार बनते हैं। जीवन के प्रति दृष्टिकोण व्यापक हो जाता है। ज्ञान-प्राप्ति और सेवा की इच्छा बढ़ती है।"),
        ("सावधानियाँ", "अहंकार, अति-आत्मविश्वास, आलस्य और उपदेश देने की अधिक आदत से बचें। सब कुछ अच्छा चलने पर भी मेहनत और विवेक बनाए रखें। गुरु का अपमान न करें।"),
        ("उपाय", "गुरुवार को विष्णुजी की पूजा करें और 'ॐ बृं बृहस्पतये नमः' का जाप करें। पीले वस्त्र, चने की दाल, हल्दी या केले का दान करें। गुरुजनों का सम्मान करें और ज़रूरतमंद विद्यार्थियों की मदद करें।"),
    ],
    "Shukra": [
        ("दशा का सामान्य स्वरूप", "शुक्र की महादशा 20 वर्ष की सबसे लंबी दशा है। शुक्र प्रेम, सुख-सुविधा, कला, सौंदर्य, वाहन और वैवाहिक जीवन का कारक है। इस काल में जीवन भौतिक सुख, आकर्षण और आनंद की ओर झुकता है। बलवान शुक्र वैभव, प्रेम और कलात्मक सफलता देता है। कमज़ोर या पीड़ित शुक्र भोग-विलास की अति, संबंधों की उलझन और खर्च बढ़ाता है।"),
        ("करियर एवं व्यवसाय", "कला, संगीत, फ़िल्म-मीडिया, फ़ैशन, डिज़ाइन, होटल, ब्यूटी, लक्ज़री सामान, वाहन, ज्वेलरी और कॉस्मेटिक्स के क्षेत्र में अच्छी सफलता मिलती है। जनसंपर्क और आकर्षण से काम बनते हैं। सहयोगात्मक और रचनात्मक भूमिकाएँ आपको आगे बढ़ाती हैं।"),
        ("धन एवं आर्थिक स्थिति", "आय अच्छी होती है और सुख-सुविधाओं पर खर्च भी बढ़ता है। घर, वाहन और गहनों की खरीद संभव है। खर्च पर नियंत्रण न रखा जाए तो बचत कम रह सकती है। दिखावे में पैसा न उड़ाएँ।"),
        ("परिवार, विवाह एवं संबंध", "प्रेम और विवाह के लिए यह दशा बहुत महत्वपूर्ण है। रिश्ते बनते हैं और वैवाहिक सुख मिलता है। जीवनसाथी का सहयोग मिलता है। यदि शुक्र पीड़ित है तो संबंधों में आकर्षण की अधिकता, ग़लतफ़हमी या विश्वासघात के प्रश्न उठ सकते हैं, इसलिए निष्ठा और मर्यादा का पालन करें।"),
        ("स्वास्थ्य", "किडनी, मूत्र-संबंधी विषय, हार्मोन, शुगर, गला और त्वचा पर ध्यान दें। अधिक मीठा और भोग-विलास वाली जीवन-शैली स्वास्थ्य बिगाड़ सकती है। संतुलित आहार और नियमित दिनचर्या रखें।"),
        ("मानसिक स्थिति एवं स्वभाव", "आप रोमांटिक, सौंदर्य-प्रेमी और सुख-प्रिय हो जाते हैं। शांति और आराम की इच्छा बढ़ती है। कभी-कभी आलस्य और सुविधा के प्रति अत्यधिक झुकाव भी आ जाता है।"),
        ("सावधानियाँ", "भोग-विलास, अनैतिक संबंध, फ़िज़ूलखर्ची और नशे से बचें। रिश्तों में ईमानदारी बनाए रखें। केवल दिखावे या आकर्षण के आधार पर निर्णय न लें।"),
        ("उपाय", "शुक्रवार को लक्ष्मीजी की पूजा करें और 'ॐ शुं शुक्राय नमः' का जाप करें। सफेद वस्त्र, चावल, दही या इत्र का दान करें। जीवनसाथी और महिलाओं का सम्मान करें। घर में स्वच्छता और सुगंध बनाए रखें।"),
    ],
    "Shani": [
        ("दशा का सामान्य स्वरूप", "शनि की महादशा 19 वर्ष की होती है। शनि कर्म, अनुशासन, देरी, न्याय और मेहनत का कारक है। इस काल में जीवन परिश्रम और परीक्षा का होता है। परिणाम देर से मिलते हैं, पर टिकाऊ होते हैं। बलवान शनि बड़ी स्थिरता, पद और धन देता है; पीड़ित शनि रुकावट, अकेलापन और कठिनाई बढ़ाता है।"),
        ("करियर एवं व्यवसाय", "उद्योग, निर्माण, खेती, खनन, लोहा-मशीनरी, कानून, सेवा-क्षेत्र और बड़े संगठनों में धीरे-धीरे पर पक्की तरक्की मिलती है। लगातार मेहनत, अनुशासन और धैर्य से बड़ा मुकाम हासिल होता है। शुरुआत में संघर्ष और देरी हो सकती है, पर समय के साथ स्थिति बहुत मज़बूत होती है।"),
        ("धन एवं आर्थिक स्थिति", "धन देर से, पर स्थायी रूप से बनता है। संयम से खर्च करने और बचत करने की आदत विकसित होती है। संपत्ति और भूमि में दीर्घकालिक निवेश लाभ देता है। जल्दी अमीर बनने वाली योजनाओं से दूर रहें।"),
        ("परिवार, विवाह एवं संबंध", "रिश्तों में गंभीरता आती है। विवाह में देरी या जीवनसाथी से कुछ दूरी महसूस हो सकती है। पर यदि संबंध निष्ठा और ज़िम्मेदारी से निभाए जाएँ तो वे बहुत टिकाऊ बनते हैं। बुज़ुर्गों और ज़रूरतमंदों की सेवा से पुण्य मिलता है।"),
        ("स्वास्थ्य", "जोड़ों का दर्द, वात, कमर-घुटने, दाँत, हड्डियाँ, थकान और अवसाद जैसी समस्याओं पर ध्यान दें। नियमित व्यायाम, गर्म भोजन और समय पर नींद लें। लंबे समय की बीमारियों का नियमित इलाज कराएँ।"),
        ("मानसिक स्थिति एवं स्वभाव", "आप गंभीर, यथार्थवादी और अंतर्मुखी हो जाते हैं। कभी अकेलेपन और निराशा का भाव आता है। इसी काल में सबसे बड़ी परिपक्वता और आत्म-अनुशासन विकसित होता है।"),
        ("सावधानियाँ", "आलस्य, निराशा, अनैतिक तरीके और दूसरों का शोषण करने से बचें, क्योंकि शनि कर्मों का हिसाब सख़्ती से करता है। मज़दूरों, कर्मचारियों और बुज़ुर्गों के साथ अच्छा व्यवहार रखें।"),
        ("उपाय", "शनिवार को शनिदेव या हनुमानजी की पूजा करें और 'ॐ शं शनैश्चराय नमः' का जाप करें। सरसों का तेल, काले तिल, काला वस्त्र या लोहे का दान करें। पीपल के नीचे दीपक जलाएँ। गरीबों और बुज़ुर्गों की सेवा करें।"),
    ],
    "Rahu": [
        ("दशा का सामान्य स्वरूप", "राहु की महादशा 18 वर्ष की होती है। राहु छाया ग्रह है जो अचानक बदलाव, महत्वाकांक्षा, विदेश और आधुनिक तकनीक का कारक है। इस काल में जीवन में अप्रत्याशित घटनाएँ होती हैं और व्यक्ति लीक से हटकर सोचता है। राहु जिस राशि और भाव में बैठा होता है, उसके स्वामी के अनुसार फल देता है। शुभ राहु अचानक बड़ा लाभ देता है, जबकि अशुभ राहु भ्रम और उलझनें बढ़ाता है।"),
        ("करियर एवं व्यवसाय", "विदेशी व्यापार, IT-सॉफ्टवेयर, इलेक्ट्रॉनिक्स, राजनीति, मीडिया, शोध, आयात-निर्यात और आधुनिक तकनीकी क्षेत्रों में तेज़ सफलता संभव है। विदेश या दूर के स्थान पर बसने के अवसर बनते हैं। सफलता तेज़ी से आती है, पर उसे टिकाए रखना चुनौती हो सकता है।"),
        ("धन एवं आर्थिक स्थिति", "अचानक धन-लाभ और अचानक हानि दोनों की संभावना रहती है। विदेशी स्रोतों या नई तकनीक से आय मिल सकती है। सट्टा, जुआ और जोखिम भरे निवेश से बचें। किसी भी लेन-देन में पारदर्शिता रखें।"),
        ("परिवार, विवाह एवं संबंध", "अंतर-जातीय या अलग पृष्ठभूमि वाले संबंधों की संभावना रहती है। पारिवारिक ग़लतफ़हमियाँ और भ्रम हो सकते हैं। रिश्तों में स्पष्टता और ईमानदारी रखना ज़रूरी है। परिवार से दूरी या विदेश-प्रवास की स्थिति बन सकती है।"),
        ("स्वास्थ्य", "तनाव, घबराहट, एलर्जी, त्वचा, नींद की समस्या और अज्ञात कारणों वाले रोग हो सकते हैं। नशा और अनियमित जीवन-शैली से दूर रहें। योग, ध्यान और नियमित दिनचर्या बहुत सहायक हैं।"),
        ("मानसिक स्थिति एवं स्वभाव", "आप महत्वाकांक्षी, बेचैन और कुछ नया करने को उत्सुक रहते हैं। कभी भ्रम, शंका और असुरक्षा भी महसूस होती है। मन की स्थिरता के लिए साधना और सादगी ज़रूरी है।"),
        ("सावधानियाँ", "धोखा, झूठ, शॉर्टकट, नशा और अनैतिक तरीकों से दूर रहें। अनजान लोगों पर आँख मूँदकर भरोसा न करें। किसी भी बड़े वादे या योजना की अच्छी तरह जाँच करें।"),
        ("उपाय", "शनिवार को दुर्गाजी या भैरवजी की पूजा करें और 'ॐ रां राहवे नमः' का जाप करें। काले तिल, नीले वस्त्र या सरसों के तेल का दान करें। सफ़ाई-कर्मियों और ज़रूरतमंदों की मदद करें। नशे का पूर्ण त्याग इस दशा का सबसे बड़ा उपाय है।"),
    ],
    "Ketu": [
        ("दशा का सामान्य स्वरूप", "केतु की महादशा 7 वर्ष की होती है। केतु वैराग्य, अध्यात्म, रहस्य और पिछले कर्मों का कारक है। इस काल में सांसारिक चीज़ों से मन हटने लगता है और आत्म-चिंतन बढ़ता है। अशुभ केतु अलगाव, भ्रम और अचानक रुकावटें देता है, जबकि शुभ केतु गहरी अंतर्दृष्टि, शोध और आध्यात्मिक उन्नति देता है।"),
        ("करियर एवं व्यवसाय", "शोध, ज्योतिष, तंत्र-मंत्र, चिकित्सा, तकनीकी और सॉफ्टवेयर, आध्यात्मिक क्षेत्र और पर्दे के पीछे वाले काम अनुकूल हैं। करियर में अचानक बदलाव या नौकरी छोड़ने की इच्छा हो सकती है। नाम-शोहरत से अधिक गहराई और ज्ञान के कामों में सफलता मिलती है।"),
        ("धन एवं आर्थिक स्थिति", "धन के प्रति उदासीनता बढ़ सकती है। अचानक खर्च या अप्रत्याशित हानि संभव है, इसलिए बचत और योजना पर ध्यान दें। गुप्त विषयों, शोध या सलाह से आय हो सकती है। अनावश्यक त्याग या लापरवाही से बचें।"),
        ("परिवार, विवाह एवं संबंध", "रिश्तों में दूरी या अलगाव की भावना महसूस हो सकती है। परिवार के लोग आपको समझ नहीं पा रहे, ऐसा लग सकता है। संबंधों में संवाद बनाए रखें और अपने भावों को समझाएँ। जीवनसाथी को समय और ध्यान दें।"),
        ("स्वास्थ्य", "पेट, त्वचा, पाचन, तंत्रिका-तंत्र और अज्ञात कारणों वाली बीमारियों पर ध्यान दें। दुर्घटना और चोट से सावधानी रखें। ध्यान और योग मन-शरीर दोनों को संतुलित करते हैं।"),
        ("मानसिक स्थिति एवं स्वभाव", "आप अंतर्मुखी, चिंतनशील और संसार से कुछ विरक्त हो जाते हैं। अकेले रहने की इच्छा बढ़ती है। अध्यात्म, साधना और अंतर्ज्ञान की क्षमता प्रबल होती है।"),
        ("सावधानियाँ", "भ्रम, अलगाव, अनावश्यक त्याग और जल्दबाज़ी में नौकरी या संबंध छोड़ने से बचें। नशे और गलत संगति से दूर रहें। किसी की बातों में आकर बड़े निर्णय न लें।"),
        ("उपाय", "मंगलवार या शनिवार को गणेशजी या भैरवजी की पूजा करें और 'ॐ कें केतवे नमः' का जाप करें। कुत्तों को रोटी खिलाएँ, कंबल या तिल का दान करें। ध्यान और मौन साधना करें। गुरु या किसी वरिष्ठ मार्गदर्शक का आशीर्वाद लें।"),
    ],
}

# अंतर्दशा में उप-स्वामी ग्रह का सामान्य फल
AD_DETAIL = {
    "Surya": [
        ("सामान्य फल", "सूर्य की अंतर्दशा में आत्मविश्वास, मान-सम्मान और अधिकार की भावना बढ़ती है। सरकारी कामों, अधिकारियों से मुलाकात और पिता से संबंधित विषय सक्रिय होते हैं। यह अवधि अपनी पहचान और स्थिति मज़बूत करने का अवसर देती है।"),
        ("करियर एवं धन", "पद, प्रमोशन या ज़िम्मेदारी बढ़ने की संभावना रहती है। सरकारी लाभ और सम्मान मिल सकता है। परंतु अहंकार के कारण सहकर्मियों से तनाव भी हो सकता है।"),
        ("संबंध एवं परिवार", "पिता के स्वास्थ्य और संबंधों पर ध्यान देना पड़ता है। जीवनसाथी से बातचीत में नरमी रखें।"),
        ("स्वास्थ्य", "सिरदर्द, आँखों, हृदय और गर्मी से जुड़ी परेशानियों का ध्यान रखें।"),
        ("उपाय", "रोज़ सूर्य को जल दें और रविवार को गुड़ या गेहूँ का दान करें।"),
    ],
    "Chandra": [
        ("सामान्य फल", "चंद्र की अंतर्दशा में मन भावनात्मक, कल्पनाशील और संवेदनशील रहता है। घर, माता और मानसिक सुख से जुड़े विषय प्रमुख होते हैं। यात्राएँ और जनता से संपर्क बढ़ते हैं।"),
        ("करियर एवं धन", "जन-संपर्क, कला, लेखन, यात्रा और तरल पदार्थ से जुड़े कामों में लाभ मिलता है। आय में थोड़ा उतार-चढ़ाव रह सकता है।"),
        ("संबंध एवं परिवार", "माता का सहयोग मिलता है। प्रेम और पारिवारिक संबंधों में भावनात्मक निकटता बढ़ती है, पर छोटी बातों पर नाराज़गी भी हो सकती है।"),
        ("स्वास्थ्य", "नींद, मानसिक तनाव, सर्दी-कफ और जल से जुड़ी समस्याओं पर ध्यान दें।"),
        ("उपाय", "सोमवार को शिवजी का अभिषेक करें और दूध या चावल का दान करें।"),
    ],
    "Mangal": [
        ("सामान्य फल", "मंगल की अंतर्दशा में ऊर्जा, साहस और कार्य-शक्ति बढ़ती है। नई शुरुआत, प्रतियोगिता और भूमि-संपत्ति से जुड़े कार्य सक्रिय होते हैं। यह अवधि मेहनत और पराक्रम का फल देती है।"),
        ("करियर एवं धन", "तकनीकी, निर्माण, खेल, सुरक्षा और रियल एस्टेट में सफलता मिलती है। जोखिम लेने की प्रवृत्ति बढ़ती है, इसलिए निवेश में सावधानी रखें।"),
        ("संबंध एवं परिवार", "भाइयों से संबंध मुख्य रहते हैं। स्वभाव में तेज़ी के कारण जीवनसाथी या मित्रों से टकराव हो सकता है।"),
        ("स्वास्थ्य", "चोट, दुर्घटना, रक्तचाप, एसिडिटी और बुखार से बचाव रखें।"),
        ("उपाय", "मंगलवार को हनुमान चालीसा पढ़ें और लाल मसूर का दान करें।"),
    ],
    "Budh": [
        ("सामान्य फल", "बुध की अंतर्दशा में बुद्धि, बातचीत और व्यापारिक कुशलता चमकती है। पढ़ाई, लेखन, अनुबंध और संचार के काम में अच्छी प्रगति होती है। नए संपर्क और मित्र बनते हैं।"),
        ("करियर एवं धन", "व्यापार, बैंकिंग, IT और परामर्श से लाभ मिलता है। छोटे सौदों और कई स्रोतों से आय बढ़ती है। दस्तावेज़ों की जाँच ज़रूर करें।"),
        ("संबंध एवं परिवार", "भाई-बहन, मित्र और रिश्तेदारों से मेल-जोल बढ़ता है। अधिक बोलने से ग़लतफ़हमी हो सकती है।"),
        ("स्वास्थ्य", "त्वचा, नसें, पेट की गैस, गला और घबराहट पर ध्यान दें।"),
        ("उपाय", "बुधवार को गणेशजी की पूजा करें और हरे मूँग का दान करें।"),
    ],
    "Guru": [
        ("सामान्य फल", "गुरु की अंतर्दशा में ज्ञान, धर्म, सम्मान और समृद्धि बढ़ती है। शुभ कार्य, शिक्षा, संतान और गुरुजनों के आशीर्वाद से जुड़े सकारात्मक विषय सामने आते हैं। यह अवधि सुकून और विस्तार देती है।"),
        ("करियर एवं धन", "शिक्षण, कानून, वित्त और सलाह के क्षेत्र में प्रगति होती है। धन-संचय और निवेश के अवसर बनते हैं। वरिष्ठों का मार्गदर्शन मिलता है।"),
        ("संबंध एवं परिवार", "विवाह, संतान और परिवार में शुभ आयोजन संभव हैं। जीवनसाथी से संबंध मधुर रहते हैं।"),
        ("स्वास्थ्य", "लिवर, वज़न, शुगर और कोलेस्ट्रॉल का ध्यान रखें।"),
        ("उपाय", "गुरुवार को विष्णुजी की पूजा करें और पीले वस्त्र या चने की दाल का दान करें।"),
    ],
    "Shukra": [
        ("सामान्य फल", "शुक्र की अंतर्दशा में सुख-सुविधा, प्रेम, कला और आकर्षण बढ़ते हैं। घर, वाहन, आभूषण और मनोरंजन से जुड़े सुख मिलते हैं। रिश्तों में मधुरता आती है।"),
        ("करियर एवं धन", "कला, मीडिया, फ़ैशन, होटल और लक्ज़री क्षेत्र में लाभ मिलता है। आय के साथ खर्च भी बढ़ता है, इसलिए संतुलन रखें।"),
        ("संबंध एवं परिवार", "प्रेम और विवाह के योग बनते हैं। जीवनसाथी का सहयोग और सुख मिलता है। मर्यादा और निष्ठा बनाए रखना ज़रूरी है।"),
        ("स्वास्थ्य", "किडनी, हार्मोन, शुगर और गले पर ध्यान दें। अधिक भोग-विलास से बचें।"),
        ("उपाय", "शुक्रवार को लक्ष्मीजी की पूजा करें और सफेद वस्त्र या चावल का दान करें।"),
    ],
    "Shani": [
        ("सामान्य फल", "शनि की अंतर्दशा में मेहनत, ज़िम्मेदारी और देरी का अनुभव होता है। कार्य धीमे चलते हैं, पर अनुशासन से स्थायी परिणाम मिलते हैं। यह अवधि परिपक्वता और धैर्य सिखाती है।"),
        ("करियर एवं धन", "कठिन परिश्रम से उद्योग, खेती, निर्माण और सेवा के क्षेत्र में प्रगति होती है। धन देर से पर स्थिर रूप से आता है। बचत की आदत डालें।"),
        ("संबंध एवं परिवार", "रिश्तों में गंभीरता और कभी-कभी दूरी रहती है। बुज़ुर्गों की सेवा और ज़िम्मेदारियाँ बढ़ती हैं।"),
        ("स्वास्थ्य", "जोड़ों, वात, कमर, दाँत और थकान पर ध्यान दें।"),
        ("उपाय", "शनिवार को शनिदेव की पूजा करें और काले तिल या सरसों के तेल का दान करें।"),
    ],
    "Rahu": [
        ("सामान्य फल", "राहु की अंतर्दशा में अचानक बदलाव, भ्रम और बड़ी महत्वाकांक्षाएँ सामने आती हैं। विदेश, तकनीक और असामान्य अवसर बनते हैं। इस अवधि में निर्णय सोच-समझकर लें।"),
        ("करियर एवं धन", "विदेशी संपर्क, IT और आधुनिक क्षेत्रों में अप्रत्याशित लाभ हो सकता है। साथ ही अचानक हानि का जोखिम भी रहता है। सट्टे से दूर रहें।"),
        ("संबंध एवं परिवार", "रिश्तों में ग़लतफ़हमियाँ और अस्पष्टता आ सकती है। नए या असामान्य संबंध बन सकते हैं।"),
        ("स्वास्थ्य", "तनाव, घबराहट, एलर्जी और नींद की समस्या का ध्यान रखें।"),
        ("उपाय", "शनिवार को दुर्गाजी की पूजा करें और काले तिल का दान करें। नशे से पूरी तरह दूर रहें।"),
    ],
    "Ketu": [
        ("सामान्य फल", "केतु की अंतर्दशा में मन अंतर्मुखी और विरक्त होता है। अध्यात्म, शोध और आत्म-चिंतन के लिए यह अनुकूल समय है। अचानक रुकावटें या अलगाव का अनुभव भी हो सकता है।"),
        ("करियर एवं धन", "शोध, तकनीकी और आध्यात्मिक कामों में सफलता मिलती है। धन के प्रति उदासीनता बढ़ती है, इसलिए बचत पर ध्यान दें।"),
        ("संबंध एवं परिवार", "रिश्तों में दूरी का भाव आ सकता है। संवाद बनाए रखें और अपनों को समय दें।"),
        ("स्वास्थ्य", "पेट, त्वचा और तंत्रिका-तंत्र का ध्यान रखें। चोट और दुर्घटना से सावधानी बरतें।"),
        ("उपाय", "गणेशजी की पूजा करें, कुत्तों को रोटी खिलाएँ और ध्यान का अभ्यास करें।"),
    ],
}

REL_TEXT = {
    "friend": "महादशा-स्वामी और अंतर्दशा-स्वामी आपस में **मित्र** हैं। इसलिए यह अंतर्दशा आम तौर पर सहयोगी रहती है, महादशा के शुभ फल बढ़ते हैं और काम अपेक्षाकृत सहजता से आगे बढ़ते हैं।",
    "enemy": "महादशा-स्वामी और अंतर्दशा-स्वामी आपस में **शत्रु** भाव रखते हैं। इसलिए इस अंतर्दशा में आंतरिक खींचतान, विरोधाभासी परिस्थितियाँ और देरी देखने को मिल सकती हैं। धैर्य और संयम से चलने पर नुकसान कम होता है।",
    "neutral": "महादशा-स्वामी और अंतर्दशा-स्वामी आपस में **सम (न मित्र, न शत्रु)** हैं। इसलिए फल मिश्रित रहते हैं, यानी परिणाम काफ़ी हद तक आपकी मेहनत और दोनों ग्रहों की कुंडली में स्थिति पर निर्भर करते हैं।",
}


def planet_relation(a, b):
    if b in NAT_FRIENDS.get(a, []):
        return "friend"
    if b in NAT_ENEMIES.get(a, []):
        return "enemy"
    return "neutral"


def planet_context(p, r):
    """Chart-specific facts about a dasha lord: house, dignity, lordships."""
    asc, sign_of, houses = r["asc_sign"], r["sign_of"], r["houses"]
    out = []
    h, s = houses[p], sign_of[p]
    out.append(f"{GRAHA_HI[p]} आपकी कुंडली में **{SIGNS[s]} ({SIGNS_HI[s]}) राशि** और **{h}वें भाव** में स्थित है।")

    if p in EXALT_ALL:
        ex = EXALT_ALL[p]
        own = OWN_SIGNS.get(p, []) + EXTRA_OWN.get(p, [])
        if s == ex:
            out.append(f"{GRAHA_HI[p]} यहाँ **उच्च राशि** में है, इसलिए इसका फल बहुत बलवान और शुभ रहने की संभावना है।")
        elif s == (ex + 6) % 12:
            out.append(f"{GRAHA_HI[p]} यहाँ **नीच राशि** में है, इसलिए इसके शुभ फल कमज़ोर पड़ सकते हैं और इसके कारक विषयों में अतिरिक्त मेहनत व उपाय ज़रूरी हैं।")
        elif s in own:
            out.append(f"{GRAHA_HI[p]} यहाँ **स्वराशि** में है, इसलिए यह मज़बूत और आत्मविश्वास से फल देने वाला ग्रह है।")
        else:
            out.append(f"{GRAHA_HI[p]} यहाँ सामान्य राशि में है, अतः इसका फल भाव, दृष्टि और अन्य ग्रहों के संबंध पर निर्भर करेगा।")

    if p in ("Rahu", "Ketu"):
        disp = RASHI_LORDS[s]
        out.append(f"राहु-केतु जिस राशि में बैठे होते हैं उसके स्वामी के अनुसार फल देते हैं। यहाँ {GRAHA_HI[p]} का राशि-स्वामी **{GRAHA_HI[disp]}** है, जो {houses[disp]}वें भाव में है। इसलिए इस दशा में {HOUSE_THEME[houses[disp]]} से जुड़े फल विशेष रूप से दिखाई देंगे।")
    else:
        owned = [x for x in range(1, 13) if RASHI_LORDS[(asc + x - 1) % 12] == p]
        if owned:
            themes = "; ".join(f"{x}वें भाव ({HOUSE_THEME[x]})" for x in owned)
            out.append(f"आपके लग्न के अनुसार {GRAHA_HI[p]} **{' और '.join(str(x) + 'वें' for x in owned)} भाव का स्वामी** है। इसलिए इसकी दशा में {themes} से जुड़े विषय सक्रिय होंगे।")
            if any(x in (6, 8, 12) for x in owned) and not any(x in (1, 4, 5, 7, 9, 10) for x in owned):
                out.append("दुःस्थान (6, 8, 12) का स्वामी होने से इसके फल मिश्रित हो सकते हैं, इसलिए स्वास्थ्य, खर्च और संघर्ष के मामलों में अतिरिक्त सावधानी रखें।")
            elif any(x in (1, 5, 9) for x in owned):
                out.append("त्रिकोण (1, 5, 9) का स्वामी होने से यह ग्रह भाग्य और शुभ फल देने वाला माना जाता है।")
            elif any(x in (4, 7, 10) for x in owned):
                out.append("केंद्र (4, 7, 10) का स्वामी होने से यह ग्रह जीवन में स्थिरता और कर्म-फल देता है।")
    return out


def md_reading(md, r):
    """Long reading of a mahadasha → list of (title, text)."""
    blocks = [("आपकी कुंडली में दशानाथ की स्थिति", "\n\n".join(planet_context(md, r))),
              ("भाव के अनुसार फल", HOUSE_EFFECT[r["houses"][md]])]
    blocks += MD_DETAIL[md]
    return blocks


def ad_reading(md, ad, r):
    """Long reading of an antardasha inside a mahadasha → list of (title, text)."""
    houses = r["houses"]
    blocks = []
    rel = planet_relation(md, ad)
    d = (houses[ad] - houses[md]) % 12 + 1
    if d in (6, 8, 12):
        pos = (f"{GRAHA_HI[md]} (महादशा) {houses[md]}वें भाव में और {GRAHA_HI[ad]} (अंतर्दशा) {houses[ad]}वें भाव में है। "
               f"दोनों के बीच {d}वाँ संबंध बनता है, जो शास्त्रों में कठिन माना जाता है। इसलिए इस अंतर्दशा में मतभेद, देरी या अप्रत्याशित बाधाएँ आ सकती हैं।")
    elif d in (1, 4, 5, 7, 9, 10):
        pos = (f"{GRAHA_HI[md]} (महादशा) {houses[md]}वें भाव में और {GRAHA_HI[ad]} (अंतर्दशा) {houses[ad]}वें भाव में है। "
               f"दोनों के बीच {d}वाँ संबंध बनता है, जो सहयोगी और शुभ माना जाता है। इसलिए दोनों ग्रह मिलकर अच्छे परिणाम देते हैं।")
    else:
        pos = (f"{GRAHA_HI[md]} (महादशा) {houses[md]}वें भाव में और {GRAHA_HI[ad]} (अंतर्दशा) {houses[ad]}वें भाव में है। "
               f"दोनों के बीच {d}वाँ संबंध बनता है, जिसका फल मिश्रित रहता है।")
    blocks.append(("महादशा और अंतर्दशा का आपसी संबंध", REL_TEXT[rel] + "\n\n" + pos))
    blocks.append((f"अंतर्दशा-स्वामी {GRAHA_HI[ad]} की स्थिति", "\n\n".join(planet_context(ad, r))))
    blocks.append(("भाव के अनुसार फल", HOUSE_EFFECT[houses[ad]].replace("दशानाथ", "अंतर्दशा-स्वामी")))
    blocks += AD_DETAIL[ad]
    return blocks


def section_heading(title, icon="✨"):
    st.markdown(
        f"""
        <div style="background: linear-gradient(135deg, #4A0000 0%, #1A0000 100%);
            padding: 14px 22px; border-radius: 10px; margin-top: 28px; margin-bottom: 18px;
            border-left: 6px solid #FFD700; box-shadow: 0px 4px 12px rgba(0,0,0,0.3);">
            <h3 style="color:#FFD700; margin:0; padding:0; font-weight:700; font-size:20px;">
                {icon} {title}
            </h3>
        </div>
        """,
        unsafe_allow_html=True,
    )


PL_SHORT = {"Surya": "सू", "Chandra": "चं", "Mangal": "मं", "Budh": "बु", "Guru": "गु",
            "Shukra": "शु", "Shani": "श", "Rahu": "रा", "Ketu": "के"}

# centre of each of the 12 houses (x, y in 0..1, y upward) in a North-Indian chart
HOUSE_CENTERS = [(0.50, 0.75), (0.25, 0.917), (0.083, 0.75), (0.25, 0.50),
                 (0.083, 0.25), (0.25, 0.083), (0.50, 0.25), (0.75, 0.083),
                 (0.917, 0.25), (0.75, 0.50), (0.917, 0.75), (0.75, 0.917)]


def render_north_indian_chart(asc_sign, planet_signs, title):
    """Return the chart as an SVG string. Text is drawn by the viewer's browser,
    so Hindi and English both show correctly (no server-side font needed)."""
    W, H, S, X0, Y0 = 600, 640, 520, 40, 80

    def px(x, y):
        return X0 + x * S, Y0 + (1 - y) * S

    font = "'Noto Sans Devanagari','Noto Sans','Segoe UI',Mangal,Arial,sans-serif"
    A, B, C, D = px(0, .5), px(.5, 1), px(1, .5), px(.5, 0)
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}">',
         f'<rect width="{W}" height="{H}" rx="14" fill="#FFFDF5"/>',
         f'<text x="{W / 2}" y="46" text-anchor="middle" font-family="{font}" font-size="24" '
         f'font-weight="700" fill="#7A0000">{_esc(title)}</text>',
         f'<rect x="{X0}" y="{Y0}" width="{S}" height="{S}" fill="none" stroke="#7A0000" stroke-width="3"/>',
         f'<polygon points="{A[0]},{A[1]} {B[0]},{B[1]} {C[0]},{C[1]} {D[0]},{D[1]}" '
         f'fill="none" stroke="#7A0000" stroke-width="2.5"/>']
    for p1, p2 in ((px(0, 0), px(1, 1)), (px(0, 1), px(1, 0))):
        o.append(f'<line x1="{p1[0]}" y1="{p1[1]}" x2="{p2[0]}" y2="{p2[1]}" stroke="#7A0000" stroke-width="2.5"/>')

    for i, (cx, cy) in enumerate(HOUSE_CENTERS):
        sign_index = (asc_sign + i) % 12
        big = i in (0, 3, 6, 9)                       # the four diamond houses
        x, y = px(cx, cy)
        toks = []
        for disp in planet_signs.get(SIGNS[sign_index], []):
            base = disp.replace(" (R)", "")
            toks.append(PL_SHORT.get(base, base[:2]) + ("(व)" if "(R)" in disp else ""))
        per_row = 3 if big else 2
        rows = [" ".join(toks[k:k + per_row]) for k in range(0, len(toks), per_row)]
        num = f"{sign_index + 1}" + (" (ल)" if i == 0 else "")
        fs_num, fs_pl, lh = (20, 19, 23) if big else (16, 15, 18)
        top = y - (len(rows) * lh) / 2 - 4
        o.append(f'<text x="{x:.1f}" y="{top - 4 if rows else y + 6:.1f}" text-anchor="middle" '
                 f'font-family="{font}" font-size="{fs_num}" font-weight="700" fill="#B00020">{num}</text>')
        for k, row in enumerate(rows):
            o.append(f'<text x="{x:.1f}" y="{top + 14 + (k + 1) * lh - 6:.1f}" text-anchor="middle" '
                     f'font-family="{font}" font-size="{fs_pl}" font-weight="600" fill="#0B2A6F">{_esc(row)}</text>')
    o.append(f'<text x="{W / 2}" y="{H - 14}" text-anchor="middle" font-family="{font}" font-size="13" '
             f'fill="#555">संख्या = राशि क्रमांक (मेष=1 ... मीन=12) | (ल)=लग्न | (व)=वक्री</text>')
    o.append("</svg>")
    return "".join(o)


def show_chart(svg):
    b64 = base64.b64encode(svg.encode("utf-8")).decode()
    st.markdown(
        f'<div style="text-align:center"><img src="data:image/svg+xml;base64,{b64}" '
        f'style="width:100%;max-width:560px;"/></div>',
        unsafe_allow_html=True,
    )


def compute_report(name, dob, bt, place):
    loc = Nominatim(user_agent="jyotish_app_v15").geocode(place)
    if not loc:
        return None
    lat, lon = loc.latitude, loc.longitude

    tz_str = TimezoneFinder().timezone_at(lng=lon, lat=lat)
    if tz_str:
        aware = datetime.combine(dob, bt, tzinfo=zoneinfo.ZoneInfo(tz_str))
        utc_dt = aware.astimezone(zoneinfo.ZoneInfo("UTC")).replace(tzinfo=None)
        utc_off = aware.utcoffset().total_seconds() / 3600.0
    else:
        tz_str, utc_off = "Default +5.75", 5.75
        utc_dt = datetime.combine(dob, bt) - timedelta(hours=5, minutes=45)

    jd = swe.julday(utc_dt.year, utc_dt.month, utc_dt.day,
                    utc_dt.hour + utc_dt.minute / 60.0 + utc_dt.second / 3600.0)

    # FLG_SPEED is required to get a valid speed (retrograde detection)
    flags = swe.FLG_SWIEPH | swe.FLG_SIDEREAL | swe.FLG_SPEED

    ayan = swe.get_ayanamsa_ut(jd)
    cusps, ascmc = swe.houses(jd, lat, lon, b"P")
    asc_degree = (ascmc[0] - ayan) % 360
    asc_sign = int(asc_degree // 30)
    d9_asc = get_navamsha_sign(asc_degree)
    d10_asc = get_dashamsha_sign(asc_degree)

    rows, lons, sign_of, houses = [], {}, {}, {}
    d1_signs, d9_signs, d10_signs = {}, {}, {}

    def add_planet(pname, deg, retro):
        si = int(deg // 30)
        d9 = get_navamsha_sign(deg)
        d10 = get_dashamsha_sign(deg)
        h = ((si - asc_sign) % 12) + 1
        disp = f"{pname} (R)" if retro else pname
        lons[pname], sign_of[pname], houses[pname] = deg, si, h
        rows.append({
            "Planet": disp, "D1 Rashi": SIGNS[si], "House": f"House {h}",
            "Degree": round(deg % 30, 2),
            "Nakshatra": NAKSHATRAS[int(deg / (360 / 27))],
            "D9 Navamsha Rashi": SIGNS[d9],
            "D10 Dashamsha Rashi": SIGNS[d10],
            "Status": "Retrograde" if retro else "Direct",
        })
        d1_signs.setdefault(SIGNS[si], []).append(disp)
        d9_signs.setdefault(SIGNS[d9], []).append(disp)
        d10_signs.setdefault(SIGNS[d10], []).append(disp)

    for pname, code in PLANETS.items():
        res = swe.calc_ut(jd, code, flags)[0]
        deg, speed = res[0] % 360, res[3]
        if pname == "Rahu":
            retro = True                       # mean node is always retrograde
        elif pname in ("Surya", "Chandra"):
            retro = False
        else:
            retro = speed < 0
        add_planet(pname, deg, retro)

    add_planet("Ketu", (lons["Rahu"] + 180) % 360, True)

    # ---- Doshas
    is_manglik = houses["Mangal"] in (1, 4, 7, 8, 12)
    kalsarp = check_kaal_sarp(lons, lons["Rahu"])

    # ---- Vimshottari Dasha
    moon = lons["Chandra"]
    span = 360.0 / 27.0
    nak_idx = int(moon / span)
    balance = 1.0 - ((moon % span) / span)
    first_idx = nak_idx % 9
    first_lord = DASHA_LORDS[first_idx]
    first_full = DASHA_YEARS[first_lord]
    first_remaining = first_full * balance

    # birth moment (UTC, naive) and the *virtual* start of the first MD
    birth = utc_dt
    first_md_start = birth - timedelta(days=(first_full - first_remaining) * YEAR_DAYS)
    now = datetime.now(timezone.utc).replace(tzinfo=None)

    md_rows, active_md, active_ad = [], "", ""
    active_ad_rows = []
    md_start = first_md_start
    for i in range(10):
        lord = DASHA_LORDS[(first_idx + i) % 9]
        full = DASHA_YEARS[lord]
        md_end = md_start + timedelta(days=full * YEAR_DAYS)
        shown_start = birth if i == 0 else md_start
        is_active = md_start <= now < md_end
        if is_active:
            active_md = lord
            for ad, a_s, a_e in antardashas(lord, md_start):
                active_ad_rows.append({
                    "अंतर्दशा": ad, "प्रारंभ": a_s.strftime("%Y-%m-%d"),
                    "समाप्ति": a_e.strftime("%Y-%m-%d"),
                    "स्थिति": "🔥 सक्रिय" if a_s <= now < a_e else "-",
                })
                if a_s <= now < a_e:
                    active_ad = ad
        md_rows.append({
            "lord": lord, "start": shown_start.strftime("%Y-%m-%d"),
            "end": md_end.strftime("%Y-%m-%d"),
            "years": round(first_remaining if i == 0 else full, 2),
            "active": is_active, "true_start": md_start,
        })
        md_start = md_end

    return {
        "name": name, "place": place, "address": loc.address,
        "dob_str": dob.strftime("%d-%m-%Y") + " " + bt.strftime("%H:%M"),
        "tz_str": tz_str, "utc_off": utc_off,
        "asc_degree": asc_degree, "asc_sign": asc_sign, "d9_asc": d9_asc,
        "d10_asc": d10_asc, "moon_sign": sign_of["Chandra"],
        "rows": rows, "d1_signs": d1_signs, "d9_signs": d9_signs,
        "d10_signs": d10_signs, "lons": lons,
        "houses": houses, "is_manglik": is_manglik, "kalsarp": kalsarp,
        "md_rows": md_rows, "active_md": active_md, "active_ad": active_ad,
        "ad_rows": active_ad_rows,
        "yogas": find_yogas(sign_of, houses),
        "lagna_lord": RASHI_LORDS[asc_sign],
        "sign_of": sign_of,
        "panchang": compute_panchang(lons, dob),
        "avakahada": compute_avakahada(lons["Chandra"]),
        "sadesati": compute_sade_sati(sign_of["Chandra"]),
        "bhava": bhava_table(asc_sign, sign_of, houses),
        "career": analyze_career(asc_sign, sign_of, houses),
    }


# ---------------------------------------------------------------
# UI
# ---------------------------------------------------------------
st.set_page_config(page_title="Jyotish AI - विस्तृत महा जन्मपत्री", page_icon="🔱", layout="wide")

LANG_OPTIONS = {
    "Hindi": {
        "features": "नए फीचर", "d10": "दशमांश कुंडली (D10)",
        "transit": "वर्तमान गोचर और दैनिक संकेत", "matching": "कुंडली मिलान (Ashtakoota)",
        "chat": "AI ज्योतिष चैट", "pdf": "PDF रिपोर्ट डाउनलोड करें",
        "save": "इस कुंडली को सेव करें", "profiles": "सेव की गई कुंडलियाँ",
    },
    "Nepali": {
        "features": "नयाँ सुविधाहरू", "d10": "दशमांश कुण्डली (D10)",
        "transit": "हालको गोचर र दैनिक संकेत", "matching": "कुण्डली मिलान (Ashtakoota)",
        "chat": "AI ज्योतिष च्याट", "pdf": "PDF रिपोर्ट डाउनलोड गर्नुहोस्",
        "save": "यो कुण्डली सुरक्षित गर्नुहोस्", "profiles": "सुरक्षित कुण्डलीहरू",
    },
    "English": {
        "features": "New features", "d10": "Dashamsha chart (D10)",
        "transit": "Current transits and daily indicators", "matching": "Kundli matching (Ashtakoota)",
        "chat": "AI Jyotish Chat", "pdf": "Download PDF report",
        "save": "Save this chart", "profiles": "Saved birth charts",
    },
}
UI_LANG = st.sidebar.selectbox("Language / भाषा / भाषा", ["Hindi", "Nepali", "English"], index=0)
UI = LANG_OPTIONS[UI_LANG]

st.markdown(
    """
    <div style="text-align:center; background: linear-gradient(90deg,#3A0007 0%,#8A1C1C 50%,#3A0007 100%);
        padding:25px; border-radius:12px; border-bottom:4px solid #FFD700; margin-bottom:25px;">
        <h1 style="color:#FFD700; font-size:34px; font-weight:800; margin:0;">🔱 JYOTISH AI — अति-विस्तृत महा जन्मपत्री</h1>
        <p style="color:#FFF8DC; font-size:16px; margin-top:8px;">Comprehensive Vedic Astrology Engine | गहन विश्लेषण एवं सम्पूर्ण जीवन फलादेश</p>
    </div>
    """,
    unsafe_allow_html=True,
)

st.subheader("📋 Birth Details / जन्म विवरण दर्ज करें")
col_a, col_b = st.columns(2)
with col_a:
    name = st.text_input("Name / नाम", value="", placeholder="अपना नाम लिखें")
    gender = st.selectbox("Gender / लिंग", ["Male (पुरुष)", "Female (महिला)", "Other (अन्य)"])
    dob = st.date_input("Date of birth / जन्म तिथि", value=None, min_value=date(1900, 1, 1))
    st.write("**Birth Time / जन्म समय (AM / PM के साथ):**")
    t1, t2, t3 = st.columns(3)
    with t1:
        hour12 = st.number_input("Hour (घंटा)", min_value=1, max_value=12, value=12)
    with t2:
        minute = st.number_input("Minute (मिनट)", min_value=0, max_value=59, value=0)
    with t3:
        ampm = st.selectbox("AM / PM", ["PM (दोपहर/शाम)", "AM (सुबह/रात)"])
with col_b:
    place = st.text_input("Birth place & Country / जन्म स्थान व देश", value="",
                          placeholder="जैसे: Ghorahi Nepal, Delhi India, London UK")

if st.button("🚀 Generate Full Detailed Report / संपूर्ण विस्तृत महा-रिपोर्ट देखें", type="primary"):
    if not name or not dob or not place:
        st.warning("कृपया सभी विवरण (नाम, जन्म तिथि, समय और जन्म स्थान) भरें!")
    else:
        try:
            h24 = hour12 % 12 + (12 if "PM" in ampm else 0)
            with st.spinner("गणना हो रही है..."):
                rep = compute_report(name, dob, time(h24, int(minute)), place)
            if rep is None:
                st.error("जन्म स्थान नहीं मिल सका! कृपया स्थान और देश का नाम सही से लिखें।")
            else:
                rep["time_label"] = f"{hour12}:{int(minute):02d} {ampm[:2]}"
                rep["gender"] = gender
                st.session_state["report"] = rep   # survives reruns
        except Exception as e:
            st.error(f"गणना में त्रुटि: {e}")

# ---------------------------------------------------------------
# Saved profiles: local SQLite storage; no profile is saved without consent.
# ---------------------------------------------------------------
st.subheader(UI["profiles"])
try:
    saved_profiles = list_profiles()
except Exception as db_exc:
    saved_profiles = []
    st.caption(f"Local profile storage is unavailable: {db_exc}")

if saved_profiles:
    selected_profile = st.selectbox(
        "Choose a saved profile / सुरक्षित प्रोफाइल चुनें",
        saved_profiles,
        format_func=lambda p: f"{p[1]} — {p[2]} {p[3]} — {p[4]}",
        key="saved_profile_choice",
    )
    load_col, delete_col = st.columns(2)
    with load_col:
        if st.button("Load selected profile / प्रोफाइल खोलें"):
            try:
                rep = compute_report(
                    selected_profile[1],
                    date.fromisoformat(selected_profile[2]),
                    time.fromisoformat(selected_profile[3]),
                    selected_profile[4],
                )
                if rep is None:
                    st.error("Saved birth place could not be found. / जन्म स्थान नहीं मिला।")
                else:
                    rep["time_label"] = time.fromisoformat(selected_profile[3]).strftime("%I:%M %p")
                    rep["gender"] = selected_profile[5]
                    st.session_state["report"] = rep
                    st.rerun()
            except Exception as load_exc:
                st.error(f"Could not load profile: {load_exc}")
    with delete_col:
        if st.button("Delete selected profile / प्रोफाइल हटाएँ"):
            delete_profile(selected_profile[0])
            st.success("Profile deleted / प्रोफाइल हटा दी गई।")
            st.rerun()
else:
    st.caption("No saved profiles yet. Save a generated chart below. Profiles are stored in a local SQLite file.")

# ---------------------------------------------------------------
# Render (outside the button block so it persists across reruns)
# ---------------------------------------------------------------
r = st.session_state.get("report")
if r:
    st.success(f"📍 स्थान: **{r['address']}** | टाइमज़ोन: **{r['tz_str']} (UTC {r['utc_off']:+.2f})** "
               f"| समय: **{r['time_label']}**")

    section_heading("1. मूल विवरण, पंचांग एवं अवकहड़ा (Basic Details)", "📜")
    pc, av = r["panchang"], r["avakahada"]
    b1, b2, b3 = st.columns(3)
    with b1:
        st.markdown("**जन्म विवरण**")
        st.dataframe([
            {"विवरण": "नाम", "मान": r["name"]},
            {"विवरण": "जन्म तिथि/समय", "मान": r["dob_str"]},
            {"विवरण": "जन्म स्थान", "मान": r["place"]},
            {"विवरण": "लग्न", "मान": f"{SIGNS[r['asc_sign']]} ({SIGNS_HI[r['asc_sign']]})"},
            {"विवरण": "चंद्र राशि", "मान": f"{SIGNS[r['moon_sign']]} ({SIGNS_HI[r['moon_sign']]})"},
            {"विवरण": "सूर्य राशि", "मान": f"{SIGNS[r['sign_of']['Surya']]} ({SIGNS_HI[r['sign_of']['Surya']]})"},
            {"विवरण": "लग्नेश", "मान": r["lagna_lord"]},
            {"विवरण": "अयनांश", "मान": "लाहिरी (चित्रपक्ष)"},
        ], hide_index=True, use_container_width=True)
    with b2:
        st.markdown("**पंचांग (जन्म के समय)**")
        st.dataframe([
            {"विवरण": "वार", "मान": pc["vara"]},
            {"विवरण": "तिथि", "मान": pc["tithi"]},
            {"विवरण": "नक्षत्र", "मान": f"{pc['nakshatra']} (चरण {pc['pada']})"},
            {"विवरण": "योग", "मान": pc["yoga"]},
            {"विवरण": "करण", "मान": pc["karana"]},
        ], hide_index=True, use_container_width=True)
        st.caption("वार स्थानीय नागरिक तारीख़ से निकाला गया है; पारंपरिक सूर्योदय-आधारित वार की अलग गणना अभी शामिल नहीं है।")
    with b3:
        st.markdown("**अवकहड़ा चक्र**")
        st.dataframe([{"विवरण": k, "मान": v} for k, v in av.items()],
                     hide_index=True, use_container_width=True)

    section_heading("2. ग्रह स्थिति एवं नवमांश विवरण (Planetary Positions)", "🪐")
    st.dataframe(r["rows"], use_container_width=True)

    section_heading("3. लग्न, चंद्र एवं नवमांश कुंडली", "📊")
    c1, c2 = st.columns(2)
    with c1:
        st.write(f"**D1 लग्न:** {SIGNS[r['asc_sign']]} ({SIGNS_HI[r['asc_sign']]}) — {round(r['asc_degree'] % 30, 2)}°")
        show_chart(render_north_indian_chart(r["asc_sign"], r["d1_signs"], "D1 - जन्म कुंडली"))
    with c2:
        st.write(f"**D9 नवमांश लग्न:** {SIGNS[r['d9_asc']]} ({SIGNS_HI[r['d9_asc']]})")
        show_chart(render_north_indian_chart(r["d9_asc"], r["d9_signs"], "D9 - नवमांश कुंडली"))

    mc1, mc2 = st.columns(2)
    with mc1:
        st.write(f"**चंद्र कुंडली (चंद्र लग्न):** {SIGNS[r['moon_sign']]} ({SIGNS_HI[r['moon_sign']]})")
        show_chart(render_north_indian_chart(r["moon_sign"], r["d1_signs"], "चंद्र कुंडली"))
    with mc2:
        section_heading("4. भाव विवरण (Bhava Table)", "🏠")
        st.dataframe(r["bhava"], hide_index=True, use_container_width=True)

    section_heading("5. दोष विचार (Manglik, Kaal Sarp, Sade Sati)", "⚠️")
    d1, d2 = st.columns(2)
    with d1:
        with st.expander("🔥 मांगलिक दोष", expanded=True):
            mh = r["houses"]["Mangal"]
            if r["is_manglik"]:
                st.error(f"मंगल **{mh}वें भाव** में है, इसलिए **मांगलिक दोष** बनता है। विवाह से पूर्व कुंडली मिलान आवश्यक है।")
            else:
                st.success(f"मंगल **{mh}वें भाव** में है। मांगलिक दोष नहीं पाया गया।")
    with d2:
        with st.expander("🐍 कालसर्प दोष", expanded=True):
            if r["kalsarp"]:
                st.error("सभी सातों ग्रह राहु-केतु अक्ष के एक ही ओर हैं, इसलिए **कालसर्प दोष** बनता है। विद्वान ज्योतिषी से शांति उपाय पूछें।")
            else:
                st.success("कालसर्प दोष नहीं पाया गया।")

    ss = r["sadesati"]
    with st.expander(f"🪐 साढ़ेसाती / ढैया (वर्तमान शनि: {ss['saturn_sign']} राशि में)", expanded=True):
        if ss["status"]:
            st.error(f"वर्तमान में **{ss['status']}** चल रही है। धैर्य, अनुशासन और शनिवार को सेवा/दान लाभकारी माना जाता है।")
        else:
            st.success("वर्तमान में साढ़ेसाती या शनि ढैया नहीं है।")

    section_heading("6. महादशा एवं अंतर्दशा का विस्तृत फलादेश (Dasha Analysis)", "⏳")
    st.markdown(f"### वर्तमान दशा: **{GRAHA_HI.get(r['active_md'], r['active_md'])} महादशा — "
                f"{GRAHA_HI.get(r['active_ad'], r['active_ad'])} अंतर्दशा**")
    st.dataframe(
        [{"महादशा": m["lord"], "प्रारंभ": m["start"], "समाप्ति": m["end"],
          "अवधि (वर्ष)": m["years"], "स्थिति": "🔥 वर्तमान में सक्रिय" if m["active"] else "-"}
         for m in r["md_rows"]],
        use_container_width=True,
    )

    md_labels = [f"{GRAHA_HI[m['lord']]} महादशा ({m['start']} से {m['end']})"
                 + (" 🔥 वर्तमान" if m["active"] else "") for m in r["md_rows"]]
    default_i = next((i for i, m in enumerate(r["md_rows"]) if m["active"]), 0)
    pick = st.selectbox("कोई भी महादशा चुनकर उसका विस्तृत फल पढ़ें:", range(len(md_labels)),
                        index=default_i, format_func=lambda i: md_labels[i], key="md_pick")
    sel = r["md_rows"][pick]
    sel_md = sel["lord"]

    st.markdown(f"## 🔱 {GRAHA_HI[sel_md]} महादशा का विस्तृत फल")
    for title, text in md_reading(sel_md, r):
        st.markdown(f"#### {title}")
        st.write(text)

    st.markdown(f"## 🔹 {GRAHA_HI[sel_md]} महादशा की सभी अंतर्दशाएँ")
    now_naive = datetime.now(timezone.utc).replace(tzinfo=None)
    ad_list = antardashas(sel_md, sel["true_start"])
    st.dataframe(
        [{"अंतर्दशा": GRAHA_HI[ad], "प्रारंभ": a_s.strftime("%Y-%m-%d"),
          "समाप्ति": a_e.strftime("%Y-%m-%d"),
          "स्थिति": "🔥 सक्रिय" if a_s <= now_naive < a_e else "-"}
         for ad, a_s, a_e in ad_list],
        use_container_width=True,
    )
    st.caption("हर अंतर्दशा पर क्लिक करके उसका पूरा विस्तृत फल पढ़ें।")
    for ad, a_s, a_e in ad_list:
        is_now = a_s <= now_naive < a_e
        label = (f"{GRAHA_HI[sel_md]} - {GRAHA_HI[ad]} अंतर्दशा "
                 f"({a_s.strftime('%d-%m-%Y')} से {a_e.strftime('%d-%m-%Y')})"
                 + (" 🔥 वर्तमान" if is_now else ""))
        with st.expander(label, expanded=is_now):
            for title, text in ad_reading(sel_md, ad, r):
                st.markdown(f"**{title}**")
                st.write(text)
    st.caption("यह फलादेश कुंडली के सामान्य ग्रह-नियमों पर आधारित है। वास्तविक फल अन्य योग, दृष्टि और गोचर पर भी निर्भर करता है।")

    section_heading("7. प्रमुख योग (Yogas)", "🌟")
    if r["yogas"]:
        for yname, ydesc in r["yogas"]:
            st.success(f"**{yname}** — {ydesc}")
    else:
        st.info("कोई प्रमुख शास्त्रीय योग नहीं मिला।")

    section_heading("8. रत्न, रुद्राक्ष एवं स्वास्थ्य (Remedies & Health)", "💎")
    ll, md = r["lagna_lord"], r["active_md"]
    st.markdown(f"**लग्नेश:** {ll}")
    g1, g2 = st.columns(2)
    with g1:
        st.write(f"💎 **लग्नेश रत्न:** {GEMSTONES[ll]}")
        st.write(f"📿 **लग्नेश रुद्राक्ष:** {RUDRAKSHA[ll]}")
        st.write(f"🩺 **स्वास्थ्य ({ll}):** {HEALTH_MAP[ll]}")
    with g2:
        if md:
            st.write(f"💎 **दशानाथ ({md}) रत्न:** {GEMSTONES[md]}")
            st.write(f"📿 **दशानाथ रुद्राक्ष:** {RUDRAKSHA[md]}")
            st.write(f"🩺 **स्वास्थ्य ({md}):** {HEALTH_MAP[md]}")
    st.caption("रत्न धारण से पहले किसी योग्य ज्योतिषी से परामर्श अवश्य लें।")

    section_heading("9. प्रेम, विवाह एवं संबंध (Love, Relationship & Affair)", "❤️")
    love = analyze_love(r["asc_sign"], r["sign_of"], r["houses"], r.get("gender", "Male"))

    def show(items):
        for kind, txt in items:
            if kind == "good":
                st.success(txt)
            elif kind == "warn":
                st.warning(txt)
            else:
                st.info(txt)

    st.markdown(f"**पंचमेश:** {love['lord5']} | **सप्तमेश:** {love['lord7']} | **विवाह कारक:** {love['karaka']}")
    with st.expander("💕 प्रेम स्वभाव (Love Nature)", expanded=True):
        show(love["love"])
    with st.expander("💍 प्रेम-विवाह एवं वैवाहिक जीवन (Marriage)", expanded=True):
        show(love["marriage"])
    with st.expander("🕵️ गुप्त संबंध / अफेयर की प्रवृत्ति (Affair Tendency)", expanded=True):
        show(love["affair"])
        st.markdown(f"**कुल प्रवृत्ति स्तर: {love['affair_level']}**")
    st.caption("यह केवल कुंडली के ग्रह-योगों पर आधारित सामान्य संकेत है, निश्चित भविष्यवाणी नहीं। "
               "असल जीवन में व्यक्ति के कर्म, संस्कार और निर्णय सबसे ज़्यादा मायने रखते हैं।")

    section_heading("10. करियर एवं धन (Career & Wealth)", "💼")
    for kind, txt in r["career"]:
        (st.success if kind == "good" else st.warning if kind == "warn" else st.info)(txt)
    st.caption("सभी फल कुंडली के सामान्य ग्रह-योगों पर आधारित हैं; निर्णय सोच-समझकर और योग्य सलाह से लें।")

    # -----------------------------------------------------------
    # Additional features: D10, transits, AI chat, PDF, save profile
    # -----------------------------------------------------------
    section_heading(f"11. {UI['features']}", "🚀")

    section_heading(UI["d10"], "💼")
    st.write(f"**D10 Lagna:** {SIGNS[r['d10_asc']]} ({SIGNS_HI[r['d10_asc']]})")
    show_chart(render_north_indian_chart(r["d10_asc"], r["d10_signs"], "D10 - Dashamsha / Career Chart"))
    d10_rows = []
    for row in r["rows"]:
        d10_rows.append({
            "Planet": row["Planet"],
            "D10 Dashamsha Rashi": row["D10 Dashamsha Rashi"],
            "D1 Rashi": row["D1 Rashi"],
            "D9 Navamsha Rashi": row["D9 Navamsha Rashi"],
        })
    st.dataframe(d10_rows, use_container_width=True, hide_index=True)
    st.caption("D10 is a traditional career-related divisional chart. Interpretations are astrological beliefs, not guaranteed outcomes.")

    section_heading(UI["transit"], "🪐")
    try:
        transits = get_current_transits()
        transit_rows = []
        for pname, data in transits.items():
            house_from_moon = ((data["sign"] - r["moon_sign"]) % 12) + 1
            transit_rows.append({
                "Planet": pname,
                "Current sidereal sign": SIGNS[data["sign"]],
                "Degree in sign": round(data["longitude"] % 30, 2),
                "House from natal Moon": house_from_moon,
            })
        st.dataframe(transit_rows, use_container_width=True, hide_index=True)
        st.caption("Transit positions are calculated for the current UTC moment using Swiss Ephemeris. Daily interpretations are indicative, not certain predictions.")
    except Exception as transit_exc:
        st.warning(f"Transit calculation unavailable: {transit_exc}")

    section_heading(UI["pdf"], "📄")
    try:
        pdf_bytes = build_pdf_bytes(r)
        st.download_button(
            label=UI["pdf"],
            data=pdf_bytes,
            file_name=f"jyotish_report_{date.today().isoformat()}.pdf",
            mime="application/pdf",
            key="download_jyotish_pdf",
        )
    except Exception as pdf_exc:
        st.warning(f"PDF report could not be prepared: {pdf_exc}")

    section_heading(UI["save"], "💾")
    st.caption("Saved profiles are stored locally in jyotish_profiles.db. On hosted services, local files may not persist after redeployment unless persistent storage is configured.")
    if st.button(UI["save"], key="save_current_profile"):
        try:
            birth_dt = datetime.strptime(r["dob_str"], "%d-%m-%Y %H:%M")
            save_profile(
                r["name"], birth_dt.date(), birth_dt.time().replace(second=0, microsecond=0),
                r["place"], r.get("gender", "Other"),
            )
            st.success("Birth chart saved locally. / कुण्डली सुरक्षित भयो।")
            st.rerun()
        except Exception as save_exc:
            st.error(f"Could not save profile: {save_exc}")

    section_heading(UI["chat"], "🤖")
    st.info("AI answers require an OpenAI API key. Questions and the supplied chart summary will be sent to the configured AI service when you submit a question.")
    if "jyotish_chat" not in st.session_state:
        st.session_state["jyotish_chat"] = []
    for chat_msg in st.session_state["jyotish_chat"]:
        with st.chat_message(chat_msg["role"]):
            st.markdown(chat_msg["content"])

    user_question = st.chat_input(
        {"Hindi": "अपना ज्योतिष प्रश्न पूछें…", "Nepali": "आफ्नो ज्योतिष प्रश्न सोध्नुहोस्…", "English": "Ask an astrology question…"}[UI_LANG],
        key="jyotish_chat_input",
    )
    if user_question:
        st.session_state["jyotish_chat"].append({"role": "user", "content": user_question})
        api_key = os.environ.get("OPENAI_API_KEY", "")
        try:
            if not api_key:
                api_key = st.secrets.get("OPENAI_API_KEY", "")
        except Exception:
            api_key = api_key or ""
        if not api_key:
            answer = {
                "Hindi": "AI Chat चालू करने के लिए Streamlit secrets में OPENAI_API_KEY सेट करें। यह API key ऐप के कोड में सीधे न लिखें।",
                "Nepali": "AI Chat चलाउन Streamlit secrets मा OPENAI_API_KEY राख्नुहोस्। API key कोडमै नलेख्नुहोस्।",
                "English": "To enable AI chat, set OPENAI_API_KEY in Streamlit secrets or the environment. Do not hard-code the API key in app.py.",
            }[UI_LANG]
        else:
            try:
                with st.spinner("AI is thinking…"):
                    answer = ask_ai_jyotish(user_question, r, UI_LANG, api_key)
            except Exception as ai_exc:
                answer = f"AI service error: {ai_exc}"
        st.session_state["jyotish_chat"].append({"role": "assistant", "content": answer})
        st.rerun()


# ---------------------------------------------------------------
# Kundli matching for two people (separate from the user's own chart)
# ---------------------------------------------------------------
section_heading(UI["matching"], "💞")
st.caption({
    "Hindi": "दोनों व्यक्तियों की जन्म जानकारी दर्ज करें। यह Ashtakoota-style अनुमानित स्कोर है; अलग परंपराओं में नियम और अंक बदल सकते हैं।",
    "Nepali": "दुवै व्यक्तिको जन्म विवरण राख्नुहोस्। यो Ashtakoota-शैलीको अनुमानित स्कोर हो; परम्पराअनुसार नियम फरक हुन सक्छन्।",
    "English": "Enter both people's birth details. This is an indicative Ashtakoota-style score; scoring rules vary by tradition.",
}[UI_LANG])

with st.form("kundli_matching_form"):
    match_a, match_b = st.columns(2)
    with match_a:
        st.markdown("**Person A / व्यक्ति A**")
        match_name_a = st.text_input("Name A", value="Person A", key="match_name_a")
        match_dob_a = st.date_input("Birth date A", value=None, min_value=date(1900, 1, 1), key="match_dob_a")
        match_time_a = st.time_input("Birth time A", value=time(12, 0), key="match_time_a")
        match_place_a = st.text_input("Birth place A", key="match_place_a", placeholder="City, Country")
    with match_b:
        st.markdown("**Person B / व्यक्ति B**")
        match_name_b = st.text_input("Name B", value="Person B", key="match_name_b")
        match_dob_b = st.date_input("Birth date B", value=None, min_value=date(1900, 1, 1), key="match_dob_b")
        match_time_b = st.time_input("Birth time B", value=time(12, 0), key="match_time_b")
        match_place_b = st.text_input("Birth place B", key="match_place_b", placeholder="City, Country")
    match_submit = st.form_submit_button("Calculate compatibility / मिलान करें", type="primary")

if match_submit:
    if not all([match_dob_a, match_dob_b, match_place_a.strip(), match_place_b.strip()]):
        st.warning("Please enter both birth dates and places. / दोनों की जन्म तिथि और स्थान भरें।")
    else:
        try:
            with st.spinner("Calculating both charts…"):
                report_a = compute_report(match_name_a or "Person A", match_dob_a, match_time_a, match_place_a)
                report_b = compute_report(match_name_b or "Person B", match_dob_b, match_time_b, match_place_b)
            if not report_a or not report_b:
                st.error("One of the birth places could not be found. Please include city and country.")
            else:
                score, guna_details, nak_a, nak_b = guna_milan(report_a, report_b)
                st.session_state["matching_result"] = {
                    "score": score, "details": guna_details,
                    "name_a": match_name_a or "Person A", "name_b": match_name_b or "Person B",
                    "nak_a": NAKSHATRAS[nak_a], "nak_b": NAKSHATRAS[nak_b],
                    "moon_a": SIGNS[report_a["moon_sign"]], "moon_b": SIGNS[report_b["moon_sign"]],
                }
        except Exception as match_exc:
            st.error(f"Matching calculation error: {match_exc}")

matching_result = st.session_state.get("matching_result")
if matching_result:
    mr1, mr2, mr3 = st.columns(3)
    mr1.metric("Guna score (indicative)", f"{matching_result['score']} / 36")
    mr2.metric(f"{matching_result['name_a']} Moon sign", matching_result["moon_a"])
    mr3.metric(f"{matching_result['name_b']} Moon sign", matching_result["moon_b"])
    st.write(f"**Nakshatras:** {matching_result['nak_a']} / {matching_result['nak_b']}")
    st.dataframe([
        {"Koota": item[0], "Score": item[1], "Maximum": item[2], "Notes": item[3]}
        for item in matching_result["details"]
    ], use_container_width=True, hide_index=True)
    st.caption("This is a simplified indicative implementation, not a substitute for a complete school-specific Guna Milan calculation or personal judgment.")
