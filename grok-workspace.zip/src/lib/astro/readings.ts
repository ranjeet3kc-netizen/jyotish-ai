import {
  AD_DETAIL,
  BHAVA_NAMES,
  CAREER_HOUSE,
  CAREER_KARAKA,
  DASHA_LORDS,
  DASHA_YEARS,
  GRAHA_HI,
  HOUSE_EFFECT,
  HOUSE_THEME,
  KARANA_FIXED,
  KARANA_MOVABLE,
  MAHAPURUSHA,
  MD_DETAIL,
  NAKSHATRAS,
  NADI_NAMES,
  NAK_GANA,
  NAK_YONI,
  NAT_ENEMIES,
  NAT_FRIENDS,
  PANCHANG_YOGAS,
  REL_TEXT,
  SIGNS,
  SIGNS_HI,
  TATVA_BY_SIGN,
  TITHIS,
  VARNA_BY_SIGN,
  VASHYA_BY_SIGN,
  WEEKDAYS,
  exaltOfFive,
  exaltSign,
  ownSignList,
  rashiLord,
  signLabel,
} from "./catalog";
import { formatInZone, nakshatraIndex, norm360, signIndex, siderealPlanets } from "./ephemeris";
import type { BhavaRow, Gender, Note, Panchang, PlanetId, Report } from "./types";

const YEAR_DAYS = 365.25;
const SEVEN: PlanetId[] = ["Surya", "Chandra", "Mangal", "Budh", "Guru", "Shukra", "Shani"];

export function emptyBuckets(): PlanetId[][] {
  return Array.from({ length: 12 }, () => []);
}

export function checkKaalSarp(lons: Record<PlanetId, number>, rahu: number): boolean {
  const diffs = SEVEN.map((p) => norm360(lons[p] - rahu));
  return diffs.every((d) => d < 180) || diffs.every((d) => d > 180);
}

export function findYogas(
  signOf: Record<PlanetId, number>,
  houses: Record<PlanetId, number>,
): { name: string; text: string }[] {
  const yogas: { name: string; text: string }[] = [];
  if ([0, 3, 6, 9].includes((signOf.Guru - signOf.Chandra + 12) % 12)) {
    yogas.push({
      name: "गजकेसरी योग",
      text: "गुरु चंद्र से केंद्र में है: यश, बुद्धि और सम्मान देने वाला योग।",
    });
  }
  if (signOf.Surya === signOf.Budh) {
    yogas.push({
      name: "बुधादित्य योग",
      text: "सूर्य-बुध एक राशि में: तीक्ष्ण बुद्धि और वाक्पटुता।",
    });
  }
  if (signOf.Chandra === signOf.Mangal) {
    yogas.push({
      name: "चंद्र-मंगल योग",
      text: "धन-अर्जन की क्षमता, पर भावनात्मक उग्रता से सावधान रहें।",
    });
  }
  for (const [planet, name] of Object.entries(MAHAPURUSHA) as [PlanetId, string][]) {
    const inKendra = [1, 4, 7, 10].includes(houses[planet]);
    const own = ownSignList(planet);
    const exalt = exaltOfFive(planet);
    const strong = own.includes(signOf[planet]) || signOf[planet] === exalt;
    if (inKendra && strong) {
      yogas.push({
        name,
        text: `${planet} स्वराशि/उच्च का होकर केंद्र में है: पंच-महापुरुष योग।`,
      });
    }
  }
  return yogas;
}

function inHouse(houses: Record<PlanetId, number>, house: number): PlanetId[] {
  return (Object.keys(houses) as PlanetId[]).filter((p) => houses[p] === house);
}

function together(signOf: Record<PlanetId, number>, a: PlanetId, b: PlanetId): boolean {
  return signOf[a] === signOf[b];
}

export function analyzeLove(
  asc: number,
  signOf: Record<PlanetId, number>,
  houses: Record<PlanetId, number>,
  gender: Gender,
) {
  const lord5 = rashiLord((asc + 4) % 12);
  const lord7 = rashiLord((asc + 6) % 12);
  const karaka: PlanetId = gender === "Female" ? "Guru" : "Shukra";
  const love: Note[] = [];
  const marriage: Note[] = [];
  const affair: Note[] = [];
  let score = 0;
  const p5 = inHouse(houses, 5);

  love.push({
    tone: "info",
    text: `पंचम भाव (प्रेम): लग्न से ${SIGNS[(asc + 4) % 12]} राशि, स्वामी ${lord5} ${houses[lord5]}वें भाव में। पंचम में ग्रह: ${p5.length ? p5.join(", ") : "कोई नहीं"}।`,
  });
  if ([1, 5, 7, 11].includes(houses.Shukra)) {
    love.push({
      tone: "good",
      text: `शुक्र ${houses.Shukra}वें भाव में है: प्रेम, आकर्षण और रोमांस की अच्छी क्षमता।`,
    });
  } else if ([6, 8, 12].includes(houses.Shukra)) {
    love.push({
      tone: "warn",
      text: `शुक्र ${houses.Shukra}वें भाव में है: प्रेम में बाधा, देरी या गुप्तता के संकेत।`,
    });
  }
  if (p5.includes("Chandra") || together(signOf, "Chandra", "Shukra")) {
    love.push({
      tone: "good",
      text: "चंद्र/शुक्र का संबंध भावनात्मक और संवेदनशील प्रेम स्वभाव दर्शाता है।",
    });
  }
  if (together(signOf, "Shani", "Shukra")) {
    love.push({
      tone: "warn",
      text: "शनि-शुक्र एक राशि में: प्रेम देर से मिलता है, रिश्ते में गंभीरता और दूरी दोनों रह सकती हैं।",
    });
  }
  if (together(signOf, "Mangal", "Shukra")) {
    love.push({
      tone: "warn",
      text: "मंगल-शुक्र एक राशि में: तीव्र आकर्षण और जुनून, पर संयम की आवश्यकता।",
    });
    score += 1;
  }
  if (together(signOf, "Rahu", "Shukra") || together(signOf, "Ketu", "Shukra")) {
    love.push({
      tone: "warn",
      text: "राहु/केतु-शुक्र संबंध: असामान्य या अचानक आकर्षण, भ्रम की संभावना।",
    });
    score += 1;
  }

  if (together(signOf, lord5, lord7) && lord5 !== lord7) {
    marriage.push({
      tone: "good",
      text: "पंचमेश और सप्तमेश एक राशि में: प्रेम-विवाह का मजबूत योग।",
    });
  }
  if (houses[lord5] === 7 || houses[lord7] === 5) {
    marriage.push({
      tone: "good",
      text: "पंचमेश-सप्तमेश का भाव-परिवर्तन/संबंध: प्रेम से विवाह की संभावना।",
    });
  }
  if (lord5 === lord7) {
    marriage.push({
      tone: "good",
      text: `${lord5} पंचम और सप्तम दोनों का स्वामी है: प्रेम और विवाह एक-दूसरे से जुड़े रहते हैं।`,
    });
  }
  if ([5, 7].includes(houses[karaka])) {
    marriage.push({
      tone: "good",
      text: `विवाह कारक ${karaka} ${houses[karaka]}वें भाव में है: साथी से अच्छा जुड़ाव।`,
    });
  }
  if (!marriage.length) {
    marriage.push({
      tone: "info",
      text: "प्रेम-विवाह के स्पष्ट शास्त्रीय योग नहीं मिले; विवाह पारंपरिक या मिश्रित रूप से संभव।",
    });
  }

  const p7 = inHouse(houses, 7);
  marriage.push({
    tone: "info",
    text: `सप्तम भाव: ${SIGNS[(asc + 6) % 12]} राशि, स्वामी ${lord7} ${houses[lord7]}वें भाव में। सप्तम में ग्रह: ${p7.length ? p7.join(", ") : "कोई नहीं"}।`,
  });
  if ([6, 8, 12].includes(houses[lord7])) {
    marriage.push({
      tone: "warn",
      text: `सप्तमेश ${houses[lord7]}वें (दुःस्थान) भाव में: वैवाहिक जीवन में उतार-चढ़ाव, दूरी या विलंब।`,
    });
    score += 1;
  }
  if ([1, 4, 5, 7, 9, 10, 11].includes(houses[lord7])) {
    marriage.push({
      tone: "good",
      text: `सप्तमेश ${houses[lord7]}वें भाव में: वैवाहिक सुख के लिए अनुकूल स्थिति।`,
    });
  }
  if (p7.includes("Shani") || p7.includes("Mangal")) {
    marriage.push({
      tone: "warn",
      text: "सप्तम में शनि/मंगल: विवाह में देरी या स्वभाव-भेद; धैर्य ज़रूरी।",
    });
  }
  if (p7.includes("Guru") || p7.includes("Shukra")) {
    marriage.push({
      tone: "good",
      text: "सप्तम में गुरु/शुक्र: सुखद और सहयोगी जीवनसाथी का संकेत।",
    });
  }

  if (inHouse(houses, 5).includes("Rahu") || p7.includes("Rahu") || p7.includes("Ketu")) {
    affair.push({
      tone: "warn",
      text: "राहु/केतु पंचम या सप्तम में: गुप्त, असामान्य या अचानक बनने-टूटने वाले संबंधों की प्रवृत्ति।",
    });
    score += 1;
  }
  if (inHouse(houses, 12).includes("Rahu") || inHouse(houses, 12).includes("Mangal")) {
    affair.push({
      tone: "warn",
      text: "द्वादश भाव (शय्या सुख/गुप्त बातें) में राहु/मंगल: छिपे हुए संबंधों की प्रवृत्ति।",
    });
    score += 1;
  }
  if ([6, 8, 12].includes(houses[lord5]) || houses[lord7] === 12) {
    affair.push({
      tone: "warn",
      text: "पंचमेश/सप्तमेश का दुःस्थान या द्वादश से संबंध: संबंधों में गोपनीयता या बाधा।",
    });
    score += 1;
  }
  if (together(signOf, "Mangal", "Shukra") || together(signOf, "Rahu", "Shukra")) {
    affair.push({
      tone: "warn",
      text: "शुक्र पर मंगल/राहु का प्रभाव: आकर्षण में अधिक तीव्रता, इच्छाओं पर संयम की आवश्यकता।",
    });
    score += 1;
  }
  if (houses.Shukra === 12) {
    affair.push({
      tone: "info",
      text: "शुक्र द्वादश में: भोग-विलास और निजी जीवन में गोपनीयता की प्रवृत्ति।",
    });
  }
  if (inHouse(houses, 7).includes("Shani") || inHouse(houses, 7).includes("Guru")) {
    affair.push({
      tone: "good",
      text: "सप्तम में शनि/गुरु: मर्यादा और निष्ठा की प्रवृत्ति को बल।",
    });
    score -= 1;
  }
  if (!affair.length) {
    affair.push({ tone: "good", text: "गुप्त संबंध या अनैतिक आकर्षण के स्पष्ट योग नहीं मिले।" });
  }
  const affairLevel = score <= 1 ? "कम" : score <= 3 ? "मध्यम" : "अधिक";
  return { love, marriage, affair, affairLevel, lord5, lord7, karaka };
}

export function analyzeCareer(
  asc: number,
  signOf: Record<PlanetId, number>,
  houses: Record<PlanetId, number>,
): Note[] {
  const out: Note[] = [];
  const lord10 = rashiLord((asc + 9) % 12);
  out.push({
    tone: "info",
    text: `दशमेश ${lord10} ${houses[lord10]}वें भाव में: ${CAREER_HOUSE[String(houses[lord10])]}`,
  });
  for (const planet of inHouse(houses, 10)) {
    out.push({ tone: "info", text: `दशम भाव में ${planet}: ${CAREER_KARAKA[planet]} से जुड़े क्षेत्र।` });
  }
  const lord2 = rashiLord((asc + 1) % 12);
  const lord11 = rashiLord((asc + 10) % 12);
  const good = [1, 2, 5, 9, 10, 11];
  out.push(
    good.includes(houses[lord2])
      ? { tone: "good", text: `धनेश ${lord2} ${houses[lord2]}वें भाव में: धन संचय के लिए अनुकूल।` }
      : {
          tone: "warn",
          text: `धनेश ${lord2} ${houses[lord2]}वें भाव में: खर्च या धन में उतार-चढ़ाव; बचत पर ध्यान दें।`,
        },
  );
  out.push(
    good.includes(houses[lord11])
      ? { tone: "good", text: `लाभेश ${lord11} ${houses[lord11]}वें भाव में: आय के अच्छे स्रोत।` }
      : {
          tone: "warn",
          text: `लाभेश ${lord11} ${houses[lord11]}वें भाव में: आय में अस्थिरता संभव।`,
        },
  );
  if (lord2 !== lord11 && signOf[lord2] === signOf[lord11]) {
    out.push({ tone: "good", text: "धनेश और लाभेश एक राशि में: धन योग।" });
  }
  return out;
}

export function computePanchang(
  lons: Record<PlanetId, number>,
  year: number,
  month: number,
  day: number,
): Panchang {
  const sun = lons.Surya;
  const moon = lons.Chandra;
  const elong = norm360(moon - sun);
  const tithiNo = Math.floor(elong / 12) + 1;
  const paksha = tithiNo <= 15 ? "शुक्ल" : "कृष्ण";
  let tithi: string;
  if (tithiNo === 15) tithi = "पूर्णिमा";
  else if (tithiNo === 30) tithi = "अमावस्या";
  else tithi = TITHIS[(tithiNo - 1) % 15];
  const k = Math.floor(elong / 6);
  let karana: string;
  if (k === 0) karana = "किंस्तुघ्न";
  else if (k >= 57) karana = KARANA_FIXED[k - 57] ?? KARANA_FIXED[KARANA_FIXED.length - 1];
  else karana = KARANA_MOVABLE[(k - 1) % 7];
  const span = 360 / 27;
  const yoga = PANCHANG_YOGAS[Math.min(26, Math.floor(norm360(sun + moon) / span))];
  const nak = nakshatraIndex(moon);
  const pada = Math.floor((norm360(moon) % span) / (span / 4)) + 1;
  const jsDay = new Date(Date.UTC(year, month - 1, day)).getUTCDay();
  const vara = WEEKDAYS[(jsDay + 6) % 7];
  return {
    vara,
    tithi: `${paksha} पक्ष ${tithi}`,
    karana,
    yoga,
    nakshatra: NAKSHATRAS[nak],
    pada,
  };
}

export function computeAvakahada(moonLon: number): { label: string; value: string }[] {
  const nak = nakshatraIndex(moonLon);
  const sign = signIndex(moonLon);
  return [
    { label: "वर्ण", value: VARNA_BY_SIGN[sign] },
    { label: "वश्य", value: VASHYA_BY_SIGN[sign] },
    { label: "योनि", value: NAK_YONI[nak] },
    { label: "गण", value: NAK_GANA[nak] },
    { label: "नाड़ी", value: NADI_NAMES[nak % 6] },
    { label: "तत्व", value: TATVA_BY_SIGN[sign % 4] },
    { label: "राशि स्वामी", value: rashiLord(sign) },
  ];
}

const SADE: Record<number, string> = {
  11: "साढ़ेसाती - प्रथम चरण (चंद्र से 12वें में शनि)",
  0: "साढ़ेसाती - द्वितीय चरण (चंद्र राशि में शनि, शिखर)",
  1: "साढ़ेसाती - तृतीय चरण (चंद्र से 2रे में शनि)",
  3: "शनि ढैया (चंद्र से 4थे में शनि)",
  7: "शनि ढैया (चंद्र से 8वें में शनि)",
};

export function computeSadeSati(moonSign: number, now = new Date()) {
  const saturn = siderealPlanets(now).Shani;
  const saturnSign = signIndex(saturn.lon);
  const distance = (saturnSign - moonSign + 12) % 12;
  return { saturnSign, status: SADE[distance] ?? null };
}

export function bhavaTable(
  asc: number,
  houses: Record<PlanetId, number>,
): BhavaRow[] {
  const rows: BhavaRow[] = [];
  for (let h = 1; h <= 12; h += 1) {
    const sign = (asc + h - 1) % 12;
    const lord = rashiLord(sign);
    rows.push({
      house: h,
      name: BHAVA_NAMES[h - 1],
      sign,
      lord,
      lordHouse: houses[lord],
      planets: inHouse(houses, h),
    });
  }
  return rows;
}

export type Antardasha = { lord: PlanetId; start: Date; end: Date };

export function antardashas(mdLord: PlanetId, mdStart: Date): Antardasha[] {
  const mdIdx = DASHA_LORDS.indexOf(mdLord);
  const mdYears = DASHA_YEARS[mdLord];
  const out: Antardasha[] = [];
  let start = mdStart;
  for (let i = 0; i < 9; i += 1) {
    const lord = DASHA_LORDS[(mdIdx + i) % 9];
    const years = (mdYears * DASHA_YEARS[lord]) / 120;
    const end = new Date(start.getTime() + years * YEAR_DAYS * 86_400_000);
    out.push({ lord, start, end });
    start = end;
  }
  return out;
}

function planetRelation(a: PlanetId, b: PlanetId): "friend" | "enemy" | "neutral" {
  if (a === b) return "neutral";
  if ((NAT_FRIENDS[a] ?? []).includes(b)) return "friend";
  if ((NAT_ENEMIES[a] ?? []).includes(b)) return "enemy";
  return "neutral";
}

function planetContext(planet: PlanetId, report: Pick<Report, "ascSign" | "signOf" | "houses">): string[] {
  const { ascSign: asc, signOf, houses } = report;
  const h = houses[planet];
  const s = signOf[planet];
  const lines = [
    `${GRAHA_HI[planet]} आपकी कुंडली में **${SIGNS[s]} (${SIGNS_HI[s]}) राशि** और **${h}वें भाव** में स्थित है।`,
  ];
  const exalt = exaltSign(planet);
  if (exalt !== undefined) {
    const own = ownSignList(planet);
    if (s === exalt) {
      lines.push(
        `${GRAHA_HI[planet]} यहाँ **उच्च राशि** में है, इसलिए इसका फल बहुत बलवान और शुभ रहने की संभावना है।`,
      );
    } else if (s === (exalt + 6) % 12) {
      lines.push(
        `${GRAHA_HI[planet]} यहाँ **नीच राशि** में है, इसलिए इसके शुभ फल कमज़ोर पड़ सकते हैं और इसके कारक विषयों में अतिरिक्त मेहनत व उपाय ज़रूरी हैं।`,
      );
    } else if (own.includes(s)) {
      lines.push(
        `${GRAHA_HI[planet]} यहाँ **स्वराशि** में है, इसलिए यह मज़बूत और आत्मविश्वास से फल देने वाला ग्रह है।`,
      );
    } else {
      lines.push(
        `${GRAHA_HI[planet]} यहाँ सामान्य राशि में है, अतः इसका फल भाव, दृष्टि और अन्य ग्रहों के संबंध पर निर्भर करेगा।`,
      );
    }
  }
  if (planet === "Rahu" || planet === "Ketu") {
    const disp = rashiLord(s);
    lines.push(
      `राहु-केतु जिस राशि में बैठे होते हैं उसके स्वामी के अनुसार फल देते हैं। यहाँ ${GRAHA_HI[planet]} का राशि-स्वामी **${GRAHA_HI[disp]}** है, जो ${houses[disp]}वें भाव में है। इसलिए इस दशा में ${HOUSE_THEME[String(houses[disp])]} से जुड़े फल विशेष रूप से दिखाई देंगे।`,
    );
  } else {
    const owned: number[] = [];
    for (let x = 1; x <= 12; x += 1) {
      if (rashiLord((asc + x - 1) % 12) === planet) owned.push(x);
    }
    if (owned.length) {
      const themes = owned.map((x) => `${x}वें भाव (${HOUSE_THEME[String(x)]})`).join("; ");
      const ownedLabel = owned.map((x) => `${x}वें`).join(" और ");
      lines.push(
        `आपके लग्न के अनुसार ${GRAHA_HI[planet]} **${ownedLabel} भाव का स्वामी** है। इसलिए इसकी दशा में ${themes} से जुड़े विषय सक्रिय होंगे।`,
      );
      const dusthana = owned.some((x) => [6, 8, 12].includes(x));
      const kendraTrikona = owned.some((x) => [1, 4, 5, 7, 9, 10].includes(x));
      if (dusthana && !kendraTrikona) {
        lines.push(
          "दुःस्थान (6, 8, 12) का स्वामी होने से इसके फल मिश्रित हो सकते हैं, इसलिए स्वास्थ्य, खर्च और संघर्ष के मामलों में अतिरिक्त सावधानी रखें।",
        );
      } else if (owned.some((x) => [1, 5, 9].includes(x))) {
        lines.push("त्रिकोण (1, 5, 9) का स्वामी होने से यह ग्रह भाग्य और शुभ फल देने वाला माना जाता है।");
      } else if (owned.some((x) => [4, 7, 10].includes(x))) {
        lines.push("केंद्र (4, 7, 10) का स्वामी होने से यह ग्रह जीवन में स्थिरता और कर्म-फल देता है।");
      }
    }
  }
  return lines;
}

export type ReadingBlock = { title: string; text: string };

export function mdReading(md: PlanetId, report: Pick<Report, "ascSign" | "signOf" | "houses">): ReadingBlock[] {
  return [
    { title: "आपकी कुंडली में दशानाथ की स्थिति", text: planetContext(md, report).join("\n\n") },
    { title: "भाव के अनुसार फल", text: HOUSE_EFFECT[String(report.houses[md])] },
    ...MD_DETAIL[md].map(([title, text]) => ({ title, text })),
  ];
}

export function adReading(
  md: PlanetId,
  ad: PlanetId,
  report: Pick<Report, "ascSign" | "signOf" | "houses">,
): ReadingBlock[] {
  const houses = report.houses;
  const rel = planetRelation(md, ad);
  const d = ((houses[ad] - houses[md] + 12) % 12) + 1;
  let pos: string;
  if ([6, 8, 12].includes(d)) {
    pos = `${GRAHA_HI[md]} (महादशा) ${houses[md]}वें भाव में और ${GRAHA_HI[ad]} (अंतर्दशा) ${houses[ad]}वें भाव में है। दोनों के बीच ${d}वाँ संबंध बनता है, जो शास्त्रों में कठिन माना जाता है। इसलिए इस अंतर्दशा में मतभेद, देरी या अप्रत्याशित बाधाएँ आ सकती हैं।`;
  } else if ([1, 4, 5, 7, 9, 10].includes(d)) {
    pos = `${GRAHA_HI[md]} (महादशा) ${houses[md]}वें भाव में और ${GRAHA_HI[ad]} (अंतर्दशा) ${houses[ad]}वें भाव में है। दोनों के बीच ${d}वाँ संबंध बनता है, जो सहयोगी और शुभ माना जाता है। इसलिए दोनों ग्रह मिलकर अच्छे परिणाम देते हैं।`;
  } else {
    pos = `${GRAHA_HI[md]} (महादशा) ${houses[md]}वें भाव में और ${GRAHA_HI[ad]} (अंतर्दशा) ${houses[ad]}वें भाव में है। दोनों के बीच ${d}वाँ संबंध बनता है, जिसका फल मिश्रित रहता है।`;
  }
  return [
    { title: "महादशा और अंतर्दशा का आपसी संबंध", text: `${REL_TEXT[rel]}\n\n${pos}` },
    { title: `अंतर्दशा-स्वामी ${GRAHA_HI[ad]} की स्थिति`, text: planetContext(ad, report).join("\n\n") },
    {
      title: "भाव के अनुसार फल",
      text: HOUSE_EFFECT[String(houses[ad])].replaceAll("दशानाथ", "अंतर्दशा-स्वामी"),
    },
    ...AD_DETAIL[ad].map(([title, text]) => ({ title, text })),
  ];
}

export function buildDashas(
  moonLon: number,
  birth: Date,
  timeZone: string,
  now = new Date(),
) {
  const span = 360 / 27;
  const nakIdx = nakshatraIndex(moonLon);
  const balance = 1 - (norm360(moonLon) % span) / span;
  const firstIdx = nakIdx % 9;
  const firstLord = DASHA_LORDS[firstIdx];
  const firstFull = DASHA_YEARS[firstLord];
  const firstRemaining = firstFull * balance;
  const firstStart = new Date(birth.getTime() - (firstFull - firstRemaining) * YEAR_DAYS * 86_400_000);
  const rows = [];
  let mdStart = firstStart;
  let activeMd: PlanetId | "" = "";
  let activeAd: PlanetId | "" = "";
  for (let i = 0; i < 10; i += 1) {
    const lord = DASHA_LORDS[(firstIdx + i) % 9];
    const full = DASHA_YEARS[lord];
    const mdEnd = new Date(mdStart.getTime() + full * YEAR_DAYS * 86_400_000);
    const shownStart = i === 0 ? birth : mdStart;
    const active = mdStart.getTime() <= now.getTime() && now.getTime() < mdEnd.getTime();
    if (active) {
      activeMd = lord;
      for (const ad of antardashas(lord, mdStart)) {
        if (ad.start.getTime() <= now.getTime() && now.getTime() < ad.end.getTime()) activeAd = ad.lord;
      }
    }
    rows.push({
      lord,
      start: formatInZone(shownStart, timeZone),
      end: formatInZone(mdEnd, timeZone),
      trueStart: mdStart.toISOString(),
      years: Math.round((i === 0 ? firstRemaining : full) * 100) / 100,
      active,
    });
    mdStart = mdEnd;
  }
  return { rows, activeMd, activeAd };
}

export function signPair(sign: number): string {
  return signLabel(sign);
}
