import { NAKSHATRAS, SIGNS } from "./catalog";
import { nakshatraIndex } from "./ephemeris";
import type { Report } from "./types";

const DEVA = new Set([0, 4, 6, 7, 12, 14, 17, 21, 26]);
const MANUSHYA = new Set([1, 3, 5, 10, 11, 19, 20, 24, 25]);
const YONI = [
  "Horse", "Elephant", "Sheep", "Serpent", "Serpent", "Dog", "Cat", "Sheep", "Cat",
  "Rat", "Rat", "Cow", "Buffalo", "Tiger", "Buffalo", "Tiger", "Deer", "Deer",
  "Dog", "Monkey", "Mongoose", "Monkey", "Lion", "Horse", "Lion", "Cow", "Elephant",
];
const SIGN_LORDS = [
  "Mars", "Venus", "Mercury", "Moon", "Sun", "Mercury",
  "Venus", "Mars", "Jupiter", "Saturn", "Saturn", "Jupiter",
];
const FRIENDS: Record<string, string[]> = {
  Sun: ["Moon", "Mars", "Jupiter"],
  Moon: ["Sun", "Mercury"],
  Mars: ["Sun", "Moon", "Jupiter"],
  Mercury: ["Sun", "Venus"],
  Jupiter: ["Sun", "Moon", "Mars"],
  Venus: ["Mercury", "Saturn"],
  Saturn: ["Mercury", "Venus"],
};
const ENEMIES: Record<string, string[]> = {
  Sun: ["Venus", "Saturn"],
  Moon: [],
  Mars: ["Mercury"],
  Mercury: ["Moon"],
  Jupiter: ["Mercury", "Venus"],
  Venus: ["Sun", "Moon"],
  Saturn: ["Sun", "Moon", "Mars"],
};
const YONI_ENEMIES = [
  ["Horse", "Buffalo"],
  ["Elephant", "Lion"],
  ["Sheep", "Monkey"],
  ["Serpent", "Mongoose"],
  ["Dog", "Deer"],
  ["Cat", "Rat"],
  ["Cow", "Tiger"],
  ["Rat", "Monkey"],
];

export type GunaRow = { koota: string; score: number; max: number; notes: string };

function ganaOf(i: number): string {
  if (DEVA.has(i)) return "Deva";
  if (MANUSHYA.has(i)) return "Manushya";
  return "Rakshasa";
}

function nadiOf(i: number): string {
  const adi = new Set([0, 5, 6, 11, 12, 17, 18, 23, 24]);
  const madhya = new Set([1, 4, 7, 10, 13, 16, 19, 22, 25]);
  if (adi.has(i)) return "Adi";
  if (madhya.has(i)) return "Madhya";
  return "Antya";
}

function mod(n: number, m: number): number {
  return ((n % m) + m) % m;
}

export function gunaMilan(a: Report, b: Report): {
  score: number;
  details: GunaRow[];
  nakA: string;
  nakB: string;
  moonA: string;
  moonB: string;
} {
  const nakA = nakshatraIndex(a.lons.Chandra);
  const nakB = nakshatraIndex(b.lons.Chandra);
  const signA = a.moonSign;
  const signB = b.moonSign;
  const varna = [1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4];
  const varnaScore = varna[signA] === varna[signB] ? 1 : 0;
  const element = [0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3];
  const vashyaScore =
    element[signA] === element[signB] ? 2 : (element[signA] + element[signB]) % 2 === 0 ? 1 : 0;
  const taraA = mod(nakB - nakA, 9);
  const taraB = mod(nakA - nakB, 9);
  const goodTara = new Set([0, 1, 3, 5, 7]);
  const taraScore =
    goodTara.has(taraA) && goodTara.has(taraB) ? 3 : goodTara.has(taraA) || goodTara.has(taraB) ? 1.5 : 0;
  const yoniPair = [YONI[nakA], YONI[nakB]].sort().join("|");
  const enemy = YONI_ENEMIES.some((pair) => pair.slice().sort().join("|") === yoniPair);
  const yoniScore = YONI[nakA] === YONI[nakB] ? 4 : enemy ? 0 : 2;
  const lordA = SIGN_LORDS[signA];
  const lordB = SIGN_LORDS[signB];
  let maitri = 3;
  if (lordA === lordB) maitri = 5;
  else if ((FRIENDS[lordA] ?? []).includes(lordB) && (FRIENDS[lordB] ?? []).includes(lordA)) maitri = 5;
  else if ((ENEMIES[lordA] ?? []).includes(lordB) || (ENEMIES[lordB] ?? []).includes(lordA)) maitri = 0;
  const ganaA = ganaOf(nakA);
  const ganaB = ganaOf(nakB);
  const ganaPair = new Set([ganaA, ganaB]);
  let ganaScore = 1;
  if (ganaA === ganaB) ganaScore = 6;
  else if (ganaPair.has("Deva") && ganaPair.has("Manushya") && ganaPair.size === 2) ganaScore = 5;
  else if (ganaPair.has("Rakshasa") && ganaPair.has("Deva")) ganaScore = 0;
  const distance = mod(signB - signA, 12);
  const bhakootBad = [1, 4, 5, 7, 8, 11].includes(distance);
  const bhakoot = bhakootBad && signA !== signB ? 0 : 7;
  const nadiA = nadiOf(nakA);
  const nadiB = nadiOf(nakB);
  const nadi = nadiA === nadiB ? 0 : 8;
  const details: GunaRow[] = [
    { koota: "Varna", score: varnaScore, max: 1, notes: `Moon-sign classes: ${varna[signA]} / ${varna[signB]}` },
    { koota: "Vashya", score: vashyaScore, max: 2, notes: "Simplified sign-class compatibility" },
    { koota: "Tara", score: taraScore, max: 3, notes: `Nakshatra distance remainders: ${taraA}, ${taraB}` },
    { koota: "Yoni", score: yoniScore, max: 4, notes: `${YONI[nakA]} / ${YONI[nakB]}` },
    { koota: "Graha Maitri", score: maitri, max: 5, notes: `Moon-sign lords: ${lordA} / ${lordB}` },
    { koota: "Gana", score: ganaScore, max: 6, notes: `${ganaA} / ${ganaB}` },
    { koota: "Bhakoot", score: bhakoot, max: 7, notes: `Moon-sign distance: ${distance}` },
    { koota: "Nadi", score: nadi, max: 8, notes: `${nadiA} / ${nadiB}` },
  ];
  const score = Math.round(details.reduce((sum, row) => sum + row.score, 0) * 10) / 10;
  return {
    score,
    details,
    nakA: NAKSHATRAS[nakA],
    nakB: NAKSHATRAS[nakB],
    moonA: SIGNS[signA],
    moonB: SIGNS[signB],
  };
}
