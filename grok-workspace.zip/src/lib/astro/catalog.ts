import raw from "./data.json";
import type { PlanetId } from "./types";

type Pair = [string, string];

export const SIGNS = raw.SIGNS;
export const SIGNS_HI = raw.SIGNS_HI;
export const NAKSHATRAS = raw.NAKSHATRAS;
export const DASHA_LORDS = raw.DASHA_LORDS as PlanetId[];
export const DASHA_YEARS = raw.DASHA_YEARS as Record<PlanetId, number>;
export const GRAHA_HI = raw.GRAHA_HI as Record<PlanetId, string>;
export const PL_SHORT = raw.PL_SHORT as Record<PlanetId, string>;
export const GEMSTONES = raw.GEMSTONES as Record<PlanetId, string>;
export const RUDRAKSHA = raw.RUDRAKSHA as Record<PlanetId, string>;
export const HEALTH_MAP = raw.HEALTH_MAP as Record<PlanetId, string>;
export const WEEKDAYS = raw.WEEKDAYS;
export const TITHIS = raw.TITHIS;
export const PANCHANG_YOGAS = raw.PANCHANG_YOGAS;
export const KARANA_MOVABLE = raw.KARANA_MOVABLE;
export const KARANA_FIXED = raw.KARANA_FIXED;
export const NAK_GANA = raw.NAK_GANA;
export const NAK_YONI = raw.NAK_YONI;
export const NADI_NAMES = raw.NADI_NAMES;
export const VARNA_BY_SIGN = raw.VARNA_BY_SIGN;
export const VASHYA_BY_SIGN = raw.VASHYA_BY_SIGN;
export const TATVA_BY_SIGN = raw.TATVA_BY_SIGN;
export const BHAVA_NAMES = raw.BHAVA_NAMES;
export const HOUSE_THEME = raw.HOUSE_THEME as Record<string, string>;
export const HOUSE_EFFECT = raw.HOUSE_EFFECT as Record<string, string>;
export const CAREER_HOUSE = raw.CAREER_HOUSE as Record<string, string>;
export const CAREER_KARAKA = raw.CAREER_KARAKA as Record<PlanetId, string>;
export const MD_DETAIL = raw.MD_DETAIL as Record<PlanetId, Pair[]>;
export const AD_DETAIL = raw.AD_DETAIL as Record<PlanetId, Pair[]>;
export const REL_TEXT = raw.REL_TEXT as Record<"friend" | "enemy" | "neutral", string>;
export const NAT_FRIENDS = raw.NAT_FRIENDS as Record<PlanetId, PlanetId[]>;
export const NAT_ENEMIES = raw.NAT_ENEMIES as Record<PlanetId, PlanetId[]>;
export const MAHAPURUSHA = raw.MAHAPURUSHA as Record<string, string>;

const rashiLords = raw.RASHI_LORDS as Record<string, PlanetId>;
const ownSigns = raw.OWN_SIGNS as Record<string, number[]>;
const extraOwn = raw.EXTRA_OWN as Record<string, number[]>;
const exaltAll = raw.EXALT_ALL as Record<string, number>;
const exaltFive = raw.EXALT_SIGN as Record<string, number>;

export function rashiLord(sign: number): PlanetId {
  return rashiLords[String(sign)];
}

export function ownSignList(planet: PlanetId): number[] {
  return [...(ownSigns[planet] ?? []), ...(extraOwn[planet] ?? [])];
}

export function exaltSign(planet: PlanetId): number | undefined {
  const value = exaltAll[planet];
  return value === undefined ? undefined : value;
}

export function exaltOfFive(planet: string): number | undefined {
  const value = exaltFive[planet];
  return value === undefined ? undefined : value;
}

export function signLabel(sign: number): string {
  return `${SIGNS[sign]} (${SIGNS_HI[sign]})`;
}
