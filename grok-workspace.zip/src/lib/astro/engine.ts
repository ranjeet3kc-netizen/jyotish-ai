import { NAKSHATRAS, rashiLord } from "./catalog";
import {
  dashamshaSign,
  lahiriAyanamsha,
  nakshatraIndex,
  navamshaSign,
  norm360,
  offsetHours,
  signIndex,
  siderealPlanets,
  tropicalAscendant,
  wallTimeToUtc,
} from "./ephemeris";
import {
  analyzeCareer,
  analyzeLove,
  bhavaTable,
  buildDashas,
  checkKaalSarp,
  computeAvakahada,
  computePanchang,
  computeSadeSati,
  findYogas,
} from "./readings";
import type { Gender, Placement, PlanetId, Report } from "./types";

export type BirthInput = {
  name: string;
  gender: Gender;
  date: string;
  time: string;
  place: string;
  address: string;
  lat: number;
  lon: number;
  timezone: string;
};

function timeLabel(time: string): string {
  const [hRaw, mRaw] = time.split(":");
  const h = Number(hRaw);
  const m = Number(mRaw);
  const suffix = h >= 12 ? "PM" : "AM";
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${hour12}:${String(m).padStart(2, "0")} ${suffix}`;
}

function buckets(planets: Placement[], key: "sign" | "d9" | "d10") {
  const ids: PlanetId[][] = Array.from({ length: 12 }, () => []);
  const retro: boolean[][] = Array.from({ length: 12 }, () => []);
  for (const planet of planets) {
    ids[planet[key]].push(planet.id);
    retro[planet[key]].push(planet.retro);
  }
  return { ids, retro };
}

export function computeReport(input: BirthInput, now = new Date()): Report {
  const [year, month, day] = input.date.split("-").map(Number);
  const [hour, minute] = input.time.split(":").map(Number);
  const birth = wallTimeToUtc(year, month, day, hour, minute, input.timezone);
  const ayan = lahiriAyanamsha(birth);
  const ascDegree = norm360(tropicalAscendant(birth, input.lat, input.lon) - ayan);
  const ascSign = signIndex(ascDegree);
  const sky = siderealPlanets(birth);
  const planets: Placement[] = (Object.keys(sky) as PlanetId[]).map((id) => {
    const lon = sky[id].lon;
    const sign = signIndex(lon);
    const span = 360 / 27;
    return {
      id,
      retro: sky[id].retro,
      lon,
      sign,
      house: ((sign - ascSign + 12) % 12) + 1,
      d9: navamshaSign(lon),
      d10: dashamshaSign(lon),
      degree: Math.round((norm360(lon) % 30) * 100) / 100,
      nakshatra: nakshatraIndex(lon),
      pada: Math.floor((norm360(lon) % span) / (span / 4)) + 1,
    };
  });
  const signOf = {} as Record<PlanetId, number>;
  const houses = {} as Record<PlanetId, number>;
  const lons = {} as Record<PlanetId, number>;
  for (const planet of planets) {
    signOf[planet.id] = planet.sign;
    houses[planet.id] = planet.house;
    lons[planet.id] = planet.lon;
  }
  const d1 = buckets(planets, "sign");
  const d9 = buckets(planets, "d9");
  const d10 = buckets(planets, "d10");
  const dasha = buildDashas(lons.Chandra, birth, input.timezone, now);
  const utcOffset = Math.round(offsetHours(birth, input.timezone) * 100) / 100;
  return {
    name: input.name.trim(),
    gender: input.gender,
    place: input.place.trim(),
    address: input.address,
    date: input.date,
    time: input.time,
    timeLabel: timeLabel(input.time),
    dobLabel: `${String(day).padStart(2, "0")}-${String(month).padStart(2, "0")}-${year} ${input.time}`,
    timezone: input.timezone,
    utcOffset,
    lat: input.lat,
    lon: input.lon,
    ayanamsha: Math.round(ayan * 1000) / 1000,
    ascDegree,
    ascSign,
    d9Asc: navamshaSign(ascDegree),
    d10Asc: dashamshaSign(ascDegree),
    moonSign: signOf.Chandra,
    sunSign: signOf.Surya,
    lagnaLord: rashiLord(ascSign),
    planets,
    bySign: d1.ids,
    bySignRetro: d1.retro,
    byD9: d9.ids,
    byD9Retro: d9.retro,
    byD10: d10.ids,
    byD10Retro: d10.retro,
    signOf,
    houses,
    lons,
    isManglik: [1, 4, 7, 8, 12].includes(houses.Mangal),
    kalsarp: checkKaalSarp(lons, lons.Rahu),
    dashas: dasha.rows,
    activeMd: dasha.activeMd,
    activeAd: dasha.activeAd,
    yogas: findYogas(signOf, houses),
    panchang: computePanchang(lons, year, month, day),
    avakahada: computeAvakahada(lons.Chandra),
    sadesati: computeSadeSati(signOf.Chandra, now),
    bhava: bhavaTable(ascSign, houses),
    career: analyzeCareer(ascSign, signOf, houses),
    love: analyzeLove(ascSign, signOf, houses, input.gender),
  };
}

export function nakshatraName(index: number): string {
  return NAKSHATRAS[index] ?? "";
}
