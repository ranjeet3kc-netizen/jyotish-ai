export const PLANET_IDS = [
  "Surya",
  "Chandra",
  "Mangal",
  "Budh",
  "Guru",
  "Shukra",
  "Shani",
  "Rahu",
  "Ketu",
] as const;

export type PlanetId = (typeof PLANET_IDS)[number];

export type Gender = "Male" | "Female" | "Other";

export type Lang = "Hindi" | "Nepali" | "English";

export type Tone = "good" | "warn" | "info";

export type Note = { tone: Tone; text: string };

export type Placement = {
  id: PlanetId;
  retro: boolean;
  lon: number;
  sign: number;
  house: number;
  d9: number;
  d10: number;
  degree: number;
  nakshatra: number;
  pada: number;
};

export type DashaSpan = {
  lord: PlanetId;
  start: string;
  end: string;
  trueStart: string;
  years: number;
  active: boolean;
};

export type Panchang = {
  vara: string;
  tithi: string;
  karana: string;
  yoga: string;
  nakshatra: string;
  pada: number;
};

export type BhavaRow = {
  house: number;
  name: string;
  sign: number;
  lord: PlanetId;
  lordHouse: number;
  planets: PlanetId[];
};

export type Report = {
  name: string;
  gender: Gender;
  place: string;
  address: string;
  date: string;
  time: string;
  timeLabel: string;
  dobLabel: string;
  timezone: string;
  utcOffset: number;
  lat: number;
  lon: number;
  ayanamsha: number;
  ascDegree: number;
  ascSign: number;
  d9Asc: number;
  d10Asc: number;
  moonSign: number;
  sunSign: number;
  lagnaLord: PlanetId;
  planets: Placement[];
  bySign: PlanetId[][];
  bySignRetro: boolean[][];
  byD9: PlanetId[][];
  byD9Retro: boolean[][];
  byD10: PlanetId[][];
  byD10Retro: boolean[][];
  signOf: Record<PlanetId, number>;
  houses: Record<PlanetId, number>;
  lons: Record<PlanetId, number>;
  isManglik: boolean;
  kalsarp: boolean;
  dashas: DashaSpan[];
  activeMd: PlanetId | "";
  activeAd: PlanetId | "";
  yogas: { name: string; text: string }[];
  panchang: Panchang;
  avakahada: { label: string; value: string }[];
  sadesati: { saturnSign: number; status: string | null };
  bhava: BhavaRow[];
  career: Note[];
  love: {
    lord5: PlanetId;
    lord7: PlanetId;
    karaka: PlanetId;
    love: Note[];
    marriage: Note[];
    affair: Note[];
    affairLevel: string;
  };
};
