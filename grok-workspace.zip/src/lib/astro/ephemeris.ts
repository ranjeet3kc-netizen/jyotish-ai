import {
  Body,
  Ecliptic,
  EclipticGeoMoon,
  GeoVector,
  MakeTime,
  SiderealTime,
  e_tilt,
} from "astronomy-engine";
import type { PlanetId } from "./types";

const DAY = 86_400_000;

const BODY = {
  Surya: Body.Sun,
  Chandra: Body.Moon,
  Mangal: Body.Mars,
  Budh: Body.Mercury,
  Guru: Body.Jupiter,
  Shukra: Body.Venus,
  Shani: Body.Saturn,
} as const;

type Moving = keyof typeof BODY;

export function julianDay(date: Date): number {
  return date.getTime() / DAY + 2_440_587.5;
}

/** Mean Lahiri ayanamsha in degrees, zero-point matched to Swiss Ephemeris at J2000. */
export function lahiriAyanamsha(date: Date): number {
  const t = (julianDay(date) - 2_451_545.0) / 36_525;
  const arcsec =
    5028.796195 * t + 1.1054348 * t * t + 0.00007964 * t ** 3 - 0.000023857 * t ** 4;
  return 23.853055555555557 + arcsec / 3600;
}

export function norm360(deg: number): number {
  const x = deg % 360;
  return x < 0 ? x + 360 : x;
}

export function tropicalLongitude(id: Moving, date: Date): number {
  if (id === "Chandra") return norm360(EclipticGeoMoon(date).lon);
  return norm360(Ecliptic(GeoVector(BODY[id], date, true)).elon);
}

/** Meeus mean longitude of the lunar ascending node (tropical). */
export function meanNodeTropical(date: Date): number {
  const t = (julianDay(date) - 2_451_545.0) / 36_525;
  const omega =
    125.0445479 - 1934.1362891 * t + 0.0020754 * t * t + (t * t * t) / 467441;
  return norm360(omega);
}

export function tropicalAscendant(date: Date, latDeg: number, lonEast: number): number {
  const gast = SiderealTime(date);
  const lst = ((gast + lonEast / 15) % 24 + 24) % 24;
  const ramc = (lst * 15 * Math.PI) / 180;
  const eps = (e_tilt(MakeTime(date)).tobl * Math.PI) / 180;
  const phi = (latDeg * Math.PI) / 180;
  const y = Math.cos(ramc);
  const x = -(Math.sin(ramc) * Math.cos(eps) + Math.tan(phi) * Math.sin(eps));
  return norm360((Math.atan2(y, x) * 180) / Math.PI);
}

export function isRetrograde(id: Exclude<Moving, "Surya" | "Chandra">, date: Date): boolean {
  const a = tropicalLongitude(id, date);
  const b = tropicalLongitude(id, new Date(date.getTime() + DAY));
  let delta = b - a;
  if (delta > 180) delta -= 360;
  if (delta < -180) delta += 360;
  return delta < 0;
}

function zoneOffsetMs(utcDate: Date, timeZone: string): number {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).formatToParts(utcDate);
  const map: Record<string, string> = {};
  for (const part of parts) {
    if (part.type !== "literal") map[part.type] = part.value;
  }
  const hour = map.hour === "24" ? 0 : Number(map.hour);
  const asUtc = Date.UTC(
    Number(map.year),
    Number(map.month) - 1,
    Number(map.day),
    hour,
    Number(map.minute),
    Number(map.second),
  );
  return asUtc - utcDate.getTime();
}

/** Convert a civil wall-clock time in an IANA zone to a UTC instant. */
export function wallTimeToUtc(
  year: number,
  month: number,
  day: number,
  hour: number,
  minute: number,
  timeZone: string,
): Date {
  const desired = Date.UTC(year, month - 1, day, hour, minute, 0);
  let utc = desired;
  for (let i = 0; i < 3; i += 1) {
    utc = desired - zoneOffsetMs(new Date(utc), timeZone);
  }
  return new Date(utc);
}

export function offsetHours(utc: Date, timeZone: string): number {
  return zoneOffsetMs(utc, timeZone) / 3_600_000;
}

export function formatInZone(date: Date, timeZone: string): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

export function navamshaSign(absDegree: number): number {
  const abs = norm360(absDegree);
  const d1 = Math.floor(abs / 30);
  const part = Math.floor((abs % 30) / (30 / 9));
  let start = 3;
  if (d1 === 0 || d1 === 4 || d1 === 8) start = 0;
  else if (d1 === 1 || d1 === 5 || d1 === 9) start = 9;
  else if (d1 === 2 || d1 === 6 || d1 === 10) start = 6;
  return (start + part) % 12;
}

export function dashamshaSign(absDegree: number): number {
  const abs = norm360(absDegree);
  const rashi = Math.floor(abs / 30);
  const part = Math.min(9, Math.floor((abs % 30) / 3));
  const start = rashi % 2 === 0 ? rashi : (rashi + 8) % 12;
  return (start + part) % 12;
}

export function signIndex(lon: number): number {
  return Math.min(11, Math.floor(norm360(lon) / 30));
}

export function nakshatraIndex(lon: number): number {
  return Math.min(26, Math.floor(norm360(lon) / (360 / 27)));
}

const CLASSICAL: Moving[] = ["Surya", "Chandra", "Mangal", "Budh", "Guru", "Shukra", "Shani"];

export function siderealPlanets(date: Date): Record<PlanetId, { lon: number; retro: boolean }> {
  const ayan = lahiriAyanamsha(date);
  const out = {} as Record<PlanetId, { lon: number; retro: boolean }>;
  for (const id of CLASSICAL) {
    const retro =
      id === "Surya" || id === "Chandra"
        ? false
        : isRetrograde(id, date);
    out[id] = { lon: norm360(tropicalLongitude(id, date) - ayan), retro };
  }
  const rahu = norm360(meanNodeTropical(date) - ayan);
  out.Rahu = { lon: rahu, retro: true };
  out.Ketu = { lon: norm360(rahu + 180), retro: true };
  return out;
}

export { CLASSICAL };
