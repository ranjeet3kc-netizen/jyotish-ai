import { signIndex, siderealPlanets } from "./ephemeris";
import type { PlanetId } from "./types";
import { PLANET_IDS } from "./types";

export type TransitRow = {
  id: PlanetId;
  sign: number;
  degree: number;
  houseFromMoon: number;
};

export function currentTransits(moonSign: number, now = new Date()): TransitRow[] {
  const sky = siderealPlanets(now);
  return PLANET_IDS.map((id) => {
    const sign = signIndex(sky[id].lon);
    return {
      id,
      sign,
      degree: Math.round((sky[id].lon % 30) * 100) / 100,
      houseFromMoon: ((sign - moonSign + 12) % 12) + 1,
    };
  });
}
