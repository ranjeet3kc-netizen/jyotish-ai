import type { Gender } from "./types";

export type SavedProfile = {
  id: string;
  name: string;
  gender: Gender;
  date: string;
  time: string;
  place: string;
  address: string;
  lat: number;
  lon: number;
  timezone: string;
  savedAt: string;
};

const KEY = "jyotish-patrika-profiles";

export function loadProfiles(): SavedProfile[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as SavedProfile[];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item) => item && typeof item.id === "string" && typeof item.place === "string");
  } catch {
    return [];
  }
}

export function writeProfiles(profiles: SavedProfile[]): void {
  localStorage.setItem(KEY, JSON.stringify(profiles.slice(0, 24)));
}
