import { createServerFn } from "@tanstack/react-start";
import tzlookup from "tz-lookup";

export type PlaceHit = {
  ok: true;
  lat: number;
  lon: number;
  address: string;
  timezone: string;
};

export type PlaceMiss = { ok: false; error: "not_found" | "unavailable" };

export const geocodePlace = createServerFn({ method: "POST" })
  .validator((input: { place: string }) => {
    const place = String(input?.place ?? "").trim().replace(/\s+/g, " ");
    if (place.length < 2 || place.length > 160) {
      throw new Error("Enter a city and country.");
    }
    return { place };
  })
  .handler(async ({ data }): Promise<PlaceHit | PlaceMiss> => {
    const url = new URL("https://nominatim.openstreetmap.org/search");
    url.searchParams.set("format", "jsonv2");
    url.searchParams.set("limit", "1");
    url.searchParams.set("q", data.place);
    try {
      const res = await fetch(url, {
        headers: {
          Accept: "application/json",
          "User-Agent": "JyotishPatrika/1.0 (vedic chart, educational)",
        },
      });
      if (!res.ok) return { ok: false, error: "unavailable" };
      const rows = (await res.json()) as { lat?: string; lon?: string; display_name?: string }[];
      const hit = rows[0];
      if (!hit?.lat || !hit.lon) return { ok: false, error: "not_found" };
      const lat = Number(hit.lat);
      const lon = Number(hit.lon);
      if (!Number.isFinite(lat) || !Number.isFinite(lon)) return { ok: false, error: "not_found" };
      let timezone = "UTC";
      try {
        timezone = tzlookup(lat, lon);
      } catch {
        timezone = "UTC";
      }
      return {
        ok: true,
        lat,
        lon,
        address: hit.display_name || data.place,
        timezone,
      };
    } catch {
      return { ok: false, error: "unavailable" };
    }
  });
