import { createServerFn } from "@tanstack/react-start";
import type { Lang } from "../astro/types";

type Turn = { role: "user" | "assistant"; content: string };

export type AskInput = {
  question: string;
  language: Lang;
  history: Turn[];
  chart: {
    name: string;
    ascendant: string;
    moon: string;
    sun: string;
    activeMd: string;
    activeAd: string;
    planets: string;
  } | null;
};

const LANG: Record<Lang, string> = {
  Hindi: "Hindi",
  Nepali: "Nepali",
  English: "English",
};

function clip(value: string, max: number): string {
  const text = value.replace(/\s+/g, " ").trim();
  return text.length > max ? text.slice(0, max) : text;
}

export const askJyotish = createServerFn({ method: "POST" })
  .validator((input: AskInput) => {
    const language: Lang =
      input?.language === "English" || input?.language === "Nepali" ? input.language : "Hindi";
    const question = clip(String(input?.question ?? ""), 1200);
    if (question.length < 2) throw new Error("Ask a question first.");
    const history = Array.isArray(input?.history) ? input.history.slice(-6) : [];
    const turns: Turn[] = [];
    for (const turn of history) {
      if (turn?.role !== "user" && turn?.role !== "assistant") continue;
      const content = clip(String(turn.content ?? ""), 800);
      if (content) turns.push({ role: turn.role, content });
    }
    const chart = input?.chart
      ? {
          name: clip(String(input.chart.name ?? ""), 80),
          ascendant: clip(String(input.chart.ascendant ?? ""), 80),
          moon: clip(String(input.chart.moon ?? ""), 80),
          sun: clip(String(input.chart.sun ?? ""), 80),
          activeMd: clip(String(input.chart.activeMd ?? ""), 40),
          activeAd: clip(String(input.chart.activeAd ?? ""), 40),
          planets: clip(String(input.chart.planets ?? ""), 1800),
        }
      : null;
    return { question, language, history: turns, chart };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "unavailable" as const };
    const chartContext = data.chart
      ? `Ascendant: ${data.chart.ascendant}. Moon sign: ${data.chart.moon}. Sun sign: ${data.chart.sun}. Active mahadasha: ${data.chart.activeMd}. Active antardasha: ${data.chart.activeAd}. Planets: ${data.chart.planets}. Name: ${data.chart.name}.`
      : "No birth chart has been generated in this session.";
    const system = [
      "You are a careful Vedic astrology explainer.",
      "Use only the supplied chart facts. Never invent planetary positions, houses, or dates.",
      "Explain traditional interpretations as beliefs, not guaranteed facts.",
      "Do not give medical diagnoses, financial guarantees, or tell the user to make a major life decision solely from astrology.",
      "Avoid fear-based certainty.",
      `Answer in ${LANG[data.language]}.`,
      `Chart context: ${chartContext}`,
    ].join(" ");
    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.4,
          max_tokens: 700,
          messages: [
            { role: "system", content: system },
            ...data.history.map((turn) => ({ role: turn.role, content: turn.content })),
            { role: "user", content: data.question },
          ],
        }),
      });
      if (!res.ok) return { ok: false as const, error: "failed" as const };
      const body = (await res.json()) as {
        choices?: { message?: { content?: unknown } }[];
      };
      const content = body.choices?.[0]?.message?.content;
      let text = "";
      if (typeof content === "string") text = content;
      else if (Array.isArray(content)) {
        text = content
          .map((part) => {
            if (typeof part === "string") return part;
            if (part && typeof part === "object" && "text" in part) return String(part.text ?? "");
            return "";
          })
          .join("");
      }
      text = text.trim();
      if (!text) return { ok: false as const, error: "failed" as const };
      return { ok: true as const, text };
    } catch {
      return { ok: false as const, error: "failed" as const };
    }
  });
