import type { ReactNode } from "react";
import type { Note, Tone } from "@/lib/astro/types";

export function Section({
  id,
  title,
  children,
}: {
  id: string;
  title: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-20">
      <h2 className="font-display border-b border-line pb-2 text-2xl font-semibold text-maroon">{title}</h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

export function DataTable({ columns, rows }: { columns: string[]; rows: string[][] }) {
  return (
    <div className="overflow-x-auto rounded-card border border-line">
      <table className="w-full min-w-[40rem] border-collapse text-left text-sm">
        <thead className="bg-maroon text-paper">
          <tr>
            {columns.map((column) => (
              <th key={column} className="px-3 py-2 font-medium whitespace-nowrap">
                {column}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={index} className={index % 2 ? "bg-paper-2" : "bg-paper"}>
              {row.map((cell, cellIndex) => (
                <td key={cellIndex} className="px-3 py-2 align-top text-ink">
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const TONE_CLASS: Record<Tone, string> = {
  good: "border-gold bg-paper-2",
  warn: "border-maroon bg-paper-2",
  info: "border-line bg-paper",
};

export function Callout({ tone, children }: { tone: Tone; children: ReactNode }) {
  return <p className={`border-l-4 px-4 py-3 leading-relaxed text-ink ${TONE_CLASS[tone]}`}>{children}</p>;
}

export function Notes({ items }: { items: Note[] }) {
  return (
    <div className="space-y-2">
      {items.map((item, index) => (
        <Callout key={index} tone={item.tone}>
          {item.text}
        </Callout>
      ))}
    </div>
  );
}

export function Rich({ text }: { text: string }) {
  return (
    <div className="space-y-3">
      {text.split(/\n\n/).map((block, index) => (
        <p key={index} className="leading-relaxed text-ink">
          {block.split(/(\*\*[^*]+\*\*)/g).map((part, partIndex) =>
            part.startsWith("**") && part.endsWith("**") ? (
              <strong key={partIndex} className="font-semibold">
                {part.slice(2, -2)}
              </strong>
            ) : (
              <span key={partIndex}>{part}</span>
            ),
          )}
        </p>
      ))}
    </div>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-ink">{label}</span>
      {children}
    </label>
  );
}

export const fieldClass =
  "min-h-11 w-full rounded-xl border border-line bg-paper px-3 text-base text-ink";

export function PrimaryButton({
  children,
  type = "button",
  disabled,
  onClick,
}: {
  children: ReactNode;
  type?: "button" | "submit";
  disabled?: boolean;
  onClick?: () => void;
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className="inline-flex min-h-11 items-center justify-center rounded-xl bg-maroon px-5 font-medium text-paper disabled:opacity-60"
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  type = "button",
  onClick,
}: {
  children: ReactNode;
  type?: "button" | "submit";
  onClick?: () => void;
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      className="inline-flex min-h-11 items-center justify-center rounded-xl border border-line bg-paper px-4 text-ink"
    >
      {children}
    </button>
  );
}
