import { useMemo, useState } from "react";
import { GRAHA_HI, GEMSTONES, HEALTH_MAP, NAKSHATRAS, RUDRAKSHA, SIGNS, signLabel } from "@/lib/astro/catalog";
import { formatInZone } from "@/lib/astro/ephemeris";
import type { Report } from "@/lib/astro/types";
import { adReading, antardashas, mdReading } from "@/lib/astro/readings";
import { currentTransits } from "@/lib/astro/transits";
import type { Copy } from "./copy";
import { NorthChart } from "./north-chart";
import { Callout, DataTable, Notes, Rich, Section } from "./ui";

function planetName(id: Report["planets"][number]["id"]): string {
  return `${GRAHA_HI[id]} (${id})`;
}

export function ReportView({
  report,
  copy,
  onSave,
  savedNote,
}: {
  report: Report;
  copy: Copy;
  onSave: () => void;
  savedNote: string | null;
}) {
  const activeIndex = Math.max(0, report.dashas.findIndex((row) => row.active));
  const [pick, setPick] = useState(activeIndex);
  const selected = report.dashas[pick] ?? report.dashas[0];
  const readings = selected ? mdReading(selected.lord, report) : [];
  const sub = selected ? antardashas(selected.lord, new Date(selected.trueStart)) : [];
  const now = Date.now();
  const transits = useMemo(() => currentTransits(report.moonSign), [report]);

  const nav = [
    ["basics", copy.basics],
    ["planets", copy.planets],
    ["charts", copy.charts],
    ["bhava", copy.bhava],
    ["dosha", copy.dosha],
    ["dasha", copy.dasha],
    ["yoga", copy.yogas],
    ["remedy", copy.remedies],
    ["love", copy.love],
    ["career", copy.career],
    ["transit", copy.transit],
  ] as const;

  return (
    <div id="report" className="space-y-10">
      <div className="no-print sticky top-0 z-20 -mx-4 border-b border-line bg-paper/95 px-4 py-2 backdrop-blur">
        <div className="flex gap-2 overflow-x-auto">
          {nav.map(([id, label]) => (
            <a
              key={id}
              href={`#${id}`}
              className="inline-flex min-h-11 shrink-0 items-center rounded-full border border-line px-3 text-sm text-ink"
            >
              {label}
            </a>
          ))}
        </div>
      </div>

      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm text-muted">{report.address}</p>
          <p className="mt-1 text-sm text-ink">
            {report.timezone} · UTC {report.utcOffset >= 0 ? "+" : ""}
            {report.utcOffset.toFixed(2)} · {report.timeLabel}
          </p>
        </div>
        <div className="no-print flex flex-wrap gap-2">
          <button
            type="button"
            onClick={onSave}
            className="inline-flex min-h-11 items-center rounded-xl border border-line bg-paper px-4 text-ink"
          >
            {copy.save}
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex min-h-11 items-center rounded-xl bg-maroon px-4 text-paper"
          >
            {copy.print}
          </button>
        </div>
      </div>
      {savedNote ? <p className="text-sm text-gold">{savedNote}</p> : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <Fact label={copy.d1} value={signLabel(report.ascSign)} />
        <Fact label={copy.moonChart} value={signLabel(report.moonSign)} />
        <Fact
          label={copy.current}
          value={
            report.activeMd
              ? `${GRAHA_HI[report.activeMd]} · ${report.activeAd ? GRAHA_HI[report.activeAd] : ""}`
              : copy.futureBirth
          }
        />
      </div>

      <Section id="basics" title={copy.basics}>
        <div className="grid gap-6 lg:grid-cols-3">
          <div>
            <h3 className="mb-2 text-lg font-semibold text-ink">{copy.birth}</h3>
            <DataTable
              columns={[copy.notes, copy.score]}
              rows={[
                [copy.name, report.name],
                [copy.date, report.dobLabel],
                [copy.place, report.place],
                [copy.d1, signLabel(report.ascSign)],
                [copy.moonChart, signLabel(report.moonSign)],
                [copy.planets, signLabel(report.sunSign)],
                [copy.lagnaLord, report.lagnaLord],
                ["Ayanamsha", String(report.ayanamsha)],
              ]}
            />
          </div>
          <div>
            <h3 className="mb-2 text-lg font-semibold text-ink">{copy.panchang}</h3>
            <DataTable
              columns={[copy.notes, copy.score]}
              rows={[
                ["Vara", report.panchang.vara],
                ["Tithi", report.panchang.tithi],
                [copy.nakshatra, `${report.panchang.nakshatra} (${report.panchang.pada})`],
                ["Yoga", report.panchang.yoga],
                ["Karana", report.panchang.karana],
              ]}
            />
            <p className="mt-2 text-xs text-muted">{copy.varaNote}</p>
          </div>
          <div>
            <h3 className="mb-2 text-lg font-semibold text-ink">{copy.avakahada}</h3>
            <DataTable
              columns={[copy.notes, copy.score]}
              rows={report.avakahada.map((row) => [row.label, row.value])}
            />
          </div>
        </div>
      </Section>

      <Section id="planets" title={copy.planets}>
        <DataTable
          columns={[
            copy.planets,
            copy.sign,
            copy.house,
            copy.degree,
            copy.nakshatra,
            copy.pada,
            copy.d9col,
            copy.d10col,
            copy.motion,
          ]}
          rows={report.planets.map((planet) => [
            planetName(planet.id),
            SIGNS[planet.sign],
            String(planet.house),
            planet.degree.toFixed(2),
            NAKSHATRAS[planet.nakshatra],
            String(planet.pada),
            SIGNS[planet.d9],
            SIGNS[planet.d10],
            planet.retro ? copy.retro : copy.direct,
          ])}
        />
      </Section>

      <Section id="charts" title={copy.charts}>
        <div className="grid gap-4 lg:grid-cols-2">
          <div>
            <p className="mb-2 text-sm text-muted">
              {copy.d1}: {signLabel(report.ascSign)} · {(report.ascDegree % 30).toFixed(2)}°
            </p>
            <NorthChart
              title={copy.d1}
              lagnaSign={report.ascSign}
              occupants={report.bySign}
              retro={report.bySignRetro}
              legend={copy.legend}
            />
          </div>
          <div>
            <p className="mb-2 text-sm text-muted">
              {copy.d9}: {signLabel(report.d9Asc)}
            </p>
            <NorthChart
              title={copy.d9}
              lagnaSign={report.d9Asc}
              occupants={report.byD9}
              retro={report.byD9Retro}
              legend={copy.legend}
            />
          </div>
          <div>
            <p className="mb-2 text-sm text-muted">{signLabel(report.moonSign)}</p>
            <NorthChart
              title={copy.moonChart}
              lagnaSign={report.moonSign}
              occupants={report.bySign}
              retro={report.bySignRetro}
              legend={copy.legend}
            />
          </div>
          <div>
            <p className="mb-2 text-sm text-muted">
              {copy.d10}: {signLabel(report.d10Asc)}
            </p>
            <NorthChart
              title={copy.d10}
              lagnaSign={report.d10Asc}
              occupants={report.byD10}
              retro={report.byD10Retro}
              legend={copy.legend}
            />
          </div>
        </div>
      </Section>

      <Section id="bhava" title={copy.bhava}>
        <DataTable
          columns={[copy.house, copy.sign, copy.lord, copy.occupants]}
          rows={report.bhava.map((row) => [
            `${row.house} · ${row.name}`,
            signLabel(row.sign),
            `${row.lord} (${row.lordHouse})`,
            row.planets.length ? row.planets.join(", ") : "—",
          ])}
        />
      </Section>

      <Section id="dosha" title={copy.dosha}>
        <div className="grid gap-3 md:grid-cols-3">
          <article className="rounded-card border border-line p-4">
            <h3 className="font-display text-xl text-maroon">{copy.manglik}</h3>
            <p className="mt-2 leading-relaxed">
              {copy.planets}: {GRAHA_HI.Mangal} {copy.inHouse} {report.houses.Mangal}.{" "}
              {report.isManglik ? copy.manglikYes : copy.manglikNo}
            </p>
          </article>
          <article className="rounded-card border border-line p-4">
            <h3 className="font-display text-xl text-maroon">{copy.kalsarp}</h3>
            <p className="mt-2 leading-relaxed">{report.kalsarp ? copy.kalsarpYes : copy.kalsarpNo}</p>
          </article>
          <article className="rounded-card border border-line p-4">
            <h3 className="font-display text-xl text-maroon">{copy.sade}</h3>
            <p className="mt-2 leading-relaxed">
              {copy.saturnNow} {SIGNS[report.sadesati.saturnSign]}.{" "}
              {report.sadesati.status ?? copy.sadeNone}
            </p>
          </article>
        </div>
      </Section>

      <Section id="dasha" title={copy.dasha}>
        <p className="mb-3 text-sm text-muted">{copy.readingNote}</p>
        <DataTable
          columns={[copy.dasha, copy.from, copy.to, copy.years, copy.current]}
          rows={report.dashas.map((row) => [
            GRAHA_HI[row.lord],
            row.start,
            row.end,
            String(row.years),
            row.active ? copy.activeNow : "—",
          ])}
        />
        <label className="mt-4 block max-w-xl">
          <span className="mb-1 block text-sm font-medium">{copy.pick}</span>
          <select
            className="min-h-11 w-full rounded-xl border border-line bg-paper px-3 text-base"
            value={pick}
            onChange={(event) => setPick(Number(event.target.value))}
          >
            {report.dashas.map((row, index) => (
              <option key={row.trueStart} value={index}>
                {GRAHA_HI[row.lord]} ({row.start} – {row.end}){row.active ? ` · ${copy.current}` : ""}
              </option>
            ))}
          </select>
        </label>
        {selected ? (
          <div className="mt-6 space-y-5">
            <h3 className="font-display text-2xl text-maroon">
              {GRAHA_HI[selected.lord]}
            </h3>
            {readings.map((block) => (
              <article key={block.title}>
                <h4 className="mb-2 text-lg font-semibold text-ink">{block.title}</h4>
                <Rich text={block.text} />
              </article>
            ))}
            <div key={selected.trueStart} className="space-y-2">
              {sub.map((span) => {
                const active = span.start.getTime() <= now && now < span.end.getTime();
                const blocks = adReading(selected.lord, span.lord, report);
                return (
                  <details
                    key={span.start.toISOString()}
                    open={active ? true : undefined}
                    className="rounded-xl border border-line"
                  >
                    <summary className="min-h-11 list-none px-4 py-3 font-medium">
                      {GRAHA_HI[selected.lord]} – {GRAHA_HI[span.lord]} ({formatInZone(span.start, report.timezone)} –{" "}
                      {formatInZone(span.end, report.timezone)}){active ? ` · ${copy.activeNow}` : ""}
                    </summary>
                    <div className="space-y-4 border-t border-line px-4 py-4">
                      {blocks.map((block) => (
                        <article key={block.title}>
                          <h4 className="mb-2 font-semibold">{block.title}</h4>
                          <Rich text={block.text} />
                        </article>
                      ))}
                    </div>
                  </details>
                );
              })}
            </div>
            <p className="text-xs text-muted">{copy.dashaNote}</p>
          </div>
        ) : null}
      </Section>

      <Section id="yoga" title={copy.yogas}>
        {report.yogas.length ? (
          <div className="space-y-2">
            {report.yogas.map((yoga) => (
              <Callout key={yoga.name} tone="good">
                <strong>{yoga.name}</strong> — {yoga.text}
              </Callout>
            ))}
          </div>
        ) : (
          <Callout tone="info">{copy.noYoga}</Callout>
        )}
      </Section>

      <Section id="remedy" title={copy.remedies}>
        <div className="grid gap-4 md:grid-cols-2">
          <Remedy
            title={`${copy.lagnaLord}: ${report.lagnaLord}`}
            gem={GEMSTONES[report.lagnaLord]}
            bead={RUDRAKSHA[report.lagnaLord]}
            health={HEALTH_MAP[report.lagnaLord]}
            copy={copy}
          />
          {report.activeMd ? (
            <Remedy
              title={`${copy.dashaLord}: ${report.activeMd}`}
              gem={GEMSTONES[report.activeMd]}
              bead={RUDRAKSHA[report.activeMd]}
              health={HEALTH_MAP[report.activeMd]}
              copy={copy}
            />
          ) : null}
        </div>
        <p className="mt-3 text-xs text-muted">{copy.gemNote}</p>
      </Section>

      <Section id="love" title={copy.love}>
        <p className="mb-3 text-sm text-muted">
          {copy.loveNature}: {report.love.lord5} · {copy.marriage}: {report.love.lord7} · {report.love.karaka}
        </p>
        <div className="space-y-4">
          <div>
            <h3 className="mb-2 font-semibold">{copy.loveNature}</h3>
            <Notes items={report.love.love} />
          </div>
          <div>
            <h3 className="mb-2 font-semibold">{copy.marriage}</h3>
            <Notes items={report.love.marriage} />
          </div>
          <div>
            <h3 className="mb-2 font-semibold">{copy.conduct}</h3>
            <Notes items={report.love.affair} />
            <p className="mt-2 text-sm font-medium">
              {copy.level}: {report.love.affairLevel}
            </p>
          </div>
        </div>
        <p className="mt-3 text-xs text-muted">{copy.loveNote}</p>
      </Section>

      <Section id="career" title={copy.career}>
        <Notes items={report.career} />
        <p className="mt-3 text-xs text-muted">{copy.careerNote}</p>
      </Section>

      <Section id="transit" title={copy.transit}>
        <DataTable
          columns={[copy.planets, copy.sign, copy.degree, copy.house]}
          rows={transits.map((row) => [
            planetName(row.id),
            SIGNS[row.sign],
            row.degree.toFixed(2),
            String(row.houseFromMoon),
          ])}
        />
        <p className="mt-3 text-xs text-muted">{copy.transitNote}</p>
      </Section>
    </div>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-card border border-line bg-paper-2 px-4 py-3">
      <p className="text-xs tracking-wide text-muted uppercase">{label}</p>
      <p className="font-display mt-1 text-xl text-ink">{value}</p>
    </div>
  );
}

function Remedy({
  title,
  gem,
  bead,
  health,
  copy,
}: {
  title: string;
  gem: string;
  bead: string;
  health: string;
  copy: Copy;
}) {
  return (
    <article className="rounded-card border border-line p-4">
      <h3 className="font-display text-xl text-maroon">{title}</h3>
      <p className="mt-3 text-sm">
        <span className="font-medium">{copy.gem}: </span>
        {gem}
      </p>
      <p className="mt-2 text-sm">
        <span className="font-medium">{copy.rudraksha}: </span>
        {bead}
      </p>
      <p className="mt-2 text-sm leading-relaxed">
        <span className="font-medium">{copy.health}: </span>
        {health}
      </p>
    </article>
  );
}
