import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { computeReport } from "@/lib/astro/engine";
import { gunaMilan, type GunaRow } from "@/lib/astro/match";
import { geocodePlace } from "@/lib/server/place";
import type { Copy } from "./copy";
import { DataTable, Field, fieldClass, PrimaryButton } from "./ui";

type Side = { name: string; date: string; time: string; place: string };

const empty = (): Side => ({ name: "", date: "", time: "12:00", place: "" });

export function MatchPanel({ copy }: { copy: Copy }) {
  const geocode = useServerFn(geocodePlace);
  const [a, setA] = useState<Side>(empty);
  const [b, setB] = useState<Side>(empty);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{
    score: number;
    details: GunaRow[];
    nakA: string;
    nakB: string;
    moonA: string;
    moonB: string;
    nameA: string;
    nameB: string;
  } | null>(null);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (!a.date || !b.date || !a.place.trim() || !b.place.trim()) {
      setError(copy.matchNeed);
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const [geoA, geoB] = await Promise.all([
        geocode({ data: { place: a.place } }),
        geocode({ data: { place: b.place } }),
      ]);
      if (!geoA.ok || !geoB.ok) {
        setError(copy.placeMissing);
        return;
      }
      const reportA = computeReport({
        name: a.name || copy.person + " A",
        gender: "Male",
        date: a.date,
        time: a.time || "12:00",
        place: a.place,
        address: geoA.address,
        lat: geoA.lat,
        lon: geoA.lon,
        timezone: geoA.timezone,
      });
      const reportB = computeReport({
        name: b.name || copy.person + " B",
        gender: "Female",
        date: b.date,
        time: b.time || "12:00",
        place: b.place,
        address: geoB.address,
        lat: geoB.lat,
        lon: geoB.lon,
        timezone: geoB.timezone,
      });
      const guna = gunaMilan(reportA, reportB);
      setResult({ ...guna, nameA: reportA.name, nameB: reportB.name });
    } catch {
      setError(copy.placeDown);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6">
      <p className="max-w-3xl leading-relaxed text-muted">{copy.matchIntro}</p>
      <form onSubmit={onSubmit} className="grid gap-4 lg:grid-cols-2">
        <PersonFields title={`${copy.person} A`} value={a} onChange={setA} copy={copy} />
        <PersonFields title={`${copy.person} B`} value={b} onChange={setB} copy={copy} />
        <div className="lg:col-span-2">
          <PrimaryButton type="submit" disabled={busy}>
            {busy ? copy.working : copy.matchBtn}
          </PrimaryButton>
          {error ? <p className="mt-3 text-sm text-maroon">{error}</p> : null}
        </div>
      </form>
      {result ? (
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-card border border-line bg-paper-2 p-4">
              <p className="text-xs text-muted">{copy.guna}</p>
              <p className="font-display text-3xl text-maroon tabular-nums">
                {result.score}
                <span className="ml-2 text-base text-muted">{copy.of36}</span>
              </p>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-line">
                <div className="h-full bg-maroon" style={{ width: `${Math.min(100, (result.score / 36) * 100)}%` }} />
              </div>
            </div>
            <div className="rounded-card border border-line p-4">
              <p className="text-xs text-muted">{result.nameA}</p>
              <p className="font-display text-2xl">{result.moonA}</p>
              <p className="text-sm text-muted">{result.nakA}</p>
            </div>
            <div className="rounded-card border border-line p-4">
              <p className="text-xs text-muted">{result.nameB}</p>
              <p className="font-display text-2xl">{result.moonB}</p>
              <p className="text-sm text-muted">{result.nakB}</p>
            </div>
          </div>
          <DataTable
            columns={[copy.koota, copy.score, copy.max, copy.notes]}
            rows={result.details.map((row) => [row.koota, String(row.score), String(row.max), row.notes])}
          />
          <p className="text-xs text-muted">{copy.matchNote}</p>
        </div>
      ) : null}
    </div>
  );
}

function PersonFields({
  title,
  value,
  onChange,
  copy,
}: {
  title: string;
  value: Side;
  onChange: (next: Side) => void;
  copy: Copy;
}) {
  return (
    <fieldset className="space-y-3 rounded-card border border-line p-4">
      <legend className="px-1 font-display text-xl text-maroon">{title}</legend>
      <Field label={copy.name}>
        <input className={fieldClass} value={value.name} onChange={(event) => onChange({ ...value, name: event.target.value })} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label={copy.date}>
          <input
            type="date"
            required
            min="1900-01-01"
            className={fieldClass}
            value={value.date}
            onChange={(event) => onChange({ ...value, date: event.target.value })}
          />
        </Field>
        <Field label={copy.time}>
          <input
            type="time"
            required
            className={fieldClass}
            value={value.time}
            onChange={(event) => onChange({ ...value, time: event.target.value })}
          />
        </Field>
      </div>
      <Field label={copy.place}>
        <input
          className={fieldClass}
          placeholder={copy.placeHint}
          value={value.place}
          onChange={(event) => onChange({ ...value, place: event.target.value })}
        />
      </Field>
    </fieldset>
  );
}
