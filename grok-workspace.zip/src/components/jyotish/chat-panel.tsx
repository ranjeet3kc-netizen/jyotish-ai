import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { GRAHA_HI, SIGNS } from "@/lib/astro/catalog";
import type { Lang, Report } from "@/lib/astro/types";
import { askJyotish } from "@/lib/server/ask";
import type { Copy } from "./copy";
import { PrimaryButton, fieldClass } from "./ui";

type Msg = { role: "user" | "assistant"; content: string };

export function ChatPanel({ copy, lang, report }: { copy: Copy; lang: Lang; report: Report | null }) {
  const ask = useServerFn(askJyotish);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [question, setQuestion] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    const text = question.trim();
    if (text.length < 2 || busy) return;
    const history = messages.slice(-6);
    setMessages((prev) => [...prev, { role: "user", content: text }]);
    setQuestion("");
    setBusy(true);
    try {
      const chart = report
        ? {
            name: report.name,
            ascendant: SIGNS[report.ascSign],
            moon: SIGNS[report.moonSign],
            sun: SIGNS[report.sunSign],
            activeMd: report.activeMd ? GRAHA_HI[report.activeMd] : "none",
            activeAd: report.activeAd ? GRAHA_HI[report.activeAd] : "none",
            planets: report.planets
              .map((planet) => `${planet.id} ${SIGNS[planet.sign]} house ${planet.house} D9 ${SIGNS[planet.d9]}`)
              .join("; "),
          }
        : null;
      const answer = await ask({ data: { question: text, language: lang, history, chart } });
      const content = answer.ok ? answer.text : answer.error === "unavailable" ? copy.aiDown : copy.aiFail;
      setMessages((prev) => [...prev, { role: "assistant", content }]);
    } catch {
      setMessages((prev) => [...prev, { role: "assistant", content: copy.aiFail }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <p className="leading-relaxed text-muted">{copy.askIntro}</p>
      {!report ? <p className="text-sm text-muted">{copy.noChartAsk}</p> : null}
      <div className="space-y-3">
        {messages.map((message, index) => (
          <article
            key={index}
            className={
              message.role === "user"
                ? "ml-8 rounded-card border border-line bg-paper-2 px-4 py-3"
                : "mr-8 rounded-card border border-maroon/30 bg-paper px-4 py-3"
            }
          >
            <p className="leading-relaxed whitespace-pre-wrap">{message.content}</p>
          </article>
        ))}
        {busy ? <p className="text-sm text-muted">{copy.thinking}</p> : null}
      </div>
      <form onSubmit={onSubmit} className="flex flex-col gap-3 sm:flex-row">
        <input
          className={fieldClass}
          value={question}
          placeholder={copy.askPlaceholder}
          onChange={(event) => setQuestion(event.target.value)}
          maxLength={1200}
        />
        <PrimaryButton type="submit" disabled={busy || question.trim().length < 2}>
          {copy.send}
        </PrimaryButton>
      </form>
    </div>
  );
}
