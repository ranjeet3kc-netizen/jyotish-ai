import { PL_SHORT, SIGNS } from "@/lib/astro/catalog";
import type { PlanetId } from "@/lib/astro/types";

const CENTERS: [number, number][] = [
  [0.5, 0.75],
  [0.25, 0.917],
  [0.083, 0.75],
  [0.25, 0.5],
  [0.083, 0.25],
  [0.25, 0.083],
  [0.5, 0.25],
  [0.75, 0.083],
  [0.917, 0.25],
  [0.75, 0.5],
  [0.917, 0.75],
  [0.75, 0.917],
];

type Props = {
  title: string;
  lagnaSign: number;
  occupants: PlanetId[][];
  retro: boolean[][];
  legend: string;
};

export function NorthChart({ title, lagnaSign, occupants, retro, legend }: Props) {
  const size = 520;
  const x0 = 36;
  const y0 = 58;
  const px = (x: number, y: number) => [x0 + x * size, y0 + (1 - y) * size] as const;
  const mid = {
    w: px(0, 0.5),
    n: px(0.5, 1),
    e: px(1, 0.5),
    s: px(0.5, 0),
  };
  const font = "Noto Sans Devanagari, Noto Sans, sans-serif";

  return (
    <figure className="rounded-card border border-line bg-paper p-2">
      <svg viewBox="0 0 592 640" role="img" aria-label={title} className="h-auto w-full">
        <rect x="8" y="8" width="576" height="624" rx="16" fill="var(--color-paper)" />
        <text
          x="296"
          y="38"
          textAnchor="middle"
          fill="var(--color-maroon)"
          fontFamily="Fraunces, serif"
          fontSize="22"
          fontWeight="650"
        >
          {title}
        </text>
        <rect x={x0} y={y0} width={size} height={size} fill="none" stroke="var(--color-maroon)" strokeWidth="2.5" />
        <polygon
          points={`${mid.w[0]},${mid.w[1]} ${mid.n[0]},${mid.n[1]} ${mid.e[0]},${mid.e[1]} ${mid.s[0]},${mid.s[1]}`}
          fill="none"
          stroke="var(--color-maroon)"
          strokeWidth="2"
        />
        <line x1={px(0, 0)[0]} y1={px(0, 0)[1]} x2={px(1, 1)[0]} y2={px(1, 1)[1]} stroke="var(--color-maroon)" strokeWidth="2" />
        <line x1={px(0, 1)[0]} y1={px(0, 1)[1]} x2={px(1, 0)[0]} y2={px(1, 0)[1]} stroke="var(--color-maroon)" strokeWidth="2" />
        {CENTERS.map(([cx, cy], house) => {
          const sign = (lagnaSign + house) % 12;
          const names = occupants[sign] ?? [];
          const flags = retro[sign] ?? [];
          const labels = names.map((id, index) => `${PL_SHORT[id]}${flags[index] ? "व" : ""}`);
          const big = house % 3 === 0;
          const perRow = big ? 3 : 2;
          const rows: string[] = [];
          for (let i = 0; i < labels.length; i += perRow) rows.push(labels.slice(i, i + perRow).join(" "));
          const [x, y] = px(cx, cy);
          const line = big ? 20 : 16;
          const top = y - (rows.length * line) / 2;
          return (
            <g key={house}>
              <text
                x={x}
                y={rows.length ? top : y + 6}
                textAnchor="middle"
                fill="var(--color-maroon)"
                fontFamily={font}
                fontSize={big ? 18 : 15}
                fontWeight="700"
              >
                {sign + 1}
                {house === 0 ? " ल" : ""}
              </text>
              {rows.map((row, index) => (
                <text
                  key={row + index}
                  x={x}
                  y={top + (index + 1) * line + 2}
                  textAnchor="middle"
                  fill="var(--color-ink)"
                  fontFamily={font}
                  fontSize={big ? 16 : 13}
                  fontWeight="600"
                >
                  {row}
                </text>
              ))}
            </g>
          );
        })}
        <text x="296" y="618" textAnchor="middle" fill="var(--color-muted)" fontFamily={font} fontSize="12">
          {SIGNS[lagnaSign]}
        </text>
      </svg>
      <figcaption className="px-3 pb-2 text-center text-xs leading-relaxed text-muted">{legend}</figcaption>
    </figure>
  );
}
