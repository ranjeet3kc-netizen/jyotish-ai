import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { computeReport } from "@/lib/astro/engine";
import { loadProfiles, writeProfiles, type SavedProfile } from "@/lib/astro/storage";
import type { Gender, Lang, Report } from "@/lib/astro/types";
import { geocodePlace } from "@/lib/server/place";
import { ChatPanel } from "@/components/jyotish/chat-panel";
import { COPY } from "@/components/jyotish/copy";
import { MatchPanel } from "@/components/jyotish/match-panel";
import { ReportView } from "@/components/jyotish/report-view";
import { Field, fieldClass, GhostButton, PrimaryButton } from "@/components/jyotish/ui";

export const Route = createFileRoute("/")({ component: Home });

type Tab = "chart" | "match" | "ask";

function Home() {
  const geocode = useServerFn(geocodePlace);
  const [lang, setLang] = useState<Lang>("Hindi");
  const [tab, setTab] = useState<Tab>("chart");
  const [name, setName] = useState("");
  const [gender, setGender] = useState<Gender>("Male");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("10:30");
  const [place, setPlace] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [report, setReport] = useState<Report | null>(null);
  const [profiles, setProfiles] = useState<SavedProfile[]>([]);
  const [savedNote, setSavedNote] = useState<string | null>(null);
  const copy = COPY[lang];
  const today = new Date().toISOString().slice(0, 10);

  useEffect(() => {
    const stored = localStorage.getItem("jyotish-lang");
    if (stored === "English" || stored === "Nepali" || stored === "Hindi") setLang(stored);
    setProfiles(loadProfiles());
  }, []);

  function chooseLang(next: Lang) {
    setLang(next);
    localStorage.setItem("jyotish-lang", next);
  }

  async function draw(input: {
    name: string;
    gender: Gender;
    date: string;
    time: string;
    place: string;
    geo?: Pick<SavedProfile, "address" | "lat" | "lon" | "timezone">;
  }) {
    if (!input.name.trim() || !input.date || !input.place.trim()) {
      setError(copy.needFields);
      return;
    }
    setBusy(true);
    setError(null);
    setSavedNote(null);
    try {
      let located: { address: string; lat: number; lon: number; timezone: string };
      if (input.geo) {
        located = input.geo;
      } else {
        const geo = await geocode({ data: { place: input.place } });
        if (!geo.ok) {
          setError(geo.error === "not_found" ? copy.placeMissing : copy.placeDown);
          return;
        }
        located = geo;
      }
      const next = computeReport({
        name: input.name,
        gender: input.gender,
        date: input.date,
        time: input.time || "12:00",
        place: input.place,
        address: located.address,
        lat: located.lat,
        lon: located.lon,
        timezone: located.timezone,
      });
      setReport(next);
      setTab("chart");
      requestAnimationFrame(() => {
        document.getElementById("report")?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    } catch {
      setError(copy.placeDown);
    } finally {
      setBusy(false);
    }
  }

  function saveCurrent() {
    if (!report) return;
    const entry: SavedProfile = {
      id: `${Date.now()}`,
      name: report.name,
      gender: report.gender,
      date: report.date,
      time: report.time,
      place: report.place,
      address: report.address,
      lat: report.lat,
      lon: report.lon,
      timezone: report.timezone,
      savedAt: new Date().toISOString(),
    };
    const next = [entry, ...profiles.filter((item) => item.place !== entry.place || item.date !== entry.date || item.time !== entry.time || item.name !== entry.name)];
    setProfiles(next);
    writeProfiles(next);
    setSavedNote(copy.savedOk);
  }

  return (
    <main className="min-h-screen">
      <header className="border-b border-gold bg-maroon text-paper">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs tracking-widest text-paper uppercase">{copy.kicker}</p>
            <h1 className="font-display mt-1 text-4xl font-semibold sm:text-5xl">{copy.title}</h1>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-paper">{copy.sub}</p>
          </div>
          <div className="no-print flex gap-2" role="group" aria-label="Language">
            {(["Hindi", "Nepali", "English"] as const).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => chooseLang(item)}
                className={`min-h-11 rounded-full px-3 text-sm ${lang === item ? "bg-paper text-maroon" : "border border-paper/40 text-paper"}`}
              >
                {item === "Hindi" ? "हिन्दी" : item === "Nepali" ? "नेपाली" : "English"}
              </button>
            ))}
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-4 py-6">
        <div className="no-print mb-6 flex gap-2 overflow-x-auto" role="tablist">
          {(
            [
              ["chart", copy.tabChart],
              ["match", copy.tabMatch],
              ["ask", copy.tabAsk],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              onClick={() => setTab(id)}
              className={`min-h-11 shrink-0 rounded-full px-4 text-sm font-medium ${tab === id ? "bg-maroon text-paper" : "border border-line text-ink"}`}
            >
              {label}
            </button>
          ))}
        </div>

        {tab === "chart" ? (
          <div className="space-y-8">
            <form
              className="no-print rounded-card border border-line bg-paper p-4 shadow-card sm:p-6"
              onSubmit={(event) => {
                event.preventDefault();
                void draw({ name, gender, date, time, place });
              }}
            >
              <div className="grid gap-4 md:grid-cols-2">
                <Field label={copy.name}>
                  <input className={fieldClass} value={name} onChange={(event) => setName(event.target.value)} />
                </Field>
                <Field label={copy.gender}>
                  <select
                    className={fieldClass}
                    value={gender}
                    onChange={(event) => setGender(event.target.value as Gender)}
                  >
                    <option value="Male">{copy.male}</option>
                    <option value="Female">{copy.female}</option>
                    <option value="Other">{copy.other}</option>
                  </select>
                </Field>
                <Field label={copy.date}>
                  <input
                    type="date"
                    min="1900-01-01"
                    max={today}
                    className={fieldClass}
                    value={date}
                    onChange={(event) => setDate(event.target.value)}
                  />
                </Field>
                <Field label={copy.time}>
                  <input type="time" className={fieldClass} value={time} onChange={(event) => setTime(event.target.value)} />
                </Field>
                <div className="md:col-span-2">
                  <Field label={copy.place}>
                    <input
                      className={fieldClass}
                      placeholder={copy.placeHint}
                      value={place}
                      onChange={(event) => setPlace(event.target.value)}
                    />
                  </Field>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-3">
                <PrimaryButton type="submit" disabled={busy}>
                  {busy ? copy.working : copy.generate}
                </PrimaryButton>
                <GhostButton
                  onClick={() => {
                    const sample = {
                      name: copy.sampleName,
                      gender: "Male" as const,
                      date: "1990-08-15",
                      time: "10:30",
                      place: "Kathmandu, Nepal",
                    };
                    setName(sample.name);
                    setGender(sample.gender);
                    setDate(sample.date);
                    setTime(sample.time);
                    setPlace(sample.place);
                    void draw(sample);
                  }}
                >
                  {copy.sample}
                </GhostButton>
              </div>
              {error ? <p className="mt-3 text-sm text-maroon">{error}</p> : null}
            </form>

            <section className="no-print">
              <h2 className="font-display text-2xl text-maroon">{copy.saved}</h2>
              {profiles.length === 0 ? (
                <p className="mt-2 text-sm text-muted">{copy.noneSaved}</p>
              ) : (
                <ul className="mt-3 divide-y divide-line rounded-card border border-line">
                  {profiles.map((profile) => (
                    <li key={profile.id} className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="font-medium">{profile.name}</p>
                        <p className="text-sm text-muted">
                          {profile.date} {profile.time} · {profile.place}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <GhostButton
                          onClick={() => {
                            setName(profile.name);
                            setGender(profile.gender);
                            setDate(profile.date);
                            setTime(profile.time);
                            setPlace(profile.place);
                            void draw({
                              name: profile.name,
                              gender: profile.gender,
                              date: profile.date,
                              time: profile.time,
                              place: profile.place,
                              geo: profile,
                            });
                          }}
                        >
                          {copy.load}
                        </GhostButton>
                        <GhostButton
                          onClick={() => {
                            const next = profiles.filter((item) => item.id !== profile.id);
                            setProfiles(next);
                            writeProfiles(next);
                          }}
                        >
                          {copy.delete}
                        </GhostButton>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {report ? (
              <ReportView
                key={`${report.name}-${report.date}-${report.time}-${report.lat}`}
                report={report}
                copy={copy}
                onSave={saveCurrent}
                savedNote={savedNote}
              />
            ) : null}
          </div>
        ) : null}

        {tab === "match" ? <MatchPanel copy={copy} /> : null}
        {tab === "ask" ? <ChatPanel copy={copy} lang={lang} report={report} /> : null}

        <footer className="mt-12 border-t border-line pt-4 text-sm leading-relaxed text-muted">{copy.disclaimer}</footer>
      </div>
    </main>
  );
}
